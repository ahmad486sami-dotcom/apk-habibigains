import re, csv, json, sys
DROP = [r'\s*\(Includes foods for USDA\'s Food Distribution Program\)', r'\s*\(includes.*?\)', r',?\s*UPC\s*:?\s*[\d ]+', r',?\s*NFS\b', r',?\s*\bNS as to [^,]*', r'\bbroilers? or fryers,\s*', r'\bbroiler,\s*', r'\bcommercially prepared\b,?\s*']
SUFFIX = {'cheese','bread','crackers','cookies','soup','sauce','oil','beans','pie','cake','rolls','muffins','pasta','noodles','rice','juice','tea','yogurt','milk','cereal','pastry','frozen novelties'}
DROPHEAD = {'fish','spices','cereals','beverages','candies','snacks','nuts','seeds','fast foods','restaurant','game meat','mollusks','crustacean','crustaceans','alcoholic beverage','cereals ready-to-eat','fast food','babyfood','infant formula','salad dressing','sweeteners','leavening agents','spice'}
MEAT = {'chicken','turkey','beef','pork','lamb','veal','duck','goose','emu','ostrich','quail'}
def clean(desc):
    s = re.sub(r'prepared from recipe', 'homemade', desc, flags=re.I)
    for p in DROP: s = re.sub(p, '', s, flags=re.I)
    s = re.sub(r'\s+', ' ', s)
    s = re.sub(r'\s*,\s*,+', ',', s).strip(' ,')
    parts = [p.strip() for p in s.split(',') if p.strip()]
    # "Chicken, breast, meat only, roasted" -> "Chicken breast, meat only, roasted"
    STATE = {'raw','cooked','canned','frozen','dried','boiled','roasted','fried','baked','grilled','dry','fresh','plain','whole','regular','fluid','uncooked','prepared','ready-to-serve','ready-to-eat','unprepared'}
    head = parts[0].lower()
    if len(parts) >= 2 and parts[1].lower() not in STATE:
        sec = parts[1]
        if head in SUFFIX:
            parts = [sec + ' ' + head] + parts[2:]
        elif head in DROPHEAD:
            parts = [sec[0].upper() + sec[1:]] + parts[2:]
        elif head in MEAT and len(sec.split()) <= 3:
            parts = [parts[0] + ' ' + sec.lower()] + parts[2:]
    out = ', '.join([parts[0]] + [p if re.search(r'[A-Z]{2}', p) else p.lower() for p in parts[1:]])
    out = out[0].upper() + out[1:]
    return out[:120]
if __name__ == '__main__':
    for l in sys.stdin: print(clean(l.strip()))
