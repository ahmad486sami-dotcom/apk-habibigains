// Supabase Edge Function: RevenueCat → Supabase, keeps profiles.is_premium in sync.
// In RevenueCat set the app user ID to the Supabase user ID (the app does this on login),
// then add a webhook pointing to this function with the Authorization header below.
// Deploy: supabase functions deploy revenuecat-webhook --no-verify-jwt
// Secret: supabase secrets set REVENUECAT_WEBHOOK_SECRET=some-long-random-string

import { createClient } from 'npm:@supabase/supabase-js@2';

const ACTIVE = ['INITIAL_PURCHASE', 'RENEWAL', 'UNCANCELLATION', 'PRODUCT_CHANGE', 'NON_RENEWING_PURCHASE'];
const INACTIVE = ['EXPIRATION'];

Deno.serve(async (req) => {
  if (req.headers.get('Authorization') !== `Bearer ${Deno.env.get('REVENUECAT_WEBHOOK_SECRET')}`) {
    return new Response('unauthorized', { status: 401 });
  }
  const { event } = await req.json();
  const userId: string | undefined = event?.app_user_id;
  if (!userId || userId.startsWith('$RCAnonymousID')) return new Response('ignored');

  let isPremium: boolean | null = null;
  if (ACTIVE.includes(event.type)) isPremium = true;
  if (INACTIVE.includes(event.type)) isPremium = false;
  if (isPremium === null) return new Response('ignored');

  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  await admin.from('profiles').update({ is_premium: isPremium }).eq('id', userId);
  return new Response('ok');
});
