Deployed to Supabase on 31 Oct 2026 (function: fatsecret-search).
Needs two secrets in Supabase > Edge Functions > Secrets: FATSECRET_CLIENT_ID and FATSECRET_CLIENT_SECRET.
