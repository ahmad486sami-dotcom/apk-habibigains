-- Recipe sharing (applied 31 Oct 2026)
alter table public.foods add column if not exists is_shared boolean not null default false;
alter table public.foods add column if not exists cooked_count integer not null default 0;
alter table public.foods add column if not exists shared_at timestamptz;
drop policy if exists "foods readable" on public.foods;
create policy "foods readable" on public.foods for select to authenticated using (
  source in ('usda', 'uae', 'off') or created_by = (select auth.uid())
  or (source = 'recipe' and is_shared = true) or public.my_role() = 'admin');
create index if not exists foods_shared_recipes_idx on public.foods (shared_at desc) where source = 'recipe' and is_shared = true;
create or replace function public.mark_cooked(recipe_id uuid) returns integer language sql security definer set search_path = public as $$
  update public.foods set cooked_count = cooked_count + 1 where id = recipe_id and source = 'recipe' and is_shared = true returning cooked_count;
$$;
revoke all on function public.mark_cooked(uuid) from public, anon;
grant execute on function public.mark_cooked(uuid) to authenticated;
