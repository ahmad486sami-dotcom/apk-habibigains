-- Workout calories (applied 31 Oct 2026)
create table if not exists public.exercise_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  logged_on date not null default current_date,
  name text not null check (char_length(name) between 1 and 80),
  minutes integer not null default 0 check (minutes >= 0 and minutes <= 1440),
  kcal integer not null check (kcal >= 0 and kcal <= 5000),
  created_at timestamptz not null default now()
);
create index if not exists exercise_logs_user_day on public.exercise_logs (user_id, logged_on);
alter table public.exercise_logs enable row level security;
create policy "own exercise" on public.exercise_logs for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
