# Terms of Use — Habibi Gains

_Last updated: [DATE]_

> Draft template. Have it reviewed by a lawyer before launch.

1. **Not medical advice.** Habibi Gains gives general fitness and nutrition guidance based on published
   research. It is not a medical device and does not diagnose or treat anything. Talk to a doctor before
   changing your diet or exercise if you have a health condition, are pregnant or breastfeeding, take
   medication, or are under 18. Supplement information (creatine, caffeine) is general and not a recommendation
   for you personally.
2. **Your account.** Keep your login secure. You're responsible for what happens on your account.
3. **Run clubs and events.** You take part at your own risk. Follow hosts' instructions, local laws and
   heat-safety advice. Hosts are independent and responsible for their events.
4. **Community rules.** No harassment, no hate, no impersonation, no posting other people's photos without
   consent. Quest photos must not show people who haven't agreed to it. We can remove content or accounts
   that break these rules.
5. **Premium.** Subscriptions renew automatically through Apple or Google until you cancel in your store
   settings. Refunds follow Apple's and Google's policies.
6. **AI estimates.** Calorie estimates from photos are approximate and can be wrong.
7. **Changes.** We may update the app and these terms. Continuing to use the app means you accept the changes.
8. **Law.** These terms are governed by the laws of the United Arab Emirates and the Emirate of Abu Dhabi.

Contact: [support@habibigains.app]
