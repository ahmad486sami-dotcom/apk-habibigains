# Privacy Policy — Habibi Gains

_Last updated: [DATE]_

Habibi Gains ("we", "us") is operated by [YOUR NAME / COMPANY], [ADDRESS], United Arab Emirates.
Contact: [support@habibigains.app]

> Draft template. Have it reviewed by a lawyer before launch. The UAE Personal Data Protection Law
> (Federal Decree-Law No. 45 of 2021) treats health data as sensitive.

## What we collect
| Data | Why |
|---|---|
| Email, name, sign-in provider ID (Apple/Google) | To create and secure your account |
| Body data you enter: sex, birth year, height, weight, goals | To calculate your targets and trend |
| Food logs, weigh-ins, progress photos | To show your progress. Photos are private to you |
| Steps, workouts and weight from Apple Health / Health Connect (only if you allow it) | To update your progress automatically |
| Meal and menu photos you send to the smart camera | To estimate calories (see AI processing below) |
| Run-club RSVPs, check-ins, quests, badges, XP | To run community features |
| Purchase status (via Apple/Google and RevenueCat) | To unlock Premium |

We do **not** sell your data, show third-party ads, or use your health data for advertising.
Data from Apple Health is never used for marketing and never shared with third parties for advertising.

## AI processing
When you use the smart camera, the photo is sent securely to our server and to Anthropic (Claude) to
estimate the food. Photos sent for analysis are not stored by us after the estimate is returned.

## Where your data lives
Our database and file storage are provided by Supabase. Subscriptions are processed by Apple, Google and
RevenueCat. These providers act on our instructions and may store data outside the UAE.

## Who can see what
- Your logs, weight and photos: only you.
- Run clubs: hosts see who RSVP'd and checked in to their event (name only).
- Women-only events are visible only to women and the event host.

## Your rights
You can view and edit your data in the app, and **delete your account and all data at any time**
in Settings → Delete account. You can also email us to request a copy of your data.

## Children
Habibi Gains is not intended for anyone under 13. Users under 18 should use it with a parent or guardian.

## Changes
We'll notify you in the app if this policy changes in a meaningful way.
