// Steps leaderboard: all UAE, your emirate, or your friends; today, this week or this month.
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { EMIRATES } from '@/lib/ramadan';
import { useSession } from '@/lib/session';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Row } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

type Scope = 'uae' | 'emirate' | 'friends';
type Period = 'today' | 'week' | 'month';
type Entry = { rank: number; user_id: string; username: string | null; display_name: string | null; avatar_url: string | null; emirate: string | null; steps: number; is_me: boolean };

export default function Leaderboard() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const [scope, setScope] = useState<Scope>('uae');
  const [period, setPeriod] = useState<Period>('week');
  const [emirate, setEmirate] = useState<string>(profile?.emirate ?? 'Abu Dhabi');
  const [rows, setRows] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    setLoading(true);
    supabase
      .rpc('steps_leaderboard', { scope, period, p_emirate: scope === 'emirate' ? emirate : null })
      .then(({ data }) => setRows(((data ?? []) as Entry[]).map((r) => ({ ...r, rank: Number(r.rank), steps: Number(r.steps) }))))
      .then(() => setLoading(false), () => setLoading(false));
  }, [scope, period, emirate]);
  useFocusEffect(load);

  const me = rows.find((r) => r.is_me);
  const publicSteps = (profile?.privacy as any)?.steps === 'everyone';
  const medal = (n: number) => (n === 1 ? '#F5C542' : n === 2 ? '#C9CED6' : n === 3 ? '#D9905A' : null);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h2">{L('Steps leaderboard', 'ترتيب الخطوات')}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <Chips value={scope} onChange={setScope} options={[{ value: 'uae', label: L('All UAE', 'كل الإمارات') }, { value: 'emirate', label: L('My emirate', 'إمارتي') }, { value: 'friends', label: L('Friends', 'الأصحاب') }]} />
      {scope === 'emirate' ? <Chips value={emirate} onChange={setEmirate} options={Object.keys(EMIRATES).map((e) => ({ value: e, label: e }))} /> : null}
      <Chips value={period} onChange={setPeriod} options={[{ value: 'today', label: L('Today', 'اليوم') }, { value: 'week', label: L('7 days', '٧ أيام') }, { value: 'month', label: L('30 days', '٣٠ يوم') }]} />

      {me ? (
        <Card>
          <Row style={{ justifyContent: 'space-between' }}>
            <Txt v="bodyStrong">{L(`You're #${me.rank}`, `ترتيبك #${me.rank}`)}</Txt>
            <Txt v="bodyStrong" color={theme.accent}>{me.steps.toLocaleString('en-US')}</Txt>
          </Row>
          {scope !== 'friends' && !publicSteps ? (
            <Press onPress={() => router.push('/profile-edit')}>
              <Txt v="small" muted>{L('Only you see yourself here. To appear for others, set Steps to Everyone in Edit profile.', 'أنت فقط تشوف نفسك هنا. لتظهر للكل، اجعل الخطوات "الكل" في تعديل الحساب.')}</Txt>
            </Press>
          ) : null}
        </Card>
      ) : null}

      <Card>
        {rows.filter((r) => r.steps > 0).map((r) => (
          <Press key={r.user_id} onPress={() => !r.is_me && router.push({ pathname: '/user/[id]', params: { id: r.user_id } })} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 4 }}>
            <View style={{ width: 30, alignItems: 'center' }}>
              <Txt v="bodyStrong" color={medal(r.rank) ?? theme.muted}>{r.rank}</Txt>
            </View>
            <Avatar url={r.avatar_url} name={r.display_name ?? r.username} size={36} />
            <View style={{ flex: 1 }}>
              <Txt v="bodyStrong" color={r.is_me ? theme.accent : theme.text}>{r.is_me ? L('You', 'أنت') : r.display_name ?? r.username}</Txt>
              <Txt v="small" faint>{[r.username ? `@${r.username}` : null, scope === 'uae' ? r.emirate : null].filter(Boolean).join(' · ')}</Txt>
            </View>
            <Txt v="bodyStrong">{r.steps.toLocaleString('en-US')}</Txt>
          </Press>
        ))}
        {!loading && !rows.some((r) => r.steps > 0) ? <Txt muted>{scope === 'friends' ? L('No steps from friends yet. Steps sync when people open the app.', 'ما في خطوات من الأصحاب بعد.') : L('No one on this board yet. Be the first.', 'ما في أحد بعد. كن الأول.')}</Txt> : null}
      </Card>
      <Txt v="small" faint center>{L('Steps come from each person\'s iPhone and update when they open the app.', 'الخطوات من جوال كل شخص وتتحدث لما يفتح التطبيق.')}</Txt>
    </ScrollView>
  );
}
