// Challenge leaderboard.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { Challenge, challengeBoard, KIND_LABEL, leaveChallenge, postEvent } from '@/lib/social';
import { useSession } from '@/lib/session';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function ChallengeView() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const [c, setC] = useState<Challenge | null>(null);
  const [board, setBoard] = useState<Awaited<ReturnType<typeof challengeBoard>>>([]);

  const { session } = useSession();
  // You won a finished challenge → friends' feed (once).
  useEffect(() => {
    if (!c || !board.length || !session) return;
    const ended = new Date(c.ends_on + 'T23:59:59') < new Date();
    if (ended && board.length > 1 && board[0].user_id === session.user.id && board[0].score != null) postEvent('challenge_won', c.id, { title: c.title }).catch(() => {});
  }, [c?.id, board.length, session?.user.id]);

  useEffect(() => {
    if (!id) return;
    supabase.from('challenges').select('id,creator,title,kind,starts_on,ends_on,stake').eq('id', id).single().then(({ data }) => setC(data as Challenge));
    challengeBoard(id).then(setBoard).catch(() => {});
  }, [id]);

  if (!c) return <View style={{ flex: 1, backgroundColor: theme.bg }} />;
  const unit = KIND_LABEL[c.kind]?.unit ?? '';
  const daysLeft = Math.max(0, Math.ceil((+new Date(c.ends_on) - Date.now()) / 86_400_000) + 1);
  const fmt = (s: number | null) => (s == null ? L('needs a weigh-in', 'يحتاج وزن') : c.kind === 'steps' ? `${Math.round(s).toLocaleString('en-US')} ${unit}` : `${s} ${unit}`);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h2" style={{ flex: 1 }}>{c.title}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <Txt v="small" muted>{`${L(KIND_LABEL[c.kind]?.en ?? c.kind, KIND_LABEL[c.kind]?.ar ?? c.kind)} · ${c.starts_on} → ${c.ends_on} · ${daysLeft ? L(`${daysLeft} days left`, `باقي ${daysLeft} يوم`) : L('Finished', 'انتهى')}`}</Txt>
      {c.stake ? <Card><Txt>{`${L('Stake', 'الرهان')}: ${c.stake}`}</Txt></Card> : null}
      <Card>
        {board.map((b, i) => (
          <Row key={b.user_id} style={{ justifyContent: 'space-between' }}>
            <Row gap={10} style={{ flex: 1 }}>
              <Txt v="h3" color={i === 0 ? theme.accent : theme.muted} style={{ width: 22 }}>{i + 1}</Txt>
              <Avatar url={b.avatar_key} name={b.display_name ?? b.username} size={36} />
              <Txt v="bodyStrong">{b.display_name ?? b.username}</Txt>
            </Row>
            <Txt v="bodyStrong">{fmt(b.score)}</Txt>
          </Row>
        ))}
      </Card>
      <Button kind="ghost" title={L('Leave challenge', 'انسحاب')} onPress={() => Alert.alert(L('Leave this challenge?', 'تنسحب؟'), '', [{ text: L('Cancel', 'إلغاء') }, { text: L('Leave', 'انسحاب'), style: 'destructive', onPress: async () => { await leaveChallenge(c.id).catch(() => {}); router.back(); } }])} />
    </ScrollView>
  );
}
