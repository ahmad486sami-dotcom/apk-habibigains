// Admin: add / edit a supplement category (guide text) or a product (photo, where to buy, partner).
import * as ImagePicker from 'expo-image-picker';
import { Image } from 'expo-image';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Switch, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { success, warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { deleteCategory, deleteProduct, fetchCatalog, saveCategory, saveProduct, STORE_PRESETS, SuppCategory, SuppLink, SuppProduct, uploadSuppPhoto } from '@/lib/supps';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const EMPTY_CAT: SuppCategory = { id: '', name_en: '', name_ar: '', tagline_en: '', tagline_ar: '', good_for_en: '', good_for_ar: '', how_en: '', how_ar: '', note_en: '', note_ar: '', sources: '', icon: 'sparkle', sort: 100, visible: true };
const ICONS = ['bolt', 'flame', 'sparkle', 'moon', 'star', 'pill'];

export default function SuppEdit() {
  const p = useLocalSearchParams<{ kind: 'category' | 'product'; id?: string; category?: string }>();
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const [cats, setCats] = useState<SuppCategory[]>([]);
  const [cat, setCat] = useState<SuppCategory>(EMPTY_CAT);
  const [prod, setProd] = useState<Partial<SuppProduct>>({ category_id: p.category ?? '', name: '', links: [{ label: 'Noon', url: '' }], partner: false, visible: true, sort: 100, blurb_en: '', blurb_ar: '' });
  const [busy, setBusy] = useState(false);
  const isCat = p.kind === 'category';

  useEffect(() => {
    fetchCatalog().then(({ categories, products }) => {
      setCats(categories);
      if (isCat && p.id) { const c = categories.find((x) => x.id === p.id); if (c) setCat(c); }
      if (!isCat && p.id) { const x = products.find((y) => y.id === p.id); if (x) setProd(x); }
    }).catch(() => {});
  }, [p.id, p.kind]);

  if (profile?.role !== 'admin') return null;

  const setC = (k: keyof SuppCategory) => (v: string) => setCat({ ...cat, [k]: v });
  const setP = (k: keyof SuppProduct) => (v: string) => setProd({ ...prod, [k]: v });
  const links = (prod.links ?? []) as SuppLink[];
  const setLink = (i: number, patch: Partial<SuppLink>) => setProd({ ...prod, links: links.map((l, j) => (j === i ? { ...l, ...patch } : l)) });

  const pickPhoto = async () => {
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, aspect: [1, 1], quality: 0.8 });
    if (r.canceled || !r.assets?.[0]) return;
    setBusy(true);
    try { setProd({ ...prod, image_url: await uploadSuppPhoto(r.assets[0].uri) }); }
    catch { warn(); Alert.alert(L('Upload failed', 'فشل الرفع')); }
    finally { setBusy(false); }
  };

  const save = async () => {
    setBusy(true);
    try {
      if (isCat) {
        const id = (cat.id || cat.name_en).toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30);
        if (!id || !cat.name_en.trim()) throw new Error('name');
        await saveCategory({ ...cat, id, sort: Number(cat.sort) || 100 });
      } else {
        if (!prod.name?.trim() || !prod.category_id) throw new Error('name');
        await saveProduct({ ...(prod as SuppProduct), name: prod.name.trim(), sort: Number(prod.sort) || 100, promo_code: prod.promo_code?.trim() || null });
      }
      success();
      router.back();
    } catch (e: any) {
      warn();
      Alert.alert(e?.message === 'name' ? L('Add a name (and a category)', 'أضف اسم (وفئة)') : L('Could not save', 'ما انحفظ'), e?.message === 'name' ? '' : String(e?.message ?? ''));
    } finally { setBusy(false); }
  };

  const remove = () =>
    Alert.alert(isCat ? L('Delete this category and all its products?', 'تحذف الفئة وكل منتجاتها؟') : L('Delete this product?', 'تحذف المنتج؟'), L('You can hide it instead (switch off "Visible").', 'تقدر تخفيه بدل الحذف.'), [
      { text: L('Cancel', 'إلغاء'), style: 'cancel' },
      { text: L('Delete', 'حذف'), style: 'destructive', onPress: async () => { await (isCat ? deleteCategory(cat.id) : deleteProduct(prod.id!)).catch(() => {}); router.back(); } },
    ]);

  const pair = (label: string, en: string, ar: string, onEn: (v: string) => void, onAr: (v: string) => void, multiline = true) => (
    <View style={{ gap: 8 }}>
      <Field label={`${label} (English)`} value={en} onChangeText={onEn} multiline={multiline} style={multiline ? { height: undefined, minHeight: 56, paddingTop: 16 } : undefined} />
      <Field label={`${label} (عربي)`} value={ar} onChangeText={onAr} multiline={multiline} style={multiline ? { height: undefined, minHeight: 56, paddingTop: 16, textAlign: 'right' } : { textAlign: 'right' }} />
    </View>
  );

  const toggle = (label: string, value: boolean, on: (v: boolean) => void) => (
    <Row style={{ justifyContent: 'space-between' }}>
      <Txt>{label}</Txt>
      <Switch value={value} onValueChange={on} trackColor={{ true: theme.accent }} />
    </Row>
  );

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 80 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{isCat ? (p.id ? L('Edit category', 'تعديل الفئة') : L('New category', 'فئة جديدة')) : p.id ? L('Edit product', 'تعديل المنتج') : L('New product', 'منتج جديد')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
        </Row>

        {isCat ? (
          <>
            {pair(L('Name', 'الاسم'), cat.name_en, cat.name_ar, setC('name_en'), setC('name_ar'), false)}
            {pair(L('Why people take it', 'ليش الناس ياخذونه'), cat.tagline_en, cat.tagline_ar, setC('tagline_en'), setC('tagline_ar'))}
            {pair(L('Great for', 'مناسب لـ'), cat.good_for_en, cat.good_for_ar, setC('good_for_en'), setC('good_for_ar'))}
            {pair(L('How to take it', 'طريقة الاستخدام'), cat.how_en, cat.how_ar, setC('how_en'), setC('how_ar'))}
            {pair(L('Good to know (safety)', 'معلومة مفيدة (السلامة)'), cat.note_en, cat.note_ar, setC('note_en'), setC('note_ar'))}
            <Field label={L('Sources (separate with " · ")', 'المصادر')} value={cat.sources} onChangeText={setC('sources')} multiline style={{ height: undefined, minHeight: 56, paddingTop: 16 }} />
            <Txt v="label" muted>{L('Icon', 'الأيقونة')}</Txt>
            <Row gap={8}>
              {ICONS.map((i) => (
                <Press key={i} onPress={() => setCat({ ...cat, icon: i })} style={{ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: cat.icon === i ? theme.accent : theme.card }}>
                  <Icon name={i as any} size={18} color={cat.icon === i ? theme.onAccent : theme.text} />
                </Press>
              ))}
            </Row>
            <Field label={L('Order (lower shows first)', 'الترتيب (الأقل يطلع أول)')} value={String(cat.sort)} onChangeText={(v) => setCat({ ...cat, sort: Number(v.replace(/\D/g, '')) || 0 })} keyboardType="number-pad" />
            {toggle(L('Visible to users', 'ظاهر للمستخدمين'), cat.visible, (v) => setCat({ ...cat, visible: v }))}
          </>
        ) : (
          <>
            <Txt v="label" muted>{L('Category', 'الفئة')}</Txt>
            <Row gap={8} style={{ flexWrap: 'wrap' }}>
              {cats.map((c) => (
                <Press key={c.id} onPress={() => setProd({ ...prod, category_id: c.id })} style={{ paddingHorizontal: 12, height: 34, borderRadius: 17, justifyContent: 'center', backgroundColor: prod.category_id === c.id ? theme.accent : theme.card }}>
                  <Txt v="small" color={prod.category_id === c.id ? theme.onAccent : theme.text}>{lang === 'ar' ? c.name_ar : c.name_en}</Txt>
                </Press>
              ))}
            </Row>
            <Press onPress={pickPhoto} style={{ alignSelf: 'flex-start', width: 110, height: 110, borderRadius: 20, backgroundColor: '#FFF', overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }}>
              {prod.image_url ? <Image source={{ uri: prod.image_url }} style={{ width: 110, height: 110 }} contentFit="contain" /> : <Txt v="small" color="#666">{L('+ Photo', '+ صورة')}</Txt>}
            </Press>
            <Field label={L('Product name', 'اسم المنتج')} value={prod.name ?? ''} onChangeText={setP('name')} maxLength={80} />
            <Field label={L('Brand', 'الماركة')} value={prod.brand ?? ''} onChangeText={setP('brand')} />
            <Field label={L('Size (optional)', 'الحجم (اختياري)')} value={prod.size_label ?? ''} onChangeText={setP('size_label')} placeholder="2 kg · 66 servings" />
            {pair(L('Short description', 'وصف قصير'), prod.blurb_en ?? '', prod.blurb_ar ?? '', setP('blurb_en'), setP('blurb_ar'))}

            <Txt v="label" muted>{L('Where to buy (first one is the main button)', 'من وين تشتري (الأول هو الزر الرئيسي)')}</Txt>
            {links.map((l, i) => (
              <View key={i} style={{ backgroundColor: theme.card, borderRadius: 16, padding: 12, gap: 8 }}>
                <Row gap={6} style={{ flexWrap: 'wrap' }}>
                  {STORE_PRESETS.map((s) => (
                    <Press key={s} onPress={() => setLink(i, { label: s })} style={{ paddingHorizontal: 10, height: 28, borderRadius: 14, justifyContent: 'center', backgroundColor: l.label === s ? theme.accent : theme.cardHigh }}>
                      <Txt v="small" color={l.label === s ? theme.onAccent : theme.text} style={{ fontSize: 12 }}>{s}</Txt>
                    </Press>
                  ))}
                </Row>
                <Field label={L('Button text', 'نص الزر')} value={l.label} onChangeText={(v) => setLink(i, { label: v })} maxLength={30} />
                <Field label={L('Link (https://…)', 'الرابط')} value={l.url} onChangeText={(v) => setLink(i, { url: v.trim() })} autoCapitalize="none" autoCorrect={false} keyboardType="url" />
                <Press onPress={() => setProd({ ...prod, links: links.filter((_, j) => j !== i) })}><Txt v="small" color={theme.danger}>{L('Remove link', 'احذف الرابط')}</Txt></Press>
              </View>
            ))}
            <Press onPress={() => setProd({ ...prod, links: [...links, { label: '', url: '' }] })}><Txt v="bodyStrong" color={theme.accent}>{L('+ Add another store', '+ أضف متجر')}</Txt></Press>

            {toggle(L('Partner (paid placement: shows first with a "Partner" tag)', 'شريك (إعلان مدفوع: يطلع أول مع وسم "شريك")'), !!prod.partner, (v) => setProd({ ...prod, partner: v }))}
            {toggle(L('Visible to users', 'ظاهر للمستخدمين'), prod.visible !== false, (v) => setProd({ ...prod, visible: v }))}
            <Field label={L('Order (lower shows first)', 'الترتيب (الأقل يطلع أول)')} value={String(prod.sort ?? 100)} onChangeText={(v) => setProd({ ...prod, sort: Number(v.replace(/\D/g, '')) || 0 })} keyboardType="number-pad" />
          </>
        )}

        <Button title={L('Save', 'حفظ')} loading={busy} onPress={save} />
        {p.id ? <Button kind="ghost" title={L('Delete', 'حذف')} onPress={remove} /> : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
