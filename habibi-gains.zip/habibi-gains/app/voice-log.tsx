// Voice log (like MyFitnessPal): say what you ate, it types it out, splits it into foods,
// and shows matches for each so you pick the right one.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { addFoodLog, Food, foodName, logFromFood, Meal, searchFoods } from '@/lib/data';
import { defaultMeal, MEAL_LABEL, mealsFor } from '@/lib/day';
import { success, warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { todayISO } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

// Loaded lazily so the rest of the app still works if the speech module is missing in a build.
// Speech module switched off for now (it stopped the app opening); the keyboard mic is used instead.
const Speech: any = null;

const WORD_NUM: Record<string, number> = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, half: 0.5, 'واحد': 1, 'اثنين': 2, 'ثلاث': 3, 'نص': 0.5 };

/** "two eggs, toast and a karak" → [{qty:2,text:'eggs'}, {qty:1,text:'toast'}, {qty:1,text:'karak'}] */
export function splitFoods(text: string) {
  return text
    .toLowerCase()
    .split(/,|\band\b|\bwith\b|\bplus\b|\bthen\b| و/)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((part) => {
      const words = part.split(/\s+/);
      let qty = 1;
      const first = words[0];
      if (/^\d+(\.\d+)?$/.test(first)) { qty = Number(first); words.shift(); }
      else if (first in WORD_NUM) { qty = WORD_NUM[first]; words.shift(); }
      const name = words.filter((w) => !['of', 'cup', 'cups', 'piece', 'pieces', 'slice', 'slices', 'bowl'].includes(w)).join(' ');
      return { qty, text: name || part };
    })
    .filter((x) => x.text.length >= 2)
    .slice(0, 8);
}

type Item = { qty: number; text: string; matches: Food[]; picked: Food | null };

export default function VoiceLog() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const p = useLocalSearchParams<{ meal?: Meal; day?: string }>();
  const [meal, setMeal] = useState<Meal>(p.meal ?? defaultMeal(!!profile?.ramadan_mode));
  const [text, setText] = useState('');
  const [listening, setListening] = useState(false);
  const [items, setItems] = useState<Item[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!Speech?.ExpoSpeechRecognitionModule) return;
    const subs = [
      Speech.ExpoSpeechRecognitionModule.addListener('result', (e: any) => setText(e?.results?.[0]?.transcript ?? '')),
      Speech.ExpoSpeechRecognitionModule.addListener('end', () => setListening(false)),
      Speech.ExpoSpeechRecognitionModule.addListener('error', () => setListening(false)),
    ];
    return () => subs.forEach((s: any) => s?.remove?.());
  }, []);

  const listen = async () => {
    if (!Speech?.ExpoSpeechRecognitionModule) {
      Alert.alert(L('Use your keyboard mic', 'استخدم مايك الكيبورد'), L('Tap the box below, then tap the microphone on your keyboard and say what you ate.', 'اضغط على المربع ثم مايك الكيبورد وقل إيش أكلت.'));
      return;
    }
    if (listening) {
      Speech.ExpoSpeechRecognitionModule.stop();
      return;
    }
    const perm = await Speech.ExpoSpeechRecognitionModule.requestPermissionsAsync();
    if (!perm?.granted) {
      Alert.alert(L('Microphone not allowed', 'المايك غير مسموح'), L('Allow microphone and speech recognition in Settings, or type it instead.', 'اسمح بالمايك من الإعدادات أو اكتب.'));
      return;
    }
    setText('');
    setItems([]);
    setListening(true);
    Speech.ExpoSpeechRecognitionModule.start({ lang: lang === 'ar' ? 'ar-AE' : 'en-US', interimResults: true, continuous: false });
  };

  const findFoods = async () => {
    const parts = splitFoods(text);
    if (!parts.length) return;
    setBusy(true);
    const found = await Promise.all(parts.map(async (x) => {
      const matches = (await searchFoods(x.text).catch(() => [])).slice(0, 5);
      return { ...x, matches, picked: matches[0] ?? null };
    }));
    setItems(found);
    setBusy(false);
  };

  useEffect(() => {
    if (!listening && text.trim().length > 2) findFoods();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [listening]);

  const logAll = async () => {
    const chosen = items.filter((i) => i.picked);
    if (!chosen.length) return;
    setBusy(true);
    try {
      for (const i of chosen) {
        const f = i.picked!;
        const serving = f.servings[0] ?? { label: `${f.base_g} g`, g: f.base_g };
        await addFoodLog({ ...logFromFood(f, serving, i.qty, meal, lang, 'search') }, p.day ?? todayISO());
      }
      success();
      router.back();
    } catch {
      warn();
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{L('Voice log', 'تسجيل صوتي')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
        </Row>
        <Chips value={meal} onChange={setMeal} options={mealsFor(!!profile?.ramadan_mode).map((m) => ({ value: m, label: L(MEAL_LABEL[m].en, MEAL_LABEL[m].ar) }))} />
        <Press onPress={listen} style={{ alignSelf: 'center', width: 120, height: 120, borderRadius: 60, backgroundColor: listening ? theme.accent : theme.card, alignItems: 'center', justifyContent: 'center', marginVertical: 8 }}>
          <Txt v="h1" color={listening ? theme.onAccent : theme.accent}>{listening ? '■' : '🎙'}</Txt>
        </Press>
        <Txt center muted>{listening ? L('Listening… tap to stop', 'أسمعك… اضغط للإيقاف') : L('Tap and say what you ate, e.g. "two eggs, toast and a karak"', 'اضغط وقل إيش أكلت، مثلاً "بيضتين وتوست وكرك"')}</Txt>
        <Field label={L('What I heard (you can edit it)', 'اللي سمعته (تقدر تعدله)')} value={text} onChangeText={setText} multiline onEndEditing={findFoods} />
        {!listening && text.trim() && !items.length ? <Button kind="secondary" title={L('Find foods', 'ابحث عن الأكل')} loading={busy} onPress={findFoods} /> : null}

        {items.map((it, idx) => (
          <Card key={idx}>
            <Txt v="bodyStrong">{`${it.qty} × ${it.text}`}</Txt>
            {it.matches.length ? it.matches.map((f) => {
              const on = it.picked?.id === f.id;
              const s = f.servings[0];
              const k = s ? Math.round((f.kcal * s.g) / f.base_g) : Math.round(f.kcal);
              return (
                <Press key={f.id} onPress={() => setItems((x) => x.map((y, j) => (j === idx ? { ...y, picked: on ? null : f } : y)))} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 10, borderRadius: 14, backgroundColor: on ? theme.accentSoft : theme.cardHigh }}>
                  <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: on ? theme.accent : theme.faint, backgroundColor: on ? theme.accent : 'transparent' }} />
                  <View style={{ flex: 1 }}>
                    <Txt>{foodName(f, lang)}</Txt>
                    <Txt v="small" faint>{[f.brand, s?.label ?? `${f.base_g} g`].filter(Boolean).join(' · ')}</Txt>
                  </View>
                  <Txt v="bodyStrong">{k * it.qty}</Txt>
                </Press>
              );
            }) : <Txt v="small" muted>{L('No match. Search for it manually.', 'ما لقينا. ابحث يدوياً.')}</Txt>}
          </Card>
        ))}
        {items.some((i) => i.picked) ? <Button title={L(`Log ${items.filter((i) => i.picked).length} foods`, `سجّل ${items.filter((i) => i.picked).length} أكلات`)} loading={busy} onPress={logAll} /> : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
