// Timing coach: today's plan as a simple timeline.
import { router } from 'expo-router';
import React, { useMemo } from 'react';
import { ScrollView, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { Emirate, fastingTimes } from '@/lib/ramadan';
import { useSession } from '@/lib/session';
import { buildTiming, SOURCES, TimingItem } from '@/lib/timing';
import { useTheme } from '@/theme/theme';
import { Icon, IconName } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const ICON: Record<TimingItem['kind'], IconName> = {
  meal: 'fork',
  preworkout: 'bolt',
  training: 'run',
  postworkout: 'fork',
  supplement: 'pill',
  bedtime: 'moon',
  hydration: 'info',
};

export default function Timing() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const { profile } = useSession();

  const items = useMemo(() => {
    if (!profile) return [];
    return buildTiming({
      weightKg: Number(profile.start_weight_kg ?? 75),
      wake: profile.wake_time,
      sleep: profile.sleep_time,
      training: profile.training_time,
      goal: profile.goal,
      proteinTargetG: profile.protein_target_g ?? 140,
      useCreatine: profile.use_creatine,
      useCaffeine: profile.use_caffeine,
      ramadan: profile.ramadan_mode ? fastingTimes((profile.emirate ?? 'Abu Dhabi') as Emirate) : null,
    });
  }, [profile]);

  const nowMin = new Date().getHours() * 60 + new Date().getMinutes();
  const carbLabel = { low: t('carbsLow'), moderate: t('carbsModerate'), high: t('carbsHigh') };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1">{t('timingTitle')}</Txt>
        <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>
      <Txt muted>{t('timingSub')}</Txt>

      <View style={{ gap: 0, marginTop: 6 }}>
        {items.map((it, i) => {
          const [h, m] = it.time.split(':').map(Number);
          const past = h * 60 + m < nowMin - 30 && h >= 4;
          return (
            <Animated.View key={i} entering={FadeInDown.delay(i * 60).springify()} style={{ flexDirection: 'row', gap: 14, opacity: past ? 0.45 : 1 }}>
              <View style={{ alignItems: 'center', width: 40 }}>
                <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: it.kind === 'training' ? theme.accent : theme.card, alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name={ICON[it.kind]} size={18} color={it.kind === 'training' ? theme.onAccent : theme.accent} />
                </View>
                {i < items.length - 1 ? <View style={{ flex: 1, width: 2, backgroundColor: theme.cardHigh, marginVertical: 4 }} /> : null}
              </View>
              <View style={{ flex: 1, paddingBottom: 22, gap: 4 }}>
                <Row style={{ justifyContent: 'space-between' }}>
                  <Txt v="h3">{t(`tm_${it.titleKey}` as 'tm_lunch')}</Txt>
                  <Txt v="bodyStrong" muted>{it.time}</Txt>
                </Row>
                {it.proteinG || it.carbs ? (
                  <Row gap={6} style={{ flexWrap: 'wrap' }}>
                    {it.proteinG ? <Tag text={`${it.proteinG}${t('g')} ${t('protein').toLowerCase()}`} /> : null}
                    {it.carbs ? <Tag text={carbLabel[it.carbs]} /> : null}
                  </Row>
                ) : null}
                <Txt v="small" muted>{it.detail[lang]}</Txt>
              </View>
            </Animated.View>
          );
        })}
      </View>

      <Press onPress={() => router.push('/settings')} style={{ backgroundColor: theme.card, borderRadius: 18, padding: 14 }}>
        <Txt v="small" muted>{t('timingEdit')}</Txt>
      </Press>

      <View style={{ gap: 6, marginTop: 8 }}>
        <Txt v="label" muted>{t('sources')}</Txt>
        {SOURCES.map((s) => (
          <Txt key={s} v="small" faint>{s}</Txt>
        ))}
        <Txt v="small" faint style={{ marginTop: 6 }}>{t('planNote')}</Txt>
      </View>
    </ScrollView>
  );
}

function Tag({ text }: { text: string }) {
  const { theme } = useTheme();
  return (
    <View style={{ backgroundColor: theme.cardHigh, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3 }}>
      <Txt v="small" style={{ fontSize: 12 }}>{text}</Txt>
    </View>
  );
}
