// Full nutrition for a day: calories by meal, macro split vs goals, and every tracked nutrient.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { fetchDayLogs, FoodLog, getWater, NUTRIENT_KEYS, sumNutrients } from '@/lib/data';
import { dayLabel, macroTargets, MEAL_LABEL, mealsFor, nutrientGoals, NUTRIENT_LABEL } from '@/lib/day';
import { useSession } from '@/lib/session';
import { todayISO } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Bar, Ring } from '@/ui/Graphics';
import { Icon } from '@/ui/Icon';
import { Card, Row, Screen } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function Nutrition() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const p = useLocalSearchParams<{ day?: string }>();
  const day = p.day ?? todayISO();
  const [logs, setLogs] = useState<FoodLog[]>([]);
  const [water, setWater] = useState(0);

  useEffect(() => {
    fetchDayLogs(day).then(setLogs).catch(() => {});
    getWater(day).then(setWater).catch(() => {});
  }, [day]);

  const target = profile?.calorie_target ?? 2000;
  const goals = macroTargets(target, profile?.protein_target_g ?? 140);
  const ng = nutrientGoals(target);
  const t = sumNutrients(logs);
  const macroKcal = t.protein_g * 4 + t.carbs_g * 4 + t.fat_g * 9 || 1;

  const lines: { key: (typeof NUTRIENT_KEYS)[number]; goal: number; limit?: boolean }[] = [
    { key: 'kcal', goal: target, limit: true },
    { key: 'protein_g', goal: goals.protein },
    { key: 'carbs_g', goal: goals.carbs, limit: true },
    { key: 'fat_g', goal: goals.fat, limit: true },
    { key: 'fiber_g', goal: ng.fiber_g },
    { key: 'sugar_g', goal: ng.sugar_g, limit: true },
    { key: 'sat_fat_g', goal: ng.sat_fat_g, limit: true },
    { key: 'sodium_mg', goal: ng.sodium_mg, limit: true },
    { key: 'cholesterol_mg', goal: ng.cholesterol_mg, limit: true },
    { key: 'potassium_mg', goal: ng.potassium_mg },
  ];

  return (
    <Screen bottomInset={60}>
      <Row style={{ justifyContent: 'space-between' }}>
        <View>
          <Txt v="h1">{L('Nutrition', 'التغذية')}</Txt>
          <Txt muted>{dayLabel(day, lang)}</Txt>
        </View>
        <Press onPress={() => router.back()} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>

      <Card index={0}>
        <Txt v="h3">{L('Calories by meal', 'السعرات حسب الوجبة')}</Txt>
        {mealsFor(!!profile?.ramadan_mode).map((m) => {
          const k = Math.round(logs.filter((l) => l.meal === m).reduce((s, l) => s + l.kcal, 0));
          return (
            <View key={m} style={{ gap: 6 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt muted>{L(MEAL_LABEL[m].en, MEAL_LABEL[m].ar)}</Txt>
                <Txt v="bodyStrong">{`${k} · ${t.kcal ? Math.round((k / t.kcal) * 100) : 0}%`}</Txt>
              </Row>
              <Bar progress={t.kcal ? k / t.kcal : 0} />
            </View>
          );
        })}
      </Card>

      <Card index={1}>
        <Txt v="h3">{L('Macros', 'الماكروز')}</Txt>
        <Row gap={16} style={{ justifyContent: 'space-around' }}>
          {[
            [L('Protein', 'بروتين'), t.protein_g, 4, goals.protein],
            [L('Carbs', 'كارب'), t.carbs_g, 4, goals.carbs],
            [L('Fat', 'دهون'), t.fat_g, 9, goals.fat],
          ].map(([label, g, per, goal]) => (
            <View key={label as string} style={{ alignItems: 'center', gap: 6 }}>
              <Ring size={84} stroke={8} progress={(g as number) / (goal as number)}>
                <Txt v="h3">{`${Math.round(((g as number) * (per as number) * 100) / macroKcal)}%`}</Txt>
              </Ring>
              <Txt v="bodyStrong">{label as string}</Txt>
              <Txt v="small" muted>{`${Math.round(g as number)} / ${goal} g`}</Txt>
            </View>
          ))}
        </Row>
      </Card>

      <Card index={2}>
        <Txt v="h3">{L('Nutrients', 'العناصر الغذائية')}</Txt>
        {lines.map(({ key, goal, limit }) => {
          const v = Number(t[key] ?? 0);
          const over = limit && v > goal;
          return (
            <View key={key} style={{ gap: 6 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt muted>{L(NUTRIENT_LABEL[key].en, NUTRIENT_LABEL[key].ar)}</Txt>
                <Txt v="bodyStrong" color={over ? theme.danger : theme.text}>{`${Math.round(v)} / ${goal} ${NUTRIENT_LABEL[key].unit}${limit ? ' ' + L('max', 'حد') : ''}`}</Txt>
              </Row>
              <Bar progress={goal ? v / goal : 0} color={over ? theme.danger : undefined} />
            </View>
          );
        })}
        <Row style={{ justifyContent: 'space-between', marginTop: 4 }}>
          <Txt muted>{L('Water', 'الماء')}</Txt>
          <Txt v="bodyStrong">{`${(water / 1000).toFixed(2)} / ${((profile?.water_goal_ml ?? 3000) / 1000).toFixed(1)} L`}</Txt>
        </Row>
        <Txt v="small" faint>
          {L(
            'Goals: protein from your plan; fat ~28% of calories; fiber 14 g per 1,000 kcal; sodium under 2,300 mg and saturated fat under 10% of calories (Dietary Guidelines for Americans 2020–2025). Some foods have no data for every nutrient, so totals can be lower than reality.',
            'الأهداف: البروتين من خطتك؛ الدهون حوالي ٢٨٪؛ الألياف ١٤ جم لكل ١٠٠٠ سعرة؛ الصوديوم أقل من ٢٣٠٠ ملجم.',
          )}
        </Txt>
      </Card>

      <Button title={L('Share my day', 'شارك يومي')} icon={<Icon name="share" color={theme.onAccent} size={20} />} disabled={!logs.length} onPress={() => router.push({ pathname: '/share', params: { kind: 'day', day } })} />
    </Screen>
  );
}
