// Recipe builder: add ingredients from the food database, set how many servings it makes,
// save it as your own food, and share it as a PDF.
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import Animated, { FadeInDown, LinearTransition, ZoomOut } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { getFood, Ingredient, NUTRIENT_KEYS, Nutrients, saveRecipe, sumNutrients } from '@/lib/data';
import { servingText } from '@/lib/day';
import { select, success, warn } from '@/lib/haptics';
import { takeIngredient } from '@/lib/picker';
import { shareRecipePdf } from '@/lib/recipePdf';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function RecipeBuilder() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const p = useLocalSearchParams<{ id?: string }>();
  const [name, setName] = useState('');
  const [servings, setServings] = useState('4');
  const [items, setItems] = useState<Ingredient[]>([]);
  const [busy, setBusy] = useState(false);
  const [savedId, setSavedId] = useState<string | undefined>(p.id);

  useEffect(() => {
    if (!p.id) return;
    getFood(p.id)
      .then((f) => {
        setName(f.name_en);
        setServings(String(f.recipe_servings ?? 1));
        setItems(f.ingredients ?? []);
      })
      .catch(() => {});
  }, [p.id]);

  // Pick up an ingredient chosen on the search screen.
  useFocusEffect(
    useCallback(() => {
      const i = takeIngredient();
      if (i) setItems((xs) => [...xs, i]);
    }, []),
  );

  const n = Math.max(1, Math.round(Number(servings) || 1));
  const total = sumNutrients(items);
  const per = {} as Nutrients;
  for (const k of NUTRIENT_KEYS) (per as any)[k] = k === 'kcal' ? Math.round(total.kcal / n) : Math.round(((total[k] as number) / n) * 10) / 10;
  const ok = name.trim().length > 0 && items.length > 0;

  const save = async (andShare = false) => {
    setBusy(true);
    try {
      const food = await saveRecipe(name, n, items, savedId);
      setSavedId(food.id);
      success();
      if (andShare) await shareRecipePdf(food, profile?.display_name);
      else router.replace({ pathname: '/food/[id]', params: { id: food.id } });
    } catch {
      warn();
      Alert.alert(L('Could not save', 'ما قدرنا نحفظ'), L('Check your connection and try again.', 'تأكد من الاتصال وحاول مرة ثانية.'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{p.id ? L('Edit recipe', 'تعديل الوصفة') : L('New recipe', 'وصفة جديدة')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}>
            <Icon name="close" />
          </Press>
        </Row>
        <Field label={L('Recipe name', 'اسم الوصفة')} value={name} onChangeText={setName} placeholder={L('e.g. Chicken machboos (mum’s)', 'مثلاً مجبوس دجاج')} maxLength={160} />
        <Row gap={10} style={{ alignItems: 'flex-end' }}>
          <View style={{ flex: 1 }}>
            <Field label={L('Makes how many servings?', 'كم حصة؟')} keyboardType="number-pad" value={servings} onChangeText={(v) => setServings(v.replace(/\D/g, '').slice(0, 3))} />
          </View>
        </Row>

        <Txt v="label" muted style={{ marginTop: 6 }}>{L(`Ingredients (${items.length})`, `المكونات (${items.length})`)}</Txt>
        {items.map((i, idx) => (
          <Animated.View key={`${i.food_id}-${idx}`} entering={FadeInDown} exiting={ZoomOut.duration(160)} layout={LinearTransition}>
            <Row style={{ backgroundColor: theme.card, borderRadius: 18, padding: 14 }}>
              <View style={{ flex: 1, gap: 2 }}>
                <Txt v="bodyStrong" numberOfLines={2}>{i.name}</Txt>
                <Txt v="small" faint>{`${servingText(i.quantity, i.serving_label)} · ${Math.round(i.grams)} g`}</Txt>
              </View>
              <Txt v="bodyStrong">{Math.round(i.kcal)}</Txt>
              <Press
                onPress={() => {
                  select();
                  setItems((xs) => xs.filter((_, j) => j !== idx));
                }}
                accessibilityLabel={L('Remove', 'حذف')}
                style={{ padding: 6 }}
              >
                <Icon name="trash" size={18} color={theme.muted} />
              </Press>
            </Row>
          </Animated.View>
        ))}
        <Press
          onPress={() => router.push({ pathname: '/add-food', params: { mode: 'recipe' } })}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 16, borderRadius: 18, borderWidth: 1, borderStyle: 'dashed', borderColor: theme.border }}
        >
          <Icon name="plus" size={18} color={theme.accent} />
          <Txt v="bodyStrong">{L('Add ingredient', 'أضف مكون')}</Txt>
        </Press>

        {items.length ? (
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 18, gap: 8 }}>
            <Txt v="h3">{L('Per serving', 'لكل حصة')}</Txt>
            <Row style={{ justifyContent: 'space-between' }}>
              <Txt v="h1">{per.kcal}</Txt>
              <Txt muted>{`kcal · ${Math.round(items.reduce((s, i) => s + i.grams, 0) / n)} g`}</Txt>
            </Row>
            <Txt muted>{`${L('Protein', 'بروتين')} ${per.protein_g} g · ${L('Carbs', 'كارب')} ${per.carbs_g} g · ${L('Fat', 'دهون')} ${per.fat_g} g`}</Txt>
            <Txt v="small" faint>{`${L('Whole recipe', 'الوصفة كاملة')}: ${total.kcal} kcal`}</Txt>
          </View>
        ) : null}

        <Button title={L('Save recipe', 'حفظ الوصفة')} loading={busy} disabled={!ok} onPress={() => save(false)} />
        <Button title={L('Save & share as PDF', 'حفظ ومشاركة PDF')} kind="secondary" icon={<Icon name="share" size={18} />} disabled={!ok || busy} onPress={() => save(true)} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
