// Quick add: log calories (and optional macros) without picking a food.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { addFoodLog, Meal } from '@/lib/data';
import { defaultMeal, MEAL_LABEL, mealsFor } from '@/lib/day';
import { success, warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { todayISO } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Chips, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function QuickAdd() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const p = useLocalSearchParams<{ meal?: Meal; day?: string }>();
  const [meal, setMeal] = useState<Meal>(p.meal ?? defaultMeal(!!profile?.ramadan_mode));
  const [f, setF] = useState({ name: '', kcal: '', protein: '', carbs: '', fat: '' });
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (v: string) => setF({ ...f, [k]: v.replace(/[^0-9.,]/g, '') });
  const num = (v: string) => Math.max(0, Number(v.replace(',', '.')) || 0);

  // If macros are given but calories are not, work calories out from them (4/4/9).
  const fromMacros = Math.round(num(f.protein) * 4 + num(f.carbs) * 4 + num(f.fat) * 9);
  const kcal = f.kcal ? Math.round(num(f.kcal)) : fromMacros;

  const save = async () => {
    setBusy(true);
    try {
      await addFoodLog(
        {
          food_id: null,
          name: f.name.trim() || L('Quick add', 'إضافة سريعة'),
          brand: null,
          meal,
          quantity: 1,
          serving_label: L('1 entry', 'إدخال واحد'),
          serving_g: null,
          source: 'quick',
          kcal,
          protein_g: num(f.protein),
          carbs_g: num(f.carbs),
          fat_g: num(f.fat),
          fiber_g: null,
          sugar_g: null,
          sodium_mg: null,
          sat_fat_g: null,
          cholesterol_mg: null,
          potassium_mg: null,
        },
        p.day ?? todayISO(),
      );
      success();
      router.back();
    } catch {
      warn();
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{L('Quick add', 'إضافة سريعة')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}>
            <Icon name="close" />
          </Press>
        </Row>
        <Chips value={meal} onChange={setMeal} options={mealsFor(!!profile?.ramadan_mode).map((m) => ({ value: m, label: L(MEAL_LABEL[m].en, MEAL_LABEL[m].ar) }))} />
        <Field label={L('Description (optional)', 'الوصف (اختياري)')} value={f.name} onChangeText={(v) => setF({ ...f, name: v })} placeholder={L('e.g. Office cake', 'مثلاً كيك المكتب')} maxLength={80} />
        <Field label={L('Calories', 'السعرات')} keyboardType="number-pad" value={f.kcal} onChangeText={set('kcal')} placeholder={fromMacros ? String(fromMacros) : '0'} autoFocus />
        <Row gap={10}>
          <View style={{ flex: 1 }}><Field label={L('Protein g', 'بروتين جم')} keyboardType="decimal-pad" value={f.protein} onChangeText={set('protein')} /></View>
          <View style={{ flex: 1 }}><Field label={L('Carbs g', 'كارب جم')} keyboardType="decimal-pad" value={f.carbs} onChangeText={set('carbs')} /></View>
          <View style={{ flex: 1 }}><Field label={L('Fat g', 'دهون جم')} keyboardType="decimal-pad" value={f.fat} onChangeText={set('fat')} /></View>
        </Row>
        {!f.kcal && fromMacros ? <Txt v="small" muted>{L(`Calories from macros: ${fromMacros} kcal`, `السعرات من الماكروز: ${fromMacros}`)}</Txt> : null}
        <Button title={L('Add', 'إضافة')} loading={busy} disabled={kcal <= 0} onPress={save} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
