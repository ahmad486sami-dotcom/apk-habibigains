// Profile tab: your social profile (photo, @username, gym, stats), friends, requests and challenges.
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { useSession } from '@/lib/session';
import { acceptBuddy, acceptRequest, BuddyRow, Challenge, endBuddy, fetchFeed, FeedItem, FriendRow, getProfileCard, Group, KIND_LABEL, listBuddies, listFriends, myChallenges, myGroups, ProfileCard, removeFriend, unreadCount } from '@/lib/social';
import { FeedList } from '@/ui/FeedList';
import { fmtWeight, unitsOf } from '@/lib/units';
import { success } from '@/lib/haptics';
import { useTheme } from '@/theme/theme';
import { Avatar, Stat } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Row, Screen } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function Profile() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile, session } = useSession();
  const [card, setCard] = useState<ProfileCard | null>(null);
  const [friends, setFriends] = useState<FriendRow[]>([]);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [feed, setFeed] = useState<FeedItem[]>([]);
  const [buddies, setBuddies] = useState<BuddyRow[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [unread, setUnread] = useState(0);
  const [showAllFeed, setShowAllFeed] = useState(false);
  const units = unitsOf(profile);

  const load = useCallback(() => {
    if (!session) return;
    getProfileCard(session.user.id).then(setCard).catch(() => {});
    listFriends().then(setFriends).catch(() => {});
    myChallenges().then(setChallenges).catch(() => {});
    fetchFeed().then(setFeed).catch(() => {});
    listBuddies().then(setBuddies).catch(() => {});
    myGroups().then(setGroups).catch(() => {});
    unreadCount().then(setUnread).catch(() => {});
  }, [session]);
  useFocusEffect(load);

  const incoming = friends.filter((f) => f.status === 'incoming');
  const accepted = friends.filter((f) => f.status === 'accepted');
  const outgoing = friends.filter((f) => f.status === 'outgoing');

  const personRow = (f: FriendRow, right?: React.ReactNode) => (
    <Press key={f.id} onPress={() => router.push({ pathname: '/user/[id]', params: { id: f.id } })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 6 }}>
      <Avatar url={f.avatar_url} name={f.display_name ?? f.username} size={40} />
      <View style={{ flex: 1 }}>
        <Txt v="bodyStrong">{f.display_name ?? f.username ?? '—'}</Txt>
        {f.username ? <Txt v="small" faint>{`@${f.username}`}</Txt> : null}
      </View>
      {right}
    </Press>
  );

  return (
    <Screen>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1">{L('Profile', 'حسابي')}</Txt>
        <Row gap={8}>
          <Press onPress={() => router.push('/inbox')} accessibilityLabel={L('Inbox', 'الإشعارات')} style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: theme.card, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="bell" size={18} />
            {unread ? (
              <View style={{ position: 'absolute', top: -2, right: -2, minWidth: 18, height: 18, borderRadius: 9, paddingHorizontal: 4, backgroundColor: theme.accent, alignItems: 'center', justifyContent: 'center' }}>
                <Txt v="small" color={theme.onAccent} style={{ fontSize: 11, fontWeight: '700' }}>{unread > 9 ? '9+' : String(unread)}</Txt>
              </View>
            ) : null}
          </Press>
          <Press onPress={() => router.push('/my-qr')} accessibilityLabel={L('My code', 'كودي')} style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: theme.card, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="qr" size={18} />
          </Press>
          <Press onPress={() => router.push({ pathname: '/share', params: { design: 'profile' } })} accessibilityLabel={L('Share', 'مشاركة')} style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: theme.card, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="share" size={18} />
          </Press>
          <Press onPress={() => router.push('/settings')} accessibilityLabel={L('Settings', 'الإعدادات')} style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: theme.card, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="settings" size={18} />
          </Press>
        </Row>
      </Row>

      <Card>
        <Row gap={16}>
          <Avatar url={profile?.avatar_url} name={profile?.display_name} size={80} />
          <View style={{ flex: 1, gap: 2 }}>
            <Txt v="h2">{profile?.display_name ?? ''}</Txt>
            <Txt v="small" muted>{profile?.username ? `@${profile.username}` : L('Set your @username', 'اختر اسم المستخدم')}</Txt>
            {profile?.gym ? <Txt v="small" color={theme.accent}>{profile.gym}</Txt> : null}
          </View>
        </Row>
        {profile?.bio ? <Txt>{profile.bio}</Txt> : null}
        <Row style={{ marginTop: 6 }}>
          <Stat value={String(profile?.streak_days ?? 0)} label={L('day streak', 'يوم متتالي')} />
          <Stat value={card?.kg_lost != null ? fmtWeight(Math.max(0, card.kg_lost), units) : '—'} label={L('lost', 'خسرت')} />
          <Stat value={card?.steps_today != null ? card.steps_today.toLocaleString('en-US') : '—'} label={L('steps today', 'خطوات اليوم')} />
          <Stat value={String(accepted.length)} label={L('friends', 'أصحاب')} />
        </Row>
        <Row gap={10}>
          <View style={{ flex: 1 }}><Button kind="secondary" title={L('Edit profile', 'تعديل')} onPress={() => router.push('/profile-edit')} /></View>
          <View style={{ flex: 1 }}><Button kind="secondary" title={L('Share', 'مشاركة')} onPress={() => router.push({ pathname: '/share', params: { design: 'profile' } })} /></View>
        </Row>
      </Card>

      {incoming.length ? (
        <>
          <Txt v="label" muted>{L('Friend requests', 'طلبات الصداقة')}</Txt>
          <Card>
            {incoming.map((f) =>
              personRow(
                f,
                <Row gap={6}>
                  <Press onPress={async () => { await acceptRequest(f.id); success(); load(); }} style={{ paddingHorizontal: 14, height: 34, borderRadius: 17, backgroundColor: theme.accent, justifyContent: 'center' }}>
                    <Txt v="bodyStrong" color={theme.onAccent} style={{ fontSize: 13 }}>{L('Accept', 'قبول')}</Txt>
                  </Press>
                  <Press onPress={async () => { await removeFriend(f.id); load(); }} style={{ paddingHorizontal: 12, height: 34, borderRadius: 17, backgroundColor: theme.cardHigh, justifyContent: 'center' }}>
                    <Icon name="close" size={14} />
                  </Press>
                </Row>,
              ),
            )}
          </Card>
        </>
      ) : null}

      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="label" muted>{L('Friends activity', 'إنجازات الأصحاب')}</Txt>
        {feed.length > 4 ? <Press onPress={() => setShowAllFeed(!showAllFeed)}><Txt v="bodyStrong" color={theme.accent}>{showAllFeed ? L('Less', 'أقل') : L('See all', 'الكل')}</Txt></Press> : null}
      </Row>
      {feed.length ? (
        <FeedList items={showAllFeed ? feed : feed.slice(0, 4)} me={session?.user.id} lang={lang} onChange={(next) => setFeed((all) => all.map((x) => next.find((n) => n.id === x.id) ?? x))} />
      ) : (
        <Card><Txt muted>{L('When you or your friends finish a week on budget, hit a streak or win a challenge, it shows up here automatically.', 'لما تخلص أنت أو أصحابك أسبوع ضمن الميزانية أو توصل لسلسلة أو تفوز بتحدي، يطلع هنا تلقائياً.')}</Txt></Card>
      )}

      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="label" muted>{L('Accountability buddies', 'شركاء الالتزام')}</Txt>
        <Txt v="small" faint>{`${buddies.filter((b) => b.status === 'accepted').length}/3`}</Txt>
      </Row>
      <Card>
        {buddies.length ? buddies.map((b) => personRow(b as FriendRow,
          b.status === 'incoming' ? (
            <Press onPress={async () => { await acceptBuddy(b.id); success(); load(); }} style={{ paddingHorizontal: 14, height: 34, borderRadius: 17, backgroundColor: theme.accent, justifyContent: 'center' }}>
              <Txt v="bodyStrong" color={theme.onAccent} style={{ fontSize: 13 }}>{L('Accept', 'قبول')}</Txt>
            </Press>
          ) : b.status === 'outgoing' ? <Txt v="small" faint>{L('Asked', 'تم الطلب')}</Txt>
          : <Press onPress={async () => { await endBuddy(b.id); load(); }}><Txt v="small" faint>{L('End', 'إنهاء')}</Txt></Press>,
        )) : <Txt muted>{L("Pick up to 3 friends. You both see each other's food diary, and you get a heads-up if your buddy hasn't logged by 9 pm. Open a friend's profile to ask.", 'اختر لين ٣ أصحاب. تشوفون يوميات أكل بعض، وتنبيه إذا شريكك ما سجل لين ٩ بالليل. افتح ملف صديق واطلب.')}</Txt>}
      </Card>

      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="label" muted>{L('Groups', 'المجموعات')}</Txt>
        <Press onPress={() => router.push('/groups')}><Txt v="bodyStrong" color={theme.accent}>{L('+ Create / join', '+ إنشاء / انضمام')}</Txt></Press>
      </Row>
      {groups.length ? groups.map((g) => (
        <Card key={g.id} onPress={() => router.push({ pathname: '/group/[id]', params: { id: g.id } })}>
          <Row style={{ justifyContent: 'space-between' }}>
            <Row gap={10}>
              <Icon name="users" size={20} color={theme.accent} />
              <View>
                <Txt v="bodyStrong">{g.name}</Txt>
                <Txt v="small" faint>{`${g.members ?? 0} ${L('members', 'عضو')}`}</Txt>
              </View>
            </Row>
            <Icon name="chevron" size={16} color={theme.faint} />
          </Row>
        </Card>
      )) : <Card onPress={() => router.push('/groups')}><Txt muted>{L('Make a group for your gym crew, office or family, with one leaderboard and group challenges.', 'سوِّ مجموعة لربعك في الجيم أو الدوام أو العائلة: ترتيب واحد وتحديات جماعية.')}</Txt></Card>}

      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="label" muted>{L('Friends', 'الأصحاب')}</Txt>
        <Press onPress={() => router.push('/friends-add')}><Txt v="bodyStrong" color={theme.accent}>{L('+ Add friends', '+ أضف أصحاب')}</Txt></Press>
      </Row>
      <Card>
        {accepted.length ? accepted.map((f) => personRow(f, <Icon name="chevron" size={16} color={theme.faint} />)) : <Txt muted>{L('Add friends by @username or from your contacts.', 'أضف أصحابك باسم المستخدم أو من جهات الاتصال.')}</Txt>}
        {outgoing.map((f) => personRow(f, <Txt v="small" faint>{L('Requested', 'تم الطلب')}</Txt>))}
      </Card>

      <Card onPress={() => router.push('/leaderboard')}>
        <Row style={{ justifyContent: 'space-between' }}>
          <Row gap={10}>
            <Icon name="medal" size={20} color={theme.accent} />
            <Txt v="bodyStrong">{L('Steps leaderboard · UAE, emirate, friends', 'ترتيب الخطوات · الإمارات، الإمارة، الأصحاب')}</Txt>
          </Row>
          <Icon name="chevron" size={16} color={theme.faint} />
        </Row>
      </Card>

      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="label" muted>{L('Challenges', 'التحديات')}</Txt>
        <Press onPress={() => router.push('/challenge-new')}><Txt v="bodyStrong" color={theme.accent}>{L('+ New', '+ جديد')}</Txt></Press>
      </Row>
      {challenges.length ? (
        challenges.map((c, i) => (
          <Card key={c.id} index={i} onPress={() => router.push({ pathname: '/challenge/[id]', params: { id: c.id } })}>
            <Row style={{ justifyContent: 'space-between' }}>
              <View style={{ flex: 1 }}>
                <Txt v="bodyStrong">{c.title}</Txt>
                <Txt v="small" faint>{`${L(KIND_LABEL[c.kind]?.en ?? c.kind, KIND_LABEL[c.kind]?.ar ?? c.kind)} · ${L('ends', 'ينتهي')} ${c.ends_on}`}</Txt>
              </View>
              <Icon name="medal" size={20} color={theme.accent} />
            </Row>
          </Card>
        ))
      ) : (
        <Card><Txt muted>{L('Start a weight-loss or steps challenge with friends.', 'ابدأ تحدي خسارة وزن أو خطوات مع أصحابك.')}</Txt></Card>
      )}
    </Screen>
  );
}
