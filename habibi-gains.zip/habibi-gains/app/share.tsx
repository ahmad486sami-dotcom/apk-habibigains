// Share studio: swipe through 5 story designs, pick dark or sticker, accent colour and what to show.
import { router, useLocalSearchParams } from 'expo-router';
import * as Sharing from 'expo-sharing';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Dimensions, NativeScrollEvent, NativeSyntheticEvent, ScrollView, Switch, View } from 'react-native';
import { captureRef } from 'react-native-view-shot';
import { useI18n } from '@/i18n/i18n';
import { fetchDailyTotals, fetchDayLogs, fetchExerciseTotals, fetchTrend, FoodLog, sumNutrients } from '@/lib/data';
import { dayLabel, MEAL_LABEL, macroTargets, mealsFor } from '@/lib/day';
import { success, warn } from '@/lib/haptics';
import { isRamadanNow } from '@/lib/ramadan';
import { useSession } from '@/lib/session';
import { supabase, todayISO } from '@/lib/supabase';
import { TrendPoint } from '@/lib/trend';
import { kgTo, unitsOf, weightLabel } from '@/lib/units';
import { buildWeek } from '@/lib/week';
import { ACCENTS, useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Chips, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { DEFAULT_TOGGLES, DesignId, DESIGNS, Look, ShareInput, TOGGLE_LABEL, Toggles } from '@/ui/ShareDesigns';
import { Txt } from '@/ui/Txt';

const SCREEN = Dimensions.get('window').width;
const CARD_W = Math.min(300, SCREEN - 80);

export default function ShareStudio() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile, session } = useSession();
  const units = unitsOf(profile);
  const p = useLocalSearchParams<{ design?: DesignId; kind?: string; day?: string }>();
  const day = p.day ?? todayISO();
  const startId: DesignId = p.design ?? (p.kind === 'day' ? 'plate' : p.kind === 'progress' ? 'progress' : 'day');
  const [index, setIndex] = useState(Math.max(0, DESIGNS.findIndex((d) => d.id === startId)));
  const [look, setLook] = useState<Look>('dark');
  const [accent, setAccent] = useState(theme.accent);
  const [t, setT] = useState<Toggles>(DEFAULT_TOGGLES);
  const [busy, setBusy] = useState(false);
  const refs = useRef<(View | null)[]>([]);
  const pager = useRef<ScrollView>(null);

  const [logs, setLogs] = useState<FoodLog[]>([]);
  const [daily, setDaily] = useState<{ day: string; kcal: number }[]>([]);
  const [ex, setEx] = useState<{ day: string; kcal: number }[]>([]);
  const [trend, setTrend] = useState<TrendPoint[]>([]);
  const [stepsWeek, setStepsWeek] = useState<number | null>(null);
  const [rank, setRank] = useState<ShareInput['rank']>(null);

  useEffect(() => {
    fetchDayLogs(day).then(setLogs).catch(() => {});
    fetchDailyTotals(14).then(setDaily).catch(() => {});
    fetchExerciseTotals(14).then(setEx).catch(() => {});
    fetchTrend(365).then(setTrend).catch(() => {});
    supabase.rpc('steps_leaderboard', { scope: 'friends', period: 'week', p_emirate: null }).then(({ data }) => {
      const rows = (data ?? []) as { rank: number; is_me: boolean; steps: number }[];
      const me = rows.find((r) => r.is_me);
      if (me) { setStepsWeek(Number(me.steps)); setRank({ pos: Number(me.rank), of: rows.length }); }
    }, () => {});
  }, [day]);

  useEffect(() => {
    if (index) setTimeout(() => pager.current?.scrollTo({ x: index * SCREEN, animated: false }), 50);
    // only on open
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const input: ShareInput = useMemo(() => {
    const target = profile?.calorie_target ?? 2000;
    const n = sumNutrients(logs);
    const mt = macroTargets(target, profile?.protein_target_g ?? 140);
    const ramadan = !!profile?.ramadan_mode && isRamadanNow();
    const meals = mealsFor(ramadan).map((m) => ({
      label: L(MEAL_LABEL[m].en, MEAL_LABEL[m].ar),
      items: logs.filter((l) => l.meal === m).map((l) => ({ name: l.name, kcal: l.kcal })),
    }));
    const todayKcal = day === todayISO() ? n.kcal : daily.find((x) => x.day === todayISO())?.kcal ?? 0;
    const week = buildWeek(daily, todayKcal, target, lang, profile?.week_start_day ?? 6, new Date(), ex);
    const first = trend[0];
    const last = trend.at(-1);
    const kgDiff = first && last ? last.trend - first.trend : null;
    return {
      lang,
      name: profile?.display_name ?? '',
      username: profile?.username ?? null,
      avatar_url: profile?.avatar_url ?? null,
      gym: profile?.gym ?? null,
      dateLabel: dayLabel(day, lang),
      kcal: n.kcal,
      target,
      macros: { protein: n.protein_g, carbs: n.carbs_g, fat: n.fat_g },
      macroTargets: { protein: mt.protein, carbs: mt.carbs, fat: mt.fat },
      meals,
      week,
      streak: profile?.streak_days ?? 0,
      kgChange: kgDiff != null ? (kgDiff < 0 ? -kgTo(-kgDiff, units) : kgTo(kgDiff, units)) : null,
      wUnit: weightLabel(units),
      pctChange: first && last ? (kgDiff! / first.trend) * 100 : null,
      trendDays: first && last ? Math.max(1, Math.round((+new Date(last.date) - +new Date(first.date)) / 86_400_000)) : 0,
      trend: trend.slice(-60),
      stepsWeek,
      rank,
      stepsToday: null,
    };
  }, [logs, daily, ex, trend, stepsWeek, rank, profile, lang, day]);

  const current = DESIGNS[index];
  const onScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const i = Math.round(e.nativeEvent.contentOffset.x / SCREEN);
    if (i !== index && i >= 0 && i < DESIGNS.length) setIndex(i);
  };

  const share = async () => {
    const node = refs.current[index];
    if (!node) return;
    setBusy(true);
    try {
      const uri = await captureRef(node, { format: 'png', quality: 1, width: 1080, height: 1920 });
      success();
      await Sharing.shareAsync(uri, { mimeType: 'image/png', UTI: 'public.png' });
    } catch {
      warn();
      Alert.alert(L('Could not create the image', 'ما قدرنا نسوي الصورة'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ paddingVertical: 20, gap: 14, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between', paddingHorizontal: 20 }}>
        <Txt v="h2">{L('Share to your story', 'شارك في الستوري')}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>

      {/* Design names: tap to jump */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, gap: 8 }}>
        {DESIGNS.map((d, i) => (
          <Press key={d.id} haptic={false} onPress={() => { setIndex(i); pager.current?.scrollTo({ x: i * SCREEN, animated: true }); }}
            style={{ paddingHorizontal: 14, height: 36, borderRadius: 18, justifyContent: 'center', backgroundColor: i === index ? theme.accent : theme.card }}>
            <Txt v="bodyStrong" color={i === index ? theme.onAccent : theme.text} style={{ fontSize: 13 }}>{L(d.en, d.ar)}</Txt>
          </Press>
        ))}
      </ScrollView>

      {/* Swipeable previews */}
      <ScrollView ref={pager} horizontal pagingEnabled showsHorizontalScrollIndicator={false} onMomentumScrollEnd={onScroll} scrollEventThrottle={16}>
        {DESIGNS.map((d, i) => {
          const C = d.C;
          return (
            <View key={d.id} style={{ width: SCREEN, alignItems: 'center' }}>
              <View style={{ borderRadius: 22, overflow: 'hidden', borderWidth: 1, borderColor: theme.cardHigh, backgroundColor: look === 'sticker' ? '#5A5F66' : '#0A0B0D' }}>
                <View ref={(r) => { refs.current[i] = r; }} collapsable={false}>
                  <C d={input} w={CARD_W} look={look} accent={accent} t={t} />
                </View>
              </View>
            </View>
          );
        })}
      </ScrollView>
      <Row gap={6} style={{ justifyContent: 'center' }}>
        {DESIGNS.map((d, i) => <View key={d.id} style={{ width: i === index ? 18 : 6, height: 6, borderRadius: 3, backgroundColor: i === index ? theme.accent : theme.cardHigh }} />)}
      </Row>

      <View style={{ paddingHorizontal: 20, gap: 14 }}>
        <Chips value={look} onChange={setLook} options={[{ value: 'dark', label: L('Dark card', 'بطاقة داكنة') }, { value: 'sticker', label: L('Sticker (on your photo)', 'ملصق على صورتك') }]} />
        <Row gap={10} style={{ flexWrap: 'wrap' }}>
          {ACCENTS.map((a) => (
            <Press key={a.id} haptic={false} onPress={() => setAccent(a.hex)} accessibilityLabel={a.id}
              style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: a.hex, borderWidth: accent === a.hex ? 3 : 0, borderColor: theme.text }} />
          ))}
        </Row>
        {current.toggles.map((k) => (
          <Row key={k} style={{ justifyContent: 'space-between' }}>
            <Txt>{L(TOGGLE_LABEL[k].en, TOGGLE_LABEL[k].ar)}</Txt>
            <Switch value={t[k]} onValueChange={(v) => setT({ ...t, [k]: v })} trackColor={{ true: theme.accent }} />
          </Row>
        ))}
        {current.id === 'profile' && !profile?.username ? <Txt v="small" faint>{L('Set an @username in Edit profile to show your QR code.', 'اختر اسم مستخدم عشان يطلع الكود.')}</Txt> : null}
        <Button title={L('Share', 'مشاركة')} icon={<Icon name="share" size={18} color={theme.onAccent} />} loading={busy} onPress={share} />
        <Txt v="small" faint center>{L('Swipe for more designs. Opens Instagram, Snapchat, WhatsApp, Save Image and more.', 'اسحب لتصاميم ثانية. يفتح انستغرام وسناب وواتساب وحفظ الصورة.')}</Txt>
      </View>
    </ScrollView>
  );
}
