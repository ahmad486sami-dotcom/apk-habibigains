// Inbox: nudges, reactions, friend/buddy requests, challenge and group invites.
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { success } from '@/lib/haptics';
import { acceptBuddy, acceptRequest, fetchInbox, InboxItem, joinGroup, markAllRead } from '@/lib/social';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Row } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

function ago(iso: string, ar: boolean) {
  const m = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (m < 60) return ar ? `${m} د` : `${m}m`;
  const h = Math.round(m / 60);
  if (h < 24) return ar ? `${h} س` : `${h}h`;
  return ar ? `${Math.round(h / 24)} ي` : `${Math.round(h / 24)}d`;
}

export default function Inbox() {
  const { lang } = useI18n();
  const ar = lang === 'ar';
  const L = (en: string, a: string) => (ar ? a : en);
  const { theme } = useTheme();
  const [items, setItems] = useState<InboxItem[]>([]);
  const [done, setDone] = useState<Record<string, boolean>>({});

  useFocusEffect(useCallback(() => {
    fetchInbox().then((r) => { setItems(r); markAllRead(); }).catch(() => {});
  }, []));

  const text = (i: InboxItem) => {
    const d = i.data ?? {};
    switch (i.kind) {
      case 'nudge': return d.text || L('nudged you', 'نكزك');
      case 'reaction': return L(`reacted ${d.emoji ?? ''} to your update`, `تفاعل ${d.emoji ?? ''} مع إنجازك`);
      case 'friend_request': return L('wants to be friends', 'يبي يضيفك');
      case 'friend_accepted': return L('accepted your friend request', 'قبل طلب صداقتك');
      case 'buddy_request': return L('asked you to be accountability buddies', 'يبيك تكون شريك الالتزام');
      case 'buddy_alert': return L("hasn't logged anything today", 'ما سجل شي اليوم');
      case 'challenge': return L(`added you to "${d.title ?? 'a challenge'}"`, `أضافك لتحدي "${d.title ?? ''}"`);
      case 'group_invite': return L(`invited you to the group "${d.name ?? ''}"`, `دعاك لمجموعة "${d.name ?? ''}"`);
    }
  };

  const action = (i: InboxItem) => {
    if (done[i.id]) return <Icon name="check" size={18} color={theme.accent} />;
    const btn = (label: string, fn: () => Promise<unknown>) => (
      <Press onPress={async () => { await fn().catch(() => {}); success(); setDone((d) => ({ ...d, [i.id]: true })); }} style={{ paddingHorizontal: 14, height: 32, borderRadius: 16, backgroundColor: theme.accent, justifyContent: 'center' }}>
        <Txt v="bodyStrong" color={theme.onAccent} style={{ fontSize: 13 }}>{label}</Txt>
      </Press>
    );
    if (i.kind === 'friend_request' && i.from_user) return btn(L('Accept', 'قبول'), () => acceptRequest(i.from_user!));
    if (i.kind === 'buddy_request' && i.from_user) return btn(L('Accept', 'قبول'), () => acceptBuddy(i.from_user!));
    if (i.kind === 'group_invite' && i.data?.code) return btn(L('Join', 'انضم'), () => joinGroup(i.data.code));
    return null;
  };

  const open = (i: InboxItem) => {
    if (i.kind === 'challenge' && i.data?.id) return router.push({ pathname: '/challenge/[id]', params: { id: i.data.id } });
    if (i.from_user) router.push({ pathname: '/user/[id]', params: { id: i.from_user } });
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 10, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h2">{L('Inbox', 'الإشعارات')}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      {items.length ? items.map((i) => (
        <Card key={i.id} onPress={() => open(i)}>
          <Row>
            <View>
              <Avatar url={i.from?.avatar_url} name={i.from?.display_name ?? i.from?.username} size={42} />
              {!i.read ? <View style={{ position: 'absolute', top: 0, right: 0, width: 10, height: 10, borderRadius: 5, backgroundColor: theme.accent }} /> : null}
            </View>
            <View style={{ flex: 1 }}>
              <Txt><Txt v="bodyStrong">{i.from?.display_name ?? (i.from?.username ? `@${i.from.username}` : '')}</Txt>{` ${text(i)}`}</Txt>
              <Txt v="small" faint>{ago(i.created_at, ar)}</Txt>
            </View>
            {action(i)}
          </Row>
        </Card>
      )) : (
        <Card><Txt muted>{L('Nothing yet. Nudges, reactions and requests from friends show up here.', 'ما في شي. النكزات والتفاعلات والطلبات تطلع هنا.')}</Txt></Card>
      )}
      <Txt v="small" faint center>{L('Lock-screen alerts come once the app is on the App Store.', 'تنبيهات الشاشة المقفلة بتشتغل لما ينزل التطبيق على الآب ستور.')}</Txt>
    </ScrollView>
  );
}
