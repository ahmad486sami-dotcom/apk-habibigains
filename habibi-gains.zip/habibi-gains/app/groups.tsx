// Create a group (gym / office / family) or join one with a 6-letter code.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { success, warn } from '@/lib/haptics';
import { createGroup, FriendRow, joinGroup, listFriends } from '@/lib/social';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function Groups() {
  const params = useLocalSearchParams<{ code?: string }>();
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const [tab, setTab] = useState<'create' | 'join'>(params.code ? 'join' : 'create');
  const [name, setName] = useState('');
  const [code, setCode] = useState(params.code ?? '');
  const [friends, setFriends] = useState<FriendRow[]>([]);
  const [picked, setPicked] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => { listFriends().then((f) => setFriends(f.filter((x) => x.status === 'accepted'))).catch(() => {}); }, []);

  const go = async () => {
    setBusy(true);
    try {
      const id = tab === 'create' ? await createGroup(name, picked) : await joinGroup(code);
      success();
      router.replace({ pathname: '/group/[id]', params: { id } });
    } catch {
      warn();
      Alert.alert(tab === 'join' ? L('No group with that code', 'ما في مجموعة بهالكود') : L('Could not create the group', 'ما قدرنا ننشئ المجموعة'));
    } finally { setBusy(false); }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h2">{L('Groups', 'المجموعات')}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <Txt muted>{L('Your gym crew, office or family: one leaderboard for steps and on-budget days, plus group challenges.', 'ربعك في الجيم أو الدوام أو العائلة: ترتيب للخطوات والأيام ضمن الميزانية، وتحديات جماعية.')}</Txt>
      <Chips value={tab} onChange={setTab} options={[{ value: 'create', label: L('Create', 'إنشاء') }, { value: 'join', label: L('Join with code', 'انضم بكود') }]} />
      {tab === 'create' ? (
        <>
          <Field label={L('Group name', 'اسم المجموعة')} value={name} onChangeText={setName} placeholder={L('e.g. GymNation 6am crew', 'مثلاً ربع جيم الصبح')} maxLength={40} />
          {friends.length ? (
            <>
              <Txt v="label" muted>{L('Invite friends (optional)', 'ادعُ أصحابك (اختياري)')}</Txt>
              <Card>
                {friends.map((f) => {
                  const on = picked.includes(f.id);
                  return (
                    <Press key={f.id} onPress={() => setPicked((p) => (on ? p.filter((x) => x !== f.id) : [...p, f.id]))} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 4 }}>
                      <Avatar url={f.avatar_url} name={f.display_name ?? f.username} size={36} />
                      <Txt style={{ flex: 1 }}>{f.display_name ?? `@${f.username}`}</Txt>
                      <View style={{ width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: on ? theme.accent : theme.faint, backgroundColor: on ? theme.accent : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
                        {on ? <Icon name="check" size={14} color={theme.onAccent} /> : null}
                      </View>
                    </Press>
                  );
                })}
              </Card>
            </>
          ) : null}
          <Txt v="small" faint>{L('Anyone else can join with the group code you get next.', 'أي أحد ثاني يقدر ينضم بكود المجموعة.')}</Txt>
          <Button title={L('Create group', 'أنشئ المجموعة')} loading={busy} disabled={name.trim().length < 2} onPress={go} />
        </>
      ) : (
        <>
          <Field label={L('Group code', 'كود المجموعة')} value={code} onChangeText={(t) => setCode(t.toUpperCase())} autoCapitalize="characters" maxLength={6} placeholder="A1B2C3" />
          <Button title={L('Join', 'انضم')} loading={busy} disabled={code.trim().length !== 6} onPress={go} />
        </>
      )}
    </ScrollView>
  );
}
