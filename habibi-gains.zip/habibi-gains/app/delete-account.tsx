// Delete account: kept out of the way (Settings › Account & data › Delete account) and needs typing DELETE.
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { deleteAccount } from '@/lib/auth';
import { warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function DeleteAccount() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { session } = useSession();
  const [typed, setTyped] = useState('');
  const [busy, setBusy] = useState(false);
  const ok = typed.trim().toUpperCase() === 'DELETE';

  const go = async () => {
    setBusy(true);
    try {
      await deleteAccount('later');
      router.replace('/');
    } catch (e: any) {
      warn();
      Alert.alert(L('Could not delete', 'ما انحذف'), e?.message ?? '');
    } finally { setBusy(false); }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 22, gap: 16, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{L('Delete account', 'حذف الحساب')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
        </Row>
        <Txt>{L('Your account is switched off straight away, and after 30 days these are permanently deleted:', 'حسابك يتوقف على طول، وبعد ٣٠ يوم ينحذف نهائياً:')}</Txt>
        <View style={{ gap: 6 }}>
          {[
            L('Your profile, @username and photo', 'ملفك واسم المستخدم والصورة'),
            L('Every food log, weight entry, photo and workout', 'كل سجلات الأكل والوزن والصور والتمارين'),
            L('Your friends, buddies, groups and challenges', 'أصحابك وشركاءك ومجموعاتك وتحدياتك'),
          ].map((t) => <Txt key={t} muted>{`•  ${t}`}</Txt>)}
        </View>
        <View style={{ backgroundColor: theme.card, borderRadius: 16, padding: 14 }}>
          <Txt>{L('Changed your mind? Just sign in again within 30 days and tap "Restore my account". Everything comes back.', 'غيرت رأيك؟ سجّل دخول خلال ٣٠ يوم واضغط "رجّع حسابي". كل شي يرجع.')}</Txt>
        </View>
        <Txt muted>{L('Until then, your profile is hidden from everyone, and your email and @username stay reserved for you.', 'لين ذاك الوقت ملفك مخفي عن الكل، وإيميلك واسم المستخدم محجوزين لك.')}</Txt>
        <Txt v="small" faint>{session?.user.email ?? ''}</Txt>
        <Field label={L('Type DELETE to confirm', 'اكتب DELETE للتأكيد')} value={typed} onChangeText={setTyped} autoCapitalize="characters" autoCorrect={false} placeholder="DELETE" />
        <Button kind="danger" title={L('Delete my account forever', 'احذف حسابي نهائياً')} disabled={!ok} loading={busy} onPress={go} />
        <Button kind="ghost" title={L('Keep my account', 'خلّ حسابي')} onPress={() => router.back()} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
