// "Why this number?" — every target explained in plain words, with its source.
import { router } from 'expo-router';
import React from 'react';
import { ScrollView, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { calcTargets, proteinReferenceKg, RATE, SOURCES } from '@/lib/nutrition';
import { useSession } from '@/lib/session';
import { useToday } from '@/lib/useToday';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function Why() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const { profile } = useSession();
  const d = useToday(profile);
  if (!profile) return null;

  const weight = d.last?.trend ?? Number(profile.start_weight_kg ?? 75);
  const formula =
    profile.sex && profile.birth_year && profile.height_cm
      ? calcTargets({ sex: profile.sex, birthYear: profile.birth_year, heightCm: Number(profile.height_cm), weightKg: weight, goal: profile.goal, activity: profile.activity })
      : null;
  const ref = profile.height_cm ? proteinReferenceKg(weight, Number(profile.height_cm)) : weight;
  const ar = lang === 'ar';

  const blocks = [
    {
      title: ar ? 'السعرات' : 'Calories',
      number: `${(profile.calorie_target ?? 0).toLocaleString('en-US')} kcal`,
      body: d.measured
        ? ar
          ? `جسمك يحرق تقريباً ${d.measured.toLocaleString('en-US')} سعرة يومياً، محسوبة من أكلك الفعلي وتغيّر اتجاه وزنك خلال آخر ٣٠ يوم (كل كغ ≈ ٧٧٠٠ سعرة).`
          : `Your body burns about ${d.measured.toLocaleString('en-US')} kcal a day. That's measured from what you actually ate and how your trend moved over the last 30 days (1 kg ≈ 7,700 kcal).`
        : ar
          ? `تقدير البداية: ${formula?.tdee.toLocaleString('en-US') ?? '—'} سعرة من معادلة Mifflin-St Jeor حسب طولك ووزنك وعمرك ونشاطك. بعد ٢–٣ أسابيع من التسجيل نستبدلها برقمك الحقيقي.`
          : `Starting estimate: ${formula?.tdee.toLocaleString('en-US') ?? '—'} kcal from the Mifflin-St Jeor equation, using your height, weight, age and activity. After 2–3 weeks of logging we replace it with your real, measured number.`,
      src: [SOURCES.MSJ, SOURCES.HALL],
    },
    {
      title: ar ? 'السرعة' : 'Pace',
      number: profile.goal === 'lose' ? `−${(RATE.lose * 100).toFixed(1)}% / week` : profile.goal === 'gain' ? `+${(RATE.gain * 100).toFixed(2)}% / week` : '±0',
      body:
        profile.goal === 'lose'
          ? ar
            ? 'نستهدف ٠٫٥–١٪ من وزنك أسبوعياً. أسرع من كذا يزيد خسارة العضل ويصعّب الاستمرار.'
            : 'We aim for 0.5–1% of body weight per week. Faster than that loses more muscle and is harder to stick to.'
          : profile.goal === 'gain'
            ? ar
              ? 'زيادة ٠٫٢٥–٠٫٥٪ أسبوعياً تبني عضل بدون دهون زائدة كثيرة.'
              : 'Gaining 0.25–0.5% per week builds muscle without piling on extra fat.'
            : ar
              ? 'المحافظة: نراقب الاتجاه وننبهك إذا تغيّر أكثر من ٠٫٣٪ أسبوعياً.'
              : 'Maintenance: we watch the trend and flag it if it moves more than 0.3% a week.',
      src: [SOURCES.HELMS, SOURCES.IRAKI],
    },
    {
      title: ar ? 'البروتين' : 'Protein',
      number: `${profile.protein_target_g ?? 0} g`,
      body: ar
        ? `${profile.goal === 'lose' ? '٢٫٠' : '١٫٦'} غ لكل كغ من وزن مرجعي ${Math.round(ref)} كغ. ١٫٦ غ/كغ هو الحد اللي بعده ما تزيد فائدة بناء العضل بالمتوسط، ونرفعه أثناء التنشيف لحماية العضل.`
        : `${profile.goal === 'lose' ? '2.0' : '1.6'} g per kg of a ${Math.round(ref)} kg reference weight. 1.6 g/kg is where extra protein stops adding muscle on average; we go higher while dieting to protect muscle.${ref < weight ? ' For higher body weights we use the weight at a BMI of 25, so the number isn’t inflated.' : ''}`,
      src: [SOURCES.MORTON, SOURCES.HELMS],
    },
    {
      title: ar ? 'خط الاتجاه' : 'Trend line',
      number: ar ? 'متوسط متحرك' : 'Smoothed average',
      body: ar
        ? 'وزنك اليومي يتقلب ١–٢ كغ بسبب الماء والملح والأكل. خط الاتجاه يخفف هالتقلبات عشان تشوف التغيير الحقيقي في الدهون.'
        : 'Your daily weight swings 1–2 kg from water, salt and food. The trend line smooths that out so you see the real change in body fat.',
      src: [],
    },
  ];

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 16, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1" style={{ flex: 1 }}>{t('whyTitle')}</Txt>
        <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>
      {blocks.map((b, i) => (
        <Animated.View key={b.title} entering={FadeInDown.delay(i * 80).springify()}>
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 18, gap: 8 }}>
            <Txt v="label" muted>{b.title}</Txt>
            <Txt v="h1">{b.number}</Txt>
            <Txt muted>{b.body}</Txt>
            {b.src.map((s) => (
              <Txt key={s} v="small" faint>{s}</Txt>
            ))}
          </View>
        </Animated.View>
      ))}
      <Txt v="small" faint>{t('planNote')}</Txt>
    </ScrollView>
  );
}
