// Supplements: categories with a short guide, then products and where to buy them in the UAE.
// Partner products show first with a "Partner" tag. Admins can edit everything from here.
import { Image } from 'expo-image';
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Linking, ScrollView, View } from 'react-native';
import Animated, { FadeIn } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { select } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { fetchCatalog, logTap, SuppCategory, SuppProduct } from '@/lib/supps';
import { useTheme } from '@/theme/theme';
import { Icon, IconName } from '@/ui/Icon';
import { Row, Screen } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function Supplements() {
  const { lang } = useI18n();
  const ar = lang === 'ar';
  const L = (en: string, a: string) => (ar ? a || en : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const admin = profile?.role === 'admin';
  const [cats, setCats] = useState<SuppCategory[]>([]);
  const [products, setProducts] = useState<SuppProduct[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  useFocusEffect(useCallback(() => {
    fetchCatalog().then(({ categories, products }) => {
      setCats(categories);
      setProducts(products);
      setSel((s) => s ?? categories.find((c) => c.visible)?.id ?? null);
      setLoaded(true);
    }).catch(() => setLoaded(true));
  }, []));

  const shown = cats.filter((c) => c.visible || admin);
  const cat = shown.find((c) => c.id === sel) ?? shown[0];
  const list = useMemo(() => products.filter((p) => p.category_id === cat?.id && (p.visible || admin)), [products, cat?.id, admin]);

  const open = (p: SuppProduct, label: string, url: string) => {
    logTap(p.id, label);
    Linking.openURL(url).catch(() => Alert.alert(L("Couldn't open the link", 'ما قدرنا نفتح الرابط')));
  };

  const block = (label: string, body: string) => (body ? (
    <View style={{ gap: 3 }}>
      <Txt v="label" muted>{label}</Txt>
      <Txt>{body}</Txt>
    </View>
  ) : null);

  return (
    <Screen bottomInset={60}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1" style={{ flex: 1 }}>{L('Supplements', 'المكملات')}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <Txt muted>{L('Find what fits your goal, and where to get it in the UAE.', 'لقِ اللي يناسب هدفك، ومن وين تجيبه في الإمارات.')}</Txt>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingRight: 20 }} style={{ marginHorizontal: -20, paddingLeft: 20, flexGrow: 0 }}>
        {shown.map((c) => {
          const on = c.id === cat?.id;
          return (
            <Press key={c.id} haptic={false} onPress={() => { select(); setSel(c.id); }}
              style={{ paddingHorizontal: 14, height: 38, borderRadius: 19, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: on ? theme.accent : theme.card, opacity: c.visible ? 1 : 0.5 }}>
              <Icon name={(c.icon as IconName) || 'sparkle'} size={14} color={on ? theme.onAccent : theme.muted} />
              <Txt v="bodyStrong" color={on ? theme.onAccent : theme.text} style={{ fontSize: 13 }}>{L(c.name_en, c.name_ar)}</Txt>
            </Press>
          );
        })}
      </ScrollView>

      {cat ? (
        <Animated.View key={cat.id} entering={FadeIn.duration(200)} style={{ gap: 14 }}>
          <View style={{ backgroundColor: theme.card, borderRadius: 22, padding: 18, gap: 12 }}>
            <Row style={{ justifyContent: 'space-between' }}>
              <Txt v="h2" style={{ flex: 1 }}>{L(cat.name_en, cat.name_ar)}</Txt>
              {admin ? (
                <Press onPress={() => router.push({ pathname: '/supp-edit', params: { kind: 'category', id: cat.id } })} style={{ padding: 4 }}>
                  <Txt v="small" color={theme.accent}>{L('Edit', 'تعديل')}</Txt>
                </Press>
              ) : null}
            </Row>
            {cat.tagline_en ? <Txt style={{ fontSize: 16, lineHeight: 23 }}>{L(cat.tagline_en, cat.tagline_ar)}</Txt> : null}
            {block(L('Great for', 'مناسب لـ'), L(cat.good_for_en, cat.good_for_ar))}
            {block(L('How to take it', 'طريقة الاستخدام'), L(cat.how_en, cat.how_ar))}
            {cat.note_en ? (
              <View style={{ backgroundColor: theme.cardHigh, borderRadius: 14, padding: 12, gap: 3 }}>
                <Txt v="label" muted>{L('Good to know', 'معلومة مفيدة')}</Txt>
                <Txt v="small">{L(cat.note_en, cat.note_ar)}</Txt>
              </View>
            ) : null}
            {cat.sources ? (
              <Press haptic={false} onPress={() => Alert.alert(L('Sources', 'المصادر'), cat.sources.split(' · ').join('\n\n'))} style={{ alignSelf: 'flex-start' }}>
                <Txt v="small" faint style={{ fontSize: 11 }}>{L('Sources', 'المصادر')}</Txt>
              </Press>
            ) : null}
          </View>

          <Row style={{ justifyContent: 'space-between' }}>
            <Txt v="label" muted>{L('Where to buy', 'من وين تشتري')}</Txt>
            {admin ? (
              <Press onPress={() => router.push({ pathname: '/supp-edit', params: { kind: 'product', category: cat.id } })}>
                <Txt v="bodyStrong" color={theme.accent}>{L('+ Add product', '+ أضف منتج')}</Txt>
              </Press>
            ) : null}
          </Row>

          {list.length ? list.map((p) => (
            <View key={p.id} style={{ backgroundColor: theme.card, borderRadius: 22, padding: 14, gap: 12, opacity: p.visible ? 1 : 0.5, borderWidth: p.partner ? 1 : 0, borderColor: theme.accent + '55' }}>
              <Row gap={12} style={{ alignItems: 'flex-start' }}>
                <View style={{ width: 76, height: 76, borderRadius: 16, backgroundColor: '#FFFFFF', overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }}>
                  {p.image_url ? <Image source={{ uri: p.image_url }} style={{ width: 76, height: 76 }} contentFit="contain" /> : <Icon name="pill" size={26} color="#999" />}
                </View>
                <View style={{ flex: 1, gap: 3 }}>
                  <Row gap={6} style={{ flexWrap: 'wrap' }}>
                    {p.brand ? <Txt v="small" muted>{p.brand}</Txt> : null}
                    {p.partner ? (
                      <View style={{ paddingHorizontal: 7, paddingVertical: 1, borderRadius: 6, backgroundColor: theme.cardHigh }}>
                        <Txt v="small" faint style={{ fontSize: 10, letterSpacing: 0.5 }}>{L('PARTNER', 'شريك')}</Txt>
                      </View>
                    ) : null}
                    {!p.visible ? <Txt v="small" faint style={{ fontSize: 10 }}>{L('HIDDEN', 'مخفي')}</Txt> : null}
                  </Row>
                  <Txt v="bodyStrong" style={{ fontSize: 16 }}>{p.name}</Txt>
                  {p.size_label ? <Txt v="small" faint>{p.size_label}</Txt> : null}
                  {p.blurb_en ? <Txt v="small" muted>{L(p.blurb_en, p.blurb_ar)}</Txt> : null}
                </View>
                {admin ? (
                  <Press onPress={() => router.push({ pathname: '/supp-edit', params: { kind: 'product', id: p.id } })} style={{ padding: 4 }}>
                    <Txt v="small" color={theme.accent}>{L('Edit', 'تعديل')}</Txt>
                  </Press>
                ) : null}
              </Row>
              {p.links.length ? (
                <Row gap={8} style={{ flexWrap: 'wrap' }}>
                  {p.links.map((l, i) => (
                    <Press key={i} onPress={() => open(p, l.label, l.url)}
                      style={{ paddingHorizontal: 14, height: 36, borderRadius: 18, justifyContent: 'center', backgroundColor: i === 0 ? theme.accent : theme.cardHigh }}>
                      <Txt v="bodyStrong" color={i === 0 ? theme.onAccent : theme.text} style={{ fontSize: 13 }}>{`${l.label} ↗`}</Txt>
                    </Press>
                  ))}
                </Row>
              ) : null}
            </View>
          )) : (
            <View style={{ backgroundColor: theme.card, borderRadius: 22, padding: 18 }}>
              <Txt muted>{L('Products for this category are coming soon.', 'المنتجات لهذي الفئة قريباً.')}</Txt>
            </View>
          )}

          <Txt v="small" faint style={{ fontSize: 11 }}>
            {L('General information, not medical advice. Check with your doctor if you take medication, are pregnant or have a health condition. "Partner" products are from brands that work with Habibi Gains.',
              'معلومات عامة وليست نصيحة طبية. استشر طبيبك إذا تاخذ أدوية أو حامل أو عندك حالة صحية. منتجات "شريك" من ماركات تتعاون مع Habibi Gains.')}
          </Txt>
        </Animated.View>
      ) : loaded ? <Txt muted>{L('Nothing here yet.', 'ما في شي بعد.')}</Txt> : null}

      {admin ? (
        <Press onPress={() => router.push({ pathname: '/supp-edit', params: { kind: 'category' } })} style={{ paddingVertical: 8 }}>
          <Txt v="bodyStrong" color={theme.accent}>{L('+ New category', '+ فئة جديدة')}</Txt>
        </Press>
      ) : null}
    </Screen>
  );
}
