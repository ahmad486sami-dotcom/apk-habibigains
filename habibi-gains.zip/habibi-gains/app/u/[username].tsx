// Opens from an invite link or QR: habibigains://u/<username>
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { findByUsername } from '@/lib/social';
import { useTheme } from '@/theme/theme';
import { Button } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function OpenUser() {
  const { username } = useLocalSearchParams<{ username: string }>();
  const { lang } = useI18n();
  const { theme } = useTheme();
  const [missing, setMissing] = useState(false);
  useEffect(() => {
    if (!username) return;
    findByUsername(String(username)).then((p) => {
      if (p) router.replace({ pathname: '/user/[id]', params: { id: p.id } });
      else setMissing(true);
    }).catch(() => setMissing(true));
  }, [username]);
  return (
    <View style={{ flex: 1, backgroundColor: theme.bg, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 14 }}>
      {missing ? (
        <>
          <Txt v="h3" center>{lang === 'ar' ? `ما لقينا @${username}` : `Couldn't find @${username}`}</Txt>
          <Button kind="secondary" title={lang === 'ar' ? 'رجوع' : 'Back'} onPress={() => (router.canGoBack() ? router.back() : router.replace('/'))} />
        </>
      ) : <ActivityIndicator color={theme.accent} />}
    </View>
  );
}
