// Your friend QR code + invite link, and a button to scan a friend's code.
import { router } from 'expo-router';
import React from 'react';
import { Share, View } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import { useI18n } from '@/i18n/i18n';
import { useSession } from '@/lib/session';
import { profileLink } from '@/lib/social';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function MyQr() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const u = profile?.username;
  const link = u ? profileLink(u) : '';

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg, padding: 20, gap: 16 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h2">{L('My code', 'كودي')}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      {u ? (
        <>
          <View style={{ alignItems: 'center', gap: 10, backgroundColor: '#FFFFFF', borderRadius: 28, padding: 28, alignSelf: 'center' }}>
            <Avatar url={profile?.avatar_url} name={profile?.display_name} size={64} />
            <Txt v="h3" color="#0A0B0D">{`@${u}`}</Txt>
            <QRCode value={link} size={200} color="#0A0B0D" backgroundColor="#FFFFFF" />
            <Txt v="small" color="#555">{L('Scan in Habibi Gains to add me', 'امسحه في Habibi Gains وضيفني')}</Txt>
          </View>
          <Button title={L("Scan a friend's code", 'امسح كود صديق')} icon={<Icon name="scan" size={18} color={theme.onAccent} />} onPress={() => router.replace({ pathname: '/scan', params: { mode: 'friend' } })} />
          <Button kind="secondary" title={L('Send invite link', 'أرسل رابط الدعوة')} onPress={() => Share.share({ message: L(`Add me on Habibi Gains: @${u}\n${link}`, `ضيفني على Habibi Gains: @${u}\n${link}`) })} />
        </>
      ) : (
        <>
          <Txt muted>{L('Pick an @username first so friends can find you.', 'اختر اسم مستخدم أول عشان يلقونك.')}</Txt>
          <Button title={L('Set @username', 'اختر الاسم')} onPress={() => router.replace('/profile-edit')} />
        </>
      )}
    </View>
  );
}
