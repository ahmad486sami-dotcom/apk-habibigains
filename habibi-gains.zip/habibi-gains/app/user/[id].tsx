// Someone's profile: what they chose to show you, friend actions, and their food diary if they share it.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { shiftDay, dayLabel, MEAL_LABEL } from '@/lib/day';
import { success } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { acceptBuddy, acceptRequest, askBuddy, blockUser, BuddyRow, copyToMyDiary, endBuddy, friendDiary, getProfileCard, listBuddies, nudge, NUDGES, ProfileCard, removeFriend, reportUser, REPORT_REASONS, sendRequest } from '@/lib/social';
import { warn } from '@/lib/haptics';
import { todayISO } from '@/lib/supabase';
import { fmtWeight, unitsOf } from '@/lib/units';
import { useTheme } from '@/theme/theme';
import { Avatar, Stat } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function UserProfile() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const units = unitsOf(profile);
  const [p, setP] = useState<ProfileCard | null>(null);
  const [day, setDay] = useState(todayISO());
  const [diary, setDiary] = useState<any[]>([]);
  const [buddy, setBuddy] = useState<BuddyRow | null>(null);
  const [nudged, setNudged] = useState(false);

  const load = useCallback(() => {
    if (!id) return;
    getProfileCard(id).then(setP).catch(() => {});
    listBuddies().then((b) => setBuddy(b.find((x) => x.id === id) ?? null)).catch(() => {});
  }, [id]);
  useEffect(load, [load]);
  useEffect(() => {
    if (p?.diary && id) friendDiary(id, day).then(setDiary).catch(() => setDiary([]));
  }, [p?.diary, id, day]);

  if (!p) return <View style={{ flex: 1, backgroundColor: theme.bg }} />;
  const name = p.display_name ?? p.username ?? '';
  const total = diary.reduce((a, l) => a + Number(l.kcal), 0);
  const act = async (fn: () => Promise<void>) => { await fn().catch(() => {}); success(); load(); };
  const isFriend = p.relation === 'friend';

  const sendNudge = () =>
    Alert.alert(L(`Nudge ${name}`, `انكز ${name}`), L('They get it in their inbox. Once a day per friend.', 'توصله في الإشعارات. مرة باليوم لكل صديق.'), [
      ...NUDGES.map((n) => ({ text: L(n.en, n.ar), onPress: async () => {
        try {
          const ok = await nudge(p.id, L(n.en, n.ar));
          if (ok) { success(); setNudged(true); } else { warn(); Alert.alert(L('Already nudged today', 'نكزته اليوم'), L('Try again tomorrow.', 'جرب بكرة.')); }
        } catch { warn(); }
      } })),
      { text: L('Cancel', 'إلغاء'), style: 'cancel' as const },
    ]);

  const addToMine = (l: any) =>
    Alert.alert(L(`Add "${l.name}" to your diary?`, `تضيف "${l.name}" ليومياتك؟`), `${Math.round(l.kcal)} kcal`, [
      ...(['breakfast', 'lunch', 'dinner', 'snack'] as const).map((m) => ({
        text: L(MEAL_LABEL[m]?.en ?? m, MEAL_LABEL[m]?.ar ?? m),
        onPress: async () => { try { await copyToMyDiary(l, m); success(); } catch { warn(); } },
      })),
      { text: L('Cancel', 'إلغاء'), style: 'cancel' as const },
    ]);

  const more = () =>
    Alert.alert(name, '', [
      ...(isFriend ? [{ text: L('Remove friend', 'إزالة الصديق'), onPress: () => act(() => removeFriend(p.id)) }] : []),
      { text: L('Report', 'إبلاغ'), onPress: () => Alert.alert(L('Why are you reporting?', 'سبب البلاغ؟'), '', [
        ...REPORT_REASONS.map((r) => ({ text: L(r.en, r.ar), onPress: async () => { await reportUser(p.id, r.value).catch(() => {}); success(); Alert.alert(L('Thanks, we will look at it.', 'شكراً، بنراجعه.')); } })),
        { text: L('Cancel', 'إلغاء'), style: 'cancel' as const },
      ]) },
      { text: L('Block', 'حظر'), style: 'destructive' as const, onPress: () => Alert.alert(L(`Block ${name}?`, `تحظر ${name}؟`), L("They won't be able to find you, see your profile or message you. They are not told.", 'ما بيقدر يلقاك أو يشوف ملفك. وما بينبلغ.'), [
        { text: L('Cancel', 'إلغاء'), style: 'cancel' as const },
        { text: L('Block', 'حظر'), style: 'destructive' as const, onPress: async () => { await blockUser(p.id).catch(() => {}); success(); router.back(); } },
      ]) },
      { text: L('Cancel', 'إلغاء'), style: 'cancel' as const },
    ]);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        {p.relation !== 'self' ? <Press onPress={more} style={{ padding: 6 }}><Txt v="h3">•••</Txt></Press> : <View />}
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <View style={{ alignItems: 'center', gap: 6 }}>
        <Avatar url={p.avatar_url} name={name} size={96} />
        <Txt v="h2">{name}</Txt>
        {p.username ? <Txt v="small" muted>{`@${p.username}`}</Txt> : null}
        {p.gym ? <Txt v="small" color={theme.accent}>{p.gym}</Txt> : null}
        {p.bio ? <Txt center>{p.bio}</Txt> : null}
      </View>
      <Card>
        <Row>
          <Stat value={p.streak != null ? String(p.streak) : '—'} label={L('day streak', 'يوم متتالي')} />
          <Stat value={p.kg_lost != null ? fmtWeight(Math.max(0, p.kg_lost), units) : '—'} label={L('lost', 'خسر')} />
          <Stat value={p.steps_today != null ? p.steps_today.toLocaleString('en-US') : '—'} label={L('steps today', 'خطوات اليوم')} />
        </Row>
      </Card>

      {p.relation === 'none' ? <Button title={L('Add friend', 'أضف صديق')} onPress={() => act(() => sendRequest(p.id))} /> : null}
      {p.relation === 'requested' ? <Button kind="secondary" title={L('Request sent · Cancel', 'تم الطلب · إلغاء')} onPress={() => act(() => removeFriend(p.id))} /> : null}
      {p.relation === 'incoming' ? <Button title={L('Accept friend request', 'قبول الطلب')} onPress={() => act(() => acceptRequest(p.id))} /> : null}
      {isFriend ? (
        <Row gap={10}>
          <View style={{ flex: 1 }}><Button kind="secondary" disabled={nudged} title={nudged ? L('Nudged ✓', 'تم النكز ✓') : L('👉 Nudge', '👉 انكز')} onPress={sendNudge} /></View>
          <View style={{ flex: 1 }}>
            {!buddy ? <Button kind="secondary" title={L('Ask to be buddies', 'اطلب شراكة')} onPress={async () => {
              try { await askBuddy(p.id); success(); load(); } catch (e: any) { warn(); Alert.alert(e?.message === 'max3' ? L('You already have 3 buddies', 'عندك ٣ شركاء') : L('Could not send', 'ما انرسل')); }
            }} />
            : buddy.status === 'incoming' ? <Button title={L('Accept buddy', 'قبول الشراكة')} onPress={() => act(() => acceptBuddy(p.id))} />
            : buddy.status === 'outgoing' ? <Button kind="secondary" title={L('Buddy request sent', 'تم طلب الشراكة')} onPress={() => act(() => endBuddy(p.id))} />
            : <Button kind="secondary" title={L('Buddies ✓', 'شركاء ✓')} onPress={() => Alert.alert(L('End buddy?', 'تنهي الشراكة؟'), '', [{ text: L('Cancel', 'إلغاء') }, { text: L('End', 'إنهاء'), style: 'destructive', onPress: () => act(() => endBuddy(p.id)) }])} />}
          </View>
        </Row>
      ) : null}

      {p.week ? (
        <Card>
          <Txt v="label" muted>{L('Last 7 days', 'آخر ٧ أيام')}</Txt>
          <Row style={{ justifyContent: 'space-between' }}>
            {Array.from({ length: 7 }, (_, i) => shiftDay(todayISO(), i - 6)).map((d) => {
              const k = p.week!.find((w) => w.day === d)?.kcal ?? 0;
              const over = p.calorie_target && k > p.calorie_target;
              return <View key={d} style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: !k ? theme.cardHigh : over ? '#FF7A59' : theme.accent }} />;
            })}
          </Row>
        </Card>
      ) : null}

      {p.diary ? (
        <>
          <Row style={{ justifyContent: 'space-between', marginTop: 4 }}>
            <Press onPress={() => setDay(shiftDay(day, -1))} style={{ padding: 6 }}><Txt v="h3">‹</Txt></Press>
            <Txt v="bodyStrong">{`${L('Food diary', 'اليوميات')} · ${dayLabel(day, lang)}`}</Txt>
            <Press onPress={() => day < todayISO() && setDay(shiftDay(day, 1))} style={{ padding: 6 }}><Txt v="h3" color={day < todayISO() ? theme.text : theme.faint}>›</Txt></Press>
          </Row>
          <Card>
            {diary.length ? diary.map((l) => (
              <Press key={l.id} onPress={() => addToMine(l)} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Txt>{l.name}</Txt>
                  <Txt v="small" faint>{L(MEAL_LABEL[l.meal as keyof typeof MEAL_LABEL]?.en ?? l.meal, MEAL_LABEL[l.meal as keyof typeof MEAL_LABEL]?.ar ?? l.meal)}</Txt>
                </View>
                <Txt v="bodyStrong">{Math.round(l.kcal)}</Txt>
                <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}><Icon name="plus" size={14} /></View>
              </Press>
            )) : <Txt muted>{L('Nothing logged this day.', 'ما سجل شي هاليوم.')}</Txt>}
            {diary.length ? <Txt v="small" muted>{`${L('Total', 'المجموع')}: ${Math.round(total)} kcal · ${L('tap + to add one to your diary', 'اضغط + تضيفه ليومياتك')}`}</Txt> : null}
          </Card>
        </>
      ) : p.relation === 'friend' ? (
        <Txt v="small" faint center>{L(`${name} keeps their food diary private.`, 'يومياته خاصة.')}</Txt>
      ) : null}

    </ScrollView>
  );
}
