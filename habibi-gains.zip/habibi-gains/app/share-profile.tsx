// Old route: opens the share studio on the profile card design.
import { router } from 'expo-router';
import { useEffect } from 'react';

export default function ShareProfile() {
  useEffect(() => {
    router.replace({ pathname: '/share', params: { design: 'profile' } });
  }, []);
  return null;
}
