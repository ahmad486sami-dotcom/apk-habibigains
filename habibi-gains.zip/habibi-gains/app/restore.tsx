// Shown when someone signs in to an account they deleted less than 30 days ago.
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { deleteAccount, restoreAccount } from '@/lib/auth';
import { success, warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Logo } from '@/ui/Graphics';
import { Button } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function Restore() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const { profile, refreshProfile } = useSession();
  const [busy, setBusy] = useState<'restore' | 'now' | null>(null);
  const wipeOn = profile?.deleted_at ? new Date(new Date(profile.deleted_at).getTime() + 30 * 86_400_000) : null;
  const dateText = wipeOn?.toLocaleDateString(lang === 'ar' ? 'ar-AE' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) ?? '';

  const restore = async () => {
    setBusy('restore');
    try {
      await restoreAccount();
      await refreshProfile();
      success();
      router.replace('/');
    } catch {
      warn();
      Alert.alert(L('Could not restore', 'ما قدرنا نرجعه'), L('Check your connection and try again.', 'تأكد من الإنترنت وحاول مرة ثانية.'));
    } finally { setBusy(null); }
  };

  const deleteNow = () =>
    Alert.alert(L('Delete everything now?', 'تحذف كل شي الحين؟'), L('This cannot be undone.', 'ما يمكن التراجع عنه.'), [
      { text: L('Cancel', 'إلغاء'), style: 'cancel' },
      { text: L('Delete now', 'احذف الحين'), style: 'destructive', onPress: async () => {
        setBusy('now');
        try { await deleteAccount('now'); router.replace('/'); } catch { warn(); } finally { setBusy(null); }
      } },
    ]);

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg, paddingTop: insets.top + 40, paddingBottom: insets.bottom + 24, paddingHorizontal: 24, gap: 18 }}>
      <Logo width={96} />
      <Txt v="hero">{L('Welcome back', 'أهلاً من جديد')}</Txt>
      <Txt muted style={{ fontSize: 17, lineHeight: 24 }}>
        {L(`You deleted this account. It's switched off and will be permanently deleted on ${dateText}.`, `حذفت هذا الحساب. هو موقّف حالياً وبينحذف نهائياً في ${dateText}.`)}
      </Txt>
      <Txt muted style={{ fontSize: 17, lineHeight: 24 }}>
        {L('Restore it to get everything back: your logs, weight, photos, friends and @username.', 'رجّعه وترجع لك كل شي: سجلاتك، وزنك، صورك، أصحابك واسم المستخدم.')}
      </Txt>
      <View style={{ flex: 1 }} />
      <Button title={L('Restore my account', 'رجّع حسابي')} loading={busy === 'restore'} onPress={restore} />
      <Button kind="ghost" title={L('Sign out', 'تسجيل خروج')} onPress={async () => { await supabase.auth.signOut(); router.replace('/'); }} />
      <Button kind="danger" title={L('Delete everything now', 'احذف كل شي الحين')} loading={busy === 'now'} onPress={deleteNow} />
    </View>
  );
}
