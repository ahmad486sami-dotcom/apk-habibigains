// Step-by-step setup that ends with a live, animated plan built from the user's numbers.
import { router } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import Animated, { FadeIn, FadeInRight, FadeOutLeft, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { logWeight } from '@/lib/data';
import { success } from '@/lib/haptics';
import { Activity, calcTargets, Goal, Sex } from '@/lib/nutrition';
import { ftInToCm, toKg, Units, unitsOf } from '@/lib/units';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { Ring, Ticker } from '@/ui/Graphics';
import { Chips, Field, Option } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const STEPS = 6;

export default function Onboarding() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const { profile, updateProfile, session } = useSession();
  const [step, setStep] = useState(0);
  const [name, setName] = useState(profile?.display_name ?? '');
  const [goal, setGoal] = useState<Goal>('lose');
  const [sex, setSex] = useState<Sex>('male');
  const [birthYear, setBirthYear] = useState('');
  const [height, setHeight] = useState('');
  const [inches, setInches] = useState('');
  const [units, setUnits] = useState<Units>(unitsOf(profile));
  const [weight, setWeight] = useState('');
  const [goalWeight, setGoalWeight] = useState('');
  const [activity, setActivity] = useState<Activity>('moderate');
  const [training, setTraining] = useState('18:00');
  const [saving, setSaving] = useState(false);

  const num = (v: string) => Number(v.replace(',', '.'));
  // Inputs follow the chosen units; everything is saved in kg and cm.
  const nums = {
    by: Number(birthYear),
    h: units.height === 'ft' ? ftInToCm(num(height), num(inches) || 0) : num(height),
    w: Math.round(toKg(num(weight), units) * 10) / 10,
    gw: Math.round(toKg(num(goalWeight), units) * 10) / 10,
  };
  const bodyValid =
    nums.by >= 1930 && nums.by <= new Date().getFullYear() - 13 && nums.h >= 120 && nums.h <= 230 && nums.w >= 30 && nums.w <= 300 && nums.gw >= 30 && nums.gw <= 300;

  const plan = useMemo(
    () => (bodyValid ? calcTargets({ sex, birthYear: nums.by, heightCm: nums.h, weightKg: nums.w, goal, activity }) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [bodyValid, sex, birthYear, height, weight, goal, activity],
  );

  const canNext = [name.trim().length > 0, true, bodyValid, true, true, true][step];

  const finish = async () => {
    if (!plan || !session) return;
    setSaving(true);
    try {
      await updateProfile({
        display_name: name.trim(),
        goal,
        sex,
        birth_year: nums.by,
        height_cm: nums.h,
        start_weight_kg: nums.w,
        goal_weight_kg: nums.gw,
        activity,
        training_time: training === 'none' ? null : training,
        calorie_target: plan.kcal,
        units,
        protein_target_g: plan.protein,
      });
      await logWeight(session.user.id, nums.w);
      success();
      router.replace('/(tabs)');
    } finally {
      setSaving(false);
    }
  };

  const prog = useSharedValue(1 / STEPS);
  useEffect(() => {
    prog.value = withSpring((step + 1) / STEPS, { damping: 20 });
  }, [step, prog]);
  const progressStyle = useAnimatedStyle(() => ({ width: `${prog.value * 100}%` }));

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <View style={{ paddingTop: insets.top + 12, paddingHorizontal: 24, gap: 18 }}>
        <View style={{ height: 4, backgroundColor: theme.cardHigh, borderRadius: 2, overflow: 'hidden' }}>
          <Animated.View style={[{ height: 4, backgroundColor: theme.accent }, progressStyle]} />
        </View>
        {step > 0 ? (
          <Press onPress={() => setStep(step - 1)} style={{ alignSelf: 'flex-start', paddingVertical: 4 }}>
            <Txt muted>‹</Txt>
          </Press>
        ) : (
          <View style={{ height: 30 }} />
        )}
      </View>

      <ScrollView contentContainerStyle={{ padding: 24, gap: 14, flexGrow: 1 }} keyboardShouldPersistTaps="handled">
        <Animated.View key={step} entering={FadeInRight.springify().damping(18)} exiting={FadeOutLeft.duration(150)} style={{ gap: 14 }}>
          {step === 0 && (
            <>
              <Txt v="h1">{t('obName')}</Txt>
              <Field value={name} onChangeText={setName} placeholder={t('obNamePlaceholder')} autoFocus />
            </>
          )}
          {step === 1 && (
            <>
              <Txt v="h1">{t('obGoal')}</Txt>
              <Option title={t('goalLose')} selected={goal === 'lose'} onPress={() => setGoal('lose')} />
              <Option title={t('goalMaintain')} selected={goal === 'maintain'} onPress={() => setGoal('maintain')} />
              <Option title={t('goalGain')} selected={goal === 'gain'} onPress={() => setGoal('gain')} />
            </>
          )}
          {step === 2 && (
            <>
              <Txt v="h1">{t('obBody')}</Txt>
              <Txt v="label" muted>{t('sex')}</Txt>
              <Chips value={sex} onChange={setSex} options={[{ value: 'male', label: t('male') }, { value: 'female', label: t('female') }]} />
              <Field label={t('birthYear')} value={birthYear} onChangeText={setBirthYear} keyboardType="number-pad" placeholder="2002" maxLength={4} />
              <Txt v="label" muted>{lang === 'ar' ? 'الوحدات' : 'Units'}</Txt>
              <Chips value={units.weight} onChange={(v) => setUnits({ ...units, weight: v })} options={[{ value: 'kg', label: 'kg' }, { value: 'lb', label: 'lb' }]} />
              <Chips value={units.height} onChange={(v) => setUnits({ ...units, height: v })} options={[{ value: 'cm', label: 'cm' }, { value: 'ft', label: 'ft / in' }]} />
              <Chips value={units.water} onChange={(v) => setUnits({ ...units, water: v })} options={[{ value: 'l', label: lang === 'ar' ? 'لتر' : 'Litres' }, { value: 'oz', label: 'fl oz' }]} />
              {units.height === 'ft' ? (
                <View style={{ flexDirection: 'row', gap: 10 }}>
                  <View style={{ flex: 1 }}><Field label={`${t('height')} (ft)`} value={height} onChangeText={setHeight} keyboardType="number-pad" placeholder="5" /></View>
                  <View style={{ flex: 1 }}><Field label="in" value={inches} onChangeText={setInches} keyboardType="number-pad" placeholder="10" /></View>
                </View>
              ) : (
                <Field label={`${t('height')} (cm)`} value={height} onChangeText={setHeight} keyboardType="decimal-pad" placeholder="178" />
              )}
              <Field label={`${t('weight')} (${units.weight})`} value={weight} onChangeText={setWeight} keyboardType="decimal-pad" placeholder={units.weight === 'lb' ? '190' : '86.5'} />
              <Field label={`${t('goalWeight')} (${units.weight})`} value={goalWeight} onChangeText={setGoalWeight} keyboardType="decimal-pad" placeholder={units.weight === 'lb' ? '172' : '78'} />
            </>
          )}
          {step === 3 && (
            <>
              <Txt v="h1">{t('obActivity')}</Txt>
              <Option title={t('actLow')} selected={activity === 'low'} onPress={() => setActivity('low')} />
              <Option title={t('actLight')} selected={activity === 'light'} onPress={() => setActivity('light')} />
              <Option title={t('actModerate')} selected={activity === 'moderate'} onPress={() => setActivity('moderate')} />
              <Option title={t('actHigh')} selected={activity === 'high'} onPress={() => setActivity('high')} />
            </>
          )}
          {step === 4 && (
            <>
              <Txt v="h1">{t('obTraining')}</Txt>
              <Txt muted>{t('obTrainingSub')}</Txt>
              <Chips
                value={training}
                onChange={setTraining}
                options={[
                  { value: '06:00', label: '6 am' },
                  { value: '12:00', label: '12 pm' },
                  { value: '18:00', label: '6 pm' },
                  { value: '21:00', label: '9 pm' },
                  { value: 'none', label: t('noTrainYet') },
                ]}
              />
            </>
          )}
          {step === 5 && plan && (
            <Animated.View entering={FadeIn.duration(400)} style={{ gap: 18, alignItems: 'center' }}>
              <Txt v="h1" center>{t('obPlan')}</Txt>
              <Ring size={210} stroke={18} progress={1}>
                <Ticker value={plan.kcal} v="hero" />
                <Txt v="small" muted>{t('dailyCalories')}</Txt>
              </Ring>
              <View style={{ flexDirection: 'row', gap: 12, alignSelf: 'stretch' }}>
                <Stat label={t('dailyProtein')} value={`${plan.protein} g`} />
                <Stat label={t('perWeek')} value={`${plan.weeklyChangeKg > 0 ? '+' : ''}${plan.weeklyChangeKg} kg`} />
              </View>
              <Txt v="small" muted center>{t('planBasis')}</Txt>
              <Txt v="small" faint center>{t('planNote')}</Txt>
            </Animated.View>
          )}
        </Animated.View>
      </ScrollView>

      <View style={{ paddingHorizontal: 24, paddingBottom: insets.bottom + 16 }}>
        {step < STEPS - 1 ? (
          <Button title={t('next')} disabled={!canNext} onPress={() => setStep(step + 1)} />
        ) : (
          <Button title={t('letsGo')} loading={saving} onPress={finish} />
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  const { theme } = useTheme();
  return (
    <View style={{ flex: 1, backgroundColor: theme.card, borderRadius: 20, padding: 16, gap: 4 }}>
      <Txt v="h2">{value}</Txt>
      <Txt v="small" muted>{label}</Txt>
    </View>
  );
}
