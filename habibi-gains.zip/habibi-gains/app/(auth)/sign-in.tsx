import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { AuthError, resetPassword, sendEmailCode, signInWithPassword, signUpWithPassword, verifyEmail } from '@/lib/auth';
import { success, warn } from '@/lib/haptics';
import { useTheme } from '@/theme/theme';
import { Logo } from '@/ui/Graphics';
import { Chips, Field } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function SignIn() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const [mode, setMode] = useState<'create' | 'signin' | 'verify' | 'forgot' | 'reset'>('create');
  const [code, setCode] = useState('');
  const [resendIn, setResendIn] = useState(0);
  const [note, setNote] = useState('');
  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const emailOk = /^\S+@\S+\.\S+$/.test(email.trim());
  const codeOk = /^\d{6}$/.test(code.trim());
  const ready =
    mode === 'verify' ? codeOk
    : mode === 'forgot' ? emailOk
    : mode === 'reset' ? codeOk && password.length >= 8
    : emailOk && password.length >= 8 && (mode === 'signin' || name.trim().length > 0);
  const codeMode = mode === 'verify' || mode === 'reset';

  const messages: Record<AuthError['code'], string> = {
    email_taken: L('That email already has an account. Sign in instead.', 'هذا الإيميل عنده حساب. سجّل دخول بدلاً من ذلك.'),
    invalid_email: L('Please check your email.', 'تأكد من الإيميل.'),
    weak_password: L('Password needs at least 8 characters.', 'كلمة المرور لازم ٨ أحرف على الأقل.'),
    wrong_password: L('Email or password is wrong.', 'الإيميل أو كلمة المرور غلط.'),
    network: L('No connection. Check your internet and try again.', 'ما في اتصال. تأكد من الإنترنت وحاول مرة ثانية.'),
    failed: L('Something went wrong. Please try again.', 'صار خطأ. حاول مرة ثانية.'),
    unverified: L('Confirm your email first. We sent you a code.', 'أكّد إيميلك أول. أرسلنا لك رمز.'),
    wrong_code: L("That code isn't right. Check the email and try again.", 'الرمز غلط. تأكد من الإيميل وحاول مرة ثانية.'),
    expired: L('That code has expired. Tap "Send a new code".', 'الرمز انتهى. اضغط "أرسل رمز جديد".'),
    too_many_tries: L('Too many wrong tries. Tap "Send a new code".', 'محاولات كثيرة غلط. اضغط "أرسل رمز جديد".'),
    wait: L('Wait a minute before asking for another code.', 'انتظر دقيقة قبل ما تطلب رمز ثاني.'),
    too_many: L('Too many codes asked for. Try again in an hour.', 'طلبت رموز كثيرة. حاول بعد ساعة.'),
    email_not_set_up: L('Password reset is not switched on yet. Contact support.', 'استعادة كلمة المرور مو مفعّلة بعد.'),
  };

  const go = (m: typeof mode) => { setMode(m); setError(''); setNote(''); setCode(''); };
  const resend = async (purpose: 'verify' | 'reset') => {
    setError('');
    try {
      await sendEmailCode(email, purpose, lang);
      setResendIn(60);
      setNote(L(`New code sent to ${email.trim()}.`, `أرسلنا رمز جديد إلى ${email.trim()}.`));
    } catch (e) {
      setError(messages[e instanceof AuthError ? e.code : 'failed']);
    }
  };

  const submit = async () => {
    setBusy(true);
    setError('');
    try {
      if (mode === 'create') {
        if ((await signUpWithPassword(name, email, password, lang)) === 'verify') {
          go('verify');
          setResendIn(60);
          setNote(L(`We sent a 6-digit code to ${email.trim()}.`, `أرسلنا رمز من ٦ أرقام إلى ${email.trim()}.`));
          return;
        }
      } else if (mode === 'signin') await signInWithPassword(email, password);
      else if (mode === 'verify') await verifyEmail(email, code, password);
      else if (mode === 'forgot') {
        await sendEmailCode(email, 'reset', lang);
        go('reset');
        setPassword('');
        setResendIn(60);
        setNote(L(`If ${email.trim()} has an account, a 6-digit code is on its way.`, `إذا ${email.trim()} عنده حساب، الرمز في الطريق.`));
        return;
      } else if (mode === 'reset') await resetPassword(email, code, password);
      success();
      router.replace('/');
    } catch (e) {
      warn();
      const c = e instanceof AuthError ? e.code : 'failed';
      if (c === 'unverified') {
        go('verify');
        sendEmailCode(email, 'verify', lang).then(() => setResendIn(60), () => {});
        setNote(L(`Confirm your email first. We sent a code to ${email.trim()}.`, `أكّد إيميلك أول. أرسلنا رمز إلى ${email.trim()}.`));
        return;
      }
      setError(messages[c]);
      if (c === 'email_taken') setMode('signin');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ flexGrow: 1, paddingTop: insets.top + 36, paddingBottom: insets.bottom + 24, paddingHorizontal: 24, gap: 22 }}
      >
        <Animated.View entering={FadeInDown.springify()} style={{ gap: 18 }}>
          <Logo width={104} />
          <Txt v="hero">
            {mode === 'create' ? L('Create your account', 'أنشئ حسابك')
              : mode === 'signin' ? L('Welcome back', 'أهلاً من جديد')
              : mode === 'verify' ? L('Check your email', 'شيّك إيميلك')
              : mode === 'forgot' ? L('Forgot password', 'نسيت كلمة المرور')
              : L('New password', 'كلمة مرور جديدة')}
          </Txt>
        </Animated.View>

        {mode === 'create' || mode === 'signin' ? <Chips
          value={mode}
          onChange={(m) => {
            setMode(m);
            setError('');
          }}
          options={[
            { value: 'create', label: L('New account', 'حساب جديد') },
            { value: 'signin', label: L('Sign in', 'تسجيل دخول') },
          ]}
        /> : (
          <Press onPress={() => go('signin')} style={{ alignSelf: 'flex-start', paddingVertical: 4 }}>
            <Txt v="bodyStrong" color={theme.accent}>{L('‹ Back to sign in', '‹ رجوع لتسجيل الدخول')}</Txt>
          </Press>
        )}

        <View style={{ gap: 12 }}>
          {note ? <Txt muted>{note}</Txt> : null}
          {codeMode ? (
            <>
              <Field
                label={L('6-digit code', 'الرمز (٦ أرقام)')}
                value={code}
                onChangeText={(v) => setCode(v.replace(/\D/g, '').slice(0, 6))}
                placeholder="123456"
                keyboardType="number-pad"
                textContentType="oneTimeCode"
                autoComplete="one-time-code"
                maxLength={6}
                autoFocus
                style={{ fontSize: 28, letterSpacing: 10, textAlign: 'center' }}
              />
              <Press disabled={resendIn > 0} onPress={() => resend(mode === 'reset' ? 'reset' : 'verify')} style={{ paddingVertical: 4 }}>
                <Txt v="small" color={resendIn > 0 ? theme.faint : theme.accent}>
                  {resendIn > 0 ? L(`Send a new code in ${resendIn}s`, `رمز جديد بعد ${resendIn} ث`) : L('Send a new code', 'أرسل رمز جديد')}
                </Txt>
              </Press>
              <Txt v="small" faint>{L("Can't find it? Check Junk / Spam.", 'ما لقيته؟ شيّك البريد المزعج.')}</Txt>
            </>
          ) : null}
          {mode === 'create' ? (
            <Animated.View entering={FadeIn}>
              <Field label={L('Name', 'الاسم')} value={name} onChangeText={setName} placeholder={L('Your first name', 'اسمك')} autoComplete="name" textContentType="givenName" maxLength={60} />
            </Animated.View>
          ) : null}
          {codeMode ? null : <Field
            label={L('Email', 'الإيميل')}
            value={email}
            onChangeText={setEmail}
            placeholder="you@email.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="email"
            textContentType="emailAddress"
          />}
          {mode === 'verify' || mode === 'forgot' ? null : <View>
            <Field
              label={mode === 'reset' ? L('New password', 'كلمة المرور الجديدة') : L('Password', 'كلمة المرور')}
              value={password}
              onChangeText={setPassword}
              placeholder={L('At least 8 characters', '٨ أحرف على الأقل')}
              secureTextEntry={!show}
              autoCapitalize="none"
              autoCorrect={false}
              autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
              textContentType={mode === 'signin' ? 'password' : 'newPassword'}
              onSubmitEditing={() => ready && submit()}
            />
            <Press onPress={() => setShow(!show)} style={{ position: 'absolute', right: 14, bottom: 16, padding: 4 }}>
              <Txt v="small" muted>{show ? L('Hide', 'إخفاء') : L('Show', 'إظهار')}</Txt>
            </Press>
          </View>}
          {mode === 'signin' ? (
            <Press onPress={() => go('forgot')} style={{ alignSelf: 'flex-end', paddingVertical: 4 }}>
              <Txt v="small" color={theme.accent}>{L('Forgot password?', 'نسيت كلمة المرور؟')}</Txt>
            </Press>
          ) : null}
          {error ? (
            <Animated.View entering={FadeIn}>
              <Txt color={theme.danger}>{error}</Txt>
            </Animated.View>
          ) : null}
        </View>

        <View style={{ flex: 1 }} />

        <View style={{ gap: 12 }}>
          <Button
            title={mode === 'create' ? L('Create account', 'إنشاء الحساب')
              : mode === 'signin' ? L('Sign in', 'دخول')
              : mode === 'verify' ? L('Confirm email', 'تأكيد الإيميل')
              : mode === 'forgot' ? L('Send me a code', 'أرسل لي رمز')
              : L('Save new password', 'احفظ كلمة المرور')}
            disabled={!ready}
            loading={busy}
            onPress={submit}
          />
          <Txt v="small" faint center style={{ paddingTop: 4 }}>
            {L('By continuing you agree to the ', 'بالمتابعة أنت توافق على ')}
            <Txt v="small" color={theme.accent} onPress={() => router.push({ pathname: '/legal', params: { doc: 'terms' } })}>{L('Terms of Use', 'شروط الاستخدام')}</Txt>
            {L(' and ', ' و')}
            <Txt v="small" color={theme.accent} onPress={() => router.push({ pathname: '/legal', params: { doc: 'privacy' } })}>{L('Privacy Policy', 'سياسة الخصوصية')}</Txt>
            .
          </Txt>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
