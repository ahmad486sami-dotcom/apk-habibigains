// Edit profile: photo, name, @username, bio, gym, phone (to be found by contacts) and who can see each item.
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Switch, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { success, warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { supabase } from '@/lib/supabase';
import { searchPeople, DEFAULT_PRIVACY, FIELD_LABEL, FriendRow, getAllowList, hashPhone, listFriends, Privacy, PRIVACY_FIELDS, setAllowed, UAE_GYMS, uploadAvatar, Visibility } from '@/lib/social';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function ProfileEdit() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile, updateProfile } = useSession();
  const [name, setName] = useState(profile?.display_name ?? '');
  const [username, setUsername] = useState(profile?.username ?? '');
  const [bio, setBio] = useState(profile?.bio ?? '');
  const [gym, setGym] = useState(profile?.gym ?? '');
  const [otherGym, setOtherGym] = useState(profile?.gym && !UAE_GYMS.includes(profile.gym) ? profile.gym : '');
  const [phone, setPhone] = useState('');
  const [findable, setFindable] = useState(!!profile?.findable_by_contacts);
  const [avatar, setAvatar] = useState(profile?.avatar_url ?? null);
  const [privacy, setPrivacy] = useState<Privacy>({ ...DEFAULT_PRIVACY, ...((profile?.privacy as Privacy) ?? {}) });
  const [friends, setFriends] = useState<FriendRow[]>([]);
  const [allowed, setAllowedState] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [nameState, setNameState] = useState<'idle' | 'checking' | 'free' | 'taken' | 'invalid' | 'needs_letter'>('idle');

  // Live check: is this @username free? (The database also blocks duplicates, so two people can never share one.)
  useEffect(() => {
    const u = username.trim().toLowerCase().replace(/^@/, '');
    if (!u || u === (profile?.username ?? '')) return setNameState('idle');
    if (!/^[a-z0-9_.]{3,20}$/.test(u)) return setNameState('invalid');
    setNameState('checking');
    const h = setTimeout(() => {
      // Server decides: taken, reserved, numbers-only, or free.
      supabase.rpc('username_status', { u }).then(({ data, error }) => {
        if (error) return setNameState('idle');
        setNameState((['free', 'taken', 'invalid', 'needs_letter'].includes(data as string) ? data : 'idle') as typeof nameState);
      }, () => setNameState('idle'));
    }, 350);
    return () => clearTimeout(h);
  }, [username, profile?.username]);

  useEffect(() => {
    listFriends().then((f) => setFriends(f.filter((x) => x.status === 'accepted'))).catch(() => {});
    getAllowList().then(setAllowedState).catch(() => {});
  }, []);

  const pickPhoto = async () => {
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, aspect: [1, 1], quality: 0.7 });
    if (r.canceled || !r.assets?.[0]) return;
    try {
      setAvatar(r.assets[0].uri);
      const url = await uploadAvatar(r.assets[0].uri);
      setAvatar(url);
      await updateProfile({ avatar_url: url });
      success();
    } catch {
      warn();
      Alert.alert(L('Photo not saved', 'لم تُحفظ الصورة'));
    }
  };

  const save = async () => {
    const u = username.trim().toLowerCase().replace(/^@/, '');
    if (u && !/^[a-z0-9_.]{3,20}$/.test(u)) {
      Alert.alert(L('Username', 'اسم المستخدم'), L('3–20 characters: letters, numbers, _ and . only.', '٣–٢٠ حرف: أحرف إنجليزية وأرقام و _ و . فقط.'));
      return;
    }
    setBusy(true);
    try {
      const patch: Record<string, unknown> = {
        display_name: name.trim() || null,
        username: u || null,
        bio: bio.trim().slice(0, 140) || null,
        gym: (gym === 'Other' ? otherGym.trim() : gym) || null,
        privacy,
        findable_by_contacts: findable,
      };
      if (phone.trim()) patch.phone_hash = await hashPhone(phone);
      await updateProfile(patch as any);
      success();
      router.back();
    } catch (e: any) {
      warn();
      Alert.alert(L('Not saved', 'لم يتم الحفظ'), String(e?.message ?? '').includes('username') || String(e?.message ?? '').includes('duplicate') ? L('That @username is taken.', 'اسم المستخدم مستخدم.') : L('Try again.', 'حاول مرة ثانية.'));
    } finally {
      setBusy(false);
    }
  };

  const levels: { value: Visibility; label: string }[] = [
    { value: 'everyone', label: L('Everyone', 'الكل') },
    { value: 'friends', label: L('Friends', 'الأصحاب') },
    { value: 'specific', label: L('Specific', 'محددين') },
    { value: 'only_me', label: L('Only me', 'أنا فقط') },
  ];
  const usesSpecific = Object.values(privacy).includes('specific');

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{L('Edit profile', 'تعديل الحساب')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
        </Row>
        <Press onPress={pickPhoto} style={{ alignSelf: 'center', alignItems: 'center', gap: 8 }}>
          <Avatar url={avatar} name={name} size={96} />
          <Txt v="bodyStrong" color={theme.accent}>{L('Change photo', 'تغيير الصورة')}</Txt>
        </Press>
        <Field label={L('Name', 'الاسم')} value={name} onChangeText={setName} maxLength={40} />
        <Field label={L('@username (your ID)', '@اسم المستخدم')} value={username} onChangeText={(v) => setUsername(v.toLowerCase().replace(/\s/g, ''))} autoCapitalize="none" autoCorrect={false} placeholder="ahmad.gains" maxLength={21} />
        {nameState !== 'idle' ? (
          <Txt v="small" color={nameState === 'free' ? theme.accent : nameState === 'checking' ? theme.muted : theme.danger}>
            {nameState === 'free' ? L('✓ Available', '✓ متاح') : nameState === 'taken' ? L('Taken: someone already has this @username', 'مأخوذ: أحد عنده هالاسم') : nameState === 'needs_letter' ? L('Needs at least one letter (numbers-only names are not allowed)', 'لازم يكون فيه حرف واحد على الأقل (الأرقام فقط ممنوعة)') : nameState === 'checking' ? L('Checking…', 'جاري التحقق…') : L('3–20 characters: a–z, 0–9, _ and . only', '٣–٢٠ حرف: a–z و 0–9 و _ و . فقط')}
          </Txt>
        ) : null}
        <Field label={L('Bio', 'نبذة')} value={bio} onChangeText={setBio} maxLength={140} placeholder={L('Cutting to 75 kg · Abu Dhabi', 'أنشف لـ ٧٥ كجم · أبوظبي')} />
        <Txt v="label" muted>{L('My gym', 'النادي')}</Txt>
        <Chips value={UAE_GYMS.includes(gym) || !gym ? gym : 'Other'} onChange={setGym} options={[...UAE_GYMS, 'Other'].map((g) => ({ value: g, label: g === 'Other' ? L('Other', 'أخرى') : g }))} />
        {gym === 'Other' || (gym && !UAE_GYMS.includes(gym)) ? <Field label={L('Gym name', 'اسم النادي')} value={otherGym} onChangeText={(v) => { setOtherGym(v); setGym('Other'); }} maxLength={60} /> : null}

        <Txt v="label" muted style={{ marginTop: 6 }}>{L('Find me from contacts', 'اسمح لأصحابي يلقوني')}</Txt>
        <Card>
          <Row style={{ justifyContent: 'space-between' }}>
            <Txt style={{ flex: 1 }}>{L('Friends with my number can find me', 'من عنده رقمي يقدر يلقاني')}</Txt>
            <Switch value={findable} onValueChange={setFindable} trackColor={{ true: theme.accent }} />
          </Row>
          {findable ? <Field label={L('Mobile number', 'رقم الجوال')} value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder={profile?.phone_hash ? L('Saved (type to change)', 'محفوظ') : '+971 5x xxx xxxx'} /> : null}
          <Txt v="small" faint>{L('Your number is never shown to anyone; only a scrambled code is stored to match contacts.', 'رقمك لا يظهر لأحد؛ نحفظ رمزاً مشفراً فقط.')}</Txt>
        </Card>

        <Txt v="label" muted style={{ marginTop: 6 }}>{L('Who can see what', 'من يشوف إيش')}</Txt>
        <Txt v="small" faint>{L('Your name, @username, photo and bio are public so friends can find you.', 'اسمك واسم المستخدم وصورتك ونبذتك عامة عشان أصحابك يلقونك.')}</Txt>
        {PRIVACY_FIELDS.filter((f) => f !== 'photo' && f !== 'bio').map((f) => (
          <Card key={f}>
            <Txt v="bodyStrong">{L(FIELD_LABEL[f].en, FIELD_LABEL[f].ar)}</Txt>
            <Chips value={privacy[f]} onChange={(v) => setPrivacy({ ...privacy, [f]: v })} options={levels} />
          </Card>
        ))}
        {usesSpecific ? (
          <>
            <Txt v="label" muted>{L('Specific people', 'أشخاص محددين')}</Txt>
            <Card>
              {friends.length ? friends.map((f) => (
                <Row key={f.id} style={{ justifyContent: 'space-between' }}>
                  <Row gap={10} style={{ flex: 1 }}>
                    <Avatar url={f.avatar_url} name={f.display_name ?? f.username} size={34} />
                    <Txt>{f.display_name ?? f.username}</Txt>
                  </Row>
                  <Switch
                    value={allowed.includes(f.id)}
                    onValueChange={(on) => { setAllowedState((a) => (on ? [...a, f.id] : a.filter((x) => x !== f.id))); setAllowed(f.id, on).catch(() => {}); }}
                    trackColor={{ true: theme.accent }}
                  />
                </Row>
              )) : <Txt muted>{L('Add friends first, then choose who sees items set to Specific.', 'أضف أصحاب أولاً.')}</Txt>}
            </Card>
          </>
        ) : null}
        <View style={{ height: 6 }} />
        <Button title={L('Save', 'حفظ')} loading={busy} disabled={nameState === 'taken' || nameState === 'invalid' || nameState === 'needs_letter' || nameState === 'checking'} onPress={save} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
