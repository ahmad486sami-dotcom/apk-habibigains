// Scanner: food barcodes (Open Food Facts + your saved foods).
import { CameraView, useCameraPermissions } from 'expo-camera';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { Linking, StyleSheet, View } from 'react-native';
import Animated, { Easing, FadeIn, SlideInDown, useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { lookupBarcode, Meal } from '@/lib/data';
import { usernameFromLink } from '@/lib/social';
import { success, warn } from '@/lib/haptics';
import { useTheme } from '@/theme/theme';
import { useCelebrate } from '@/ui/Celebrate';
import { Icon } from '@/ui/Icon';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

type Msg = { title: string; body?: string; code?: string } | null;

export default function Scan() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const celebrate = useCelebrate();
  const p = useLocalSearchParams<{ meal?: Meal; day?: string; mode?: 'recipe' | 'friend'; from?: string }>();
  const [perm, requestPerm] = useCameraPermissions();
  const locked = useRef(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<Msg>(null);
  const [torch, setTorch] = useState(false);

  const sweep = useSharedValue(0);
  useEffect(() => {
    sweep.value = withRepeat(withTiming(1, { duration: 1600, easing: Easing.inOut(Easing.quad) }), -1, true);
  }, [sweep]);
  const sweepStyle = useAnimatedStyle(() => ({ transform: [{ translateY: sweep.value * 170 }] }));

  const onCode = async (raw: string) => {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    const data = raw.trim();
    try {
      // Friend QR code (habibigains://u/<username>)
      const friend = usernameFromLink(data);
      if (friend) {
        success();
        router.replace({ pathname: '/u/[username]', params: { username: friend } });
        return;
      }
      if (p.mode === 'friend') {
        warn();
        setMsg({ title: L('Not a Habibi Gains code', 'مو كود Habibi Gains'), body: L("Ask your friend to open Profile › My code.", 'خل صديقك يفتح حسابي › كودي.') });
        return;
      }
      // Food barcode
      if (/^\d{8,14}$/.test(data)) {
        const r = await lookupBarcode(data);
        if ('food' in r) {
          success();
          router.replace({ pathname: '/food/[id]', params: { id: r.food.id, ...(p.meal ? { meal: p.meal } : {}), ...(p.day ? { day: p.day } : {}), ...(p.mode === 'recipe' ? { mode: p.mode } : {}), ...(p.from ? { from: p.from } : {}) } });
          return;
        }
        warn();
        setMsg(
          'offline' in r
            ? { title: L('No connection', 'ما في اتصال'), body: L('Barcode lookup needs internet.', 'البحث بالباركود يحتاج إنترنت.') }
            : { title: L('Product not found', 'المنتج غير موجود'), body: L('It is not in Open Food Facts yet. Add it once from the label and it will scan instantly next time.', 'مو موجود في قاعدة البيانات. أضفه مرة من الملصق وبيطلع على طول المرة الجاية.'), code: data },
        );
        return;
      }
      warn();
      setMsg({ title: L('Not a food barcode', 'مو باركود أكل'), body: L('Point at the barcode on the pack.', 'وجّه الكاميرا على باركود المنتج.') });
    } catch {
      warn();
      setMsg({ title: L('Something went wrong', 'صار خطأ'), body: L('Try again.', 'حاول مرة ثانية.') });
    } finally {
      setBusy(false);
    }
  };

  const again = () => {
    setMsg(null);
    setTimeout(() => (locked.current = false), 400);
  };

  if (!perm) return <View style={{ flex: 1, backgroundColor: '#000' }} />;
  if (!perm.granted)
    return (
      <View style={{ flex: 1, backgroundColor: theme.bg, padding: 24, justifyContent: 'center', gap: 16 }}>
        <Icon name="scan" size={40} />
        <Txt v="h1">{L('Camera access', 'الوصول للكاميرا')}</Txt>
        <Txt muted>{L('Habibi Gains uses the camera only to read food barcodes.', 'نستخدم الكاميرا فقط لقراءة باركود الأكل.')}</Txt>
        {perm.canAskAgain ? (
          <Button title={L('Allow camera', 'السماح للكاميرا')} onPress={requestPerm} />
        ) : (
          <Button title={L('Open Settings', 'افتح الإعدادات')} onPress={() => Linking.openSettings()} />
        )}
        <Button title={L('Close', 'إغلاق')} kind="ghost" onPress={() => router.back()} />
      </View>
    );

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <CameraView
        style={StyleSheet.absoluteFill}
        facing="back"
        enableTorch={torch}
        barcodeScannerSettings={{ barcodeTypes: p.mode === 'friend' ? ['qr'] : ['ean13', 'ean8', 'upc_a', 'upc_e'] }}
        onBarcodeScanned={msg || busy ? undefined : ({ data }) => onCode(data)}
      />
      <View pointerEvents="none" style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' }}>
        <View style={{ width: 290, height: 190, borderRadius: 28, borderWidth: 2, borderColor: 'rgba(255,255,255,0.75)', overflow: 'hidden' }}>
          <Animated.View style={[{ height: 2, backgroundColor: theme.accent, marginTop: 8 }, sweepStyle]} />
        </View>
        <Txt v="bodyStrong" center style={{ marginTop: 20, paddingHorizontal: 40 }}>
          {busy ? L('Looking it up…', 'جاري البحث…') : (p.mode === 'friend' ? L("Point at your friend's code", 'وجّه الكاميرا على كود صديقك') : L('Point at a food barcode', 'وجّه الكاميرا على باركود الأكل'))}
        </Txt>
      </View>

      <Press onPress={() => router.back()} accessibilityLabel={L('Close', 'إغلاق')} style={[circle, { top: insets.top + 12, right: 18 }]}>
        <Icon name="close" />
      </Press>
      <Press onPress={() => setTorch(!torch)} accessibilityLabel={L('Torch', 'الكشاف')} style={[circle, { top: insets.top + 12, left: 18, backgroundColor: torch ? theme.accent : 'rgba(0,0,0,0.5)' }]}>
        <Icon name="bolt" color={torch ? theme.onAccent : '#fff'} />
      </Press>

      {msg ? (
        <Animated.View
          entering={SlideInDown.springify().damping(18)}
          style={{ position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: theme.surface, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 22, paddingBottom: insets.bottom + 16, gap: 12 }}
        >
          <Animated.View entering={FadeIn} style={{ gap: 6 }}>
            <Txt v="h2">{msg.title}</Txt>
            {msg.body ? <Txt muted>{msg.body}</Txt> : null}
          </Animated.View>
          {msg.code ? <Button title={L('Add this product', 'أضف المنتج')} onPress={() => router.replace({ pathname: '/food/create', params: { barcode: msg.code } })} /> : null}
          <Button title={L('Scan again', 'امسح مرة ثانية')} kind={msg.code ? 'secondary' : 'primary'} onPress={again} />
        </Animated.View>
      ) : null}
    </View>
  );
}

const circle = { position: 'absolute' as const, width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center' as const, justifyContent: 'center' as const };
