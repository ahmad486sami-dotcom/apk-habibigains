// Privacy Policy / Terms of Use inside the app (works offline, no website needed).
import { router, useLocalSearchParams } from 'expo-router';
import React from 'react';
import { Linking, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { CONTACT, LEGAL, LegalKind } from '@/lib/legal';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function Legal() {
  const { doc } = useLocalSearchParams<{ doc?: LegalKind }>();
  const { lang } = useI18n();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const kind: LegalKind = doc === 'terms' ? 'terms' : 'privacy';
  const d = LEGAL[kind][lang === 'ar' ? 'ar' : 'en'];
  const other: LegalKind = kind === 'terms' ? 'privacy' : 'terms';

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 22, paddingBottom: insets.bottom + 40, gap: 18 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1" style={{ flex: 1 }}>{d.title}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <Txt v="small" faint>{lang === 'ar' ? `آخر تحديث: ${d.updated}` : `Last updated: ${d.updated}`}</Txt>
      <Txt muted style={{ lineHeight: 22 }}>{d.intro}</Txt>
      {d.sections.map((s) => (
        <View key={s.h} style={{ gap: 8 }}>
          <Txt v="h3">{s.h}</Txt>
          {s.p.map((p, i) => (
            <Row key={i} gap={10} style={{ alignItems: 'flex-start' }}>
              {s.p.length > 1 ? <View style={{ width: 5, height: 5, borderRadius: 3, backgroundColor: theme.accent, marginTop: 9 }} /> : null}
              <Txt style={{ flex: 1, lineHeight: 22 }}>{p}</Txt>
            </Row>
          ))}
        </View>
      ))}
      <Press onPress={() => Linking.openURL(`mailto:${CONTACT}`)}>
        <Txt v="bodyStrong" color={theme.accent}>{CONTACT}</Txt>
      </Press>
      <Press onPress={() => router.replace({ pathname: '/legal', params: { doc: other } })}>
        <Txt v="small" color={theme.accent}>{LEGAL[other][lang === 'ar' ? 'ar' : 'en'].title} ›</Txt>
      </Press>
    </ScrollView>
  );
}
