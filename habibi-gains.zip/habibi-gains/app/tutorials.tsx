// Form tutorials: tap an exercise to expand cues and common mistakes.
import { router } from 'expo-router';
import React, { useState } from 'react';
import { ScrollView, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, LinearTransition } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

type Ex = { en: string; ar: string; muscles: string; cues: [string, string][]; mistakes: [string, string][] };

const EXERCISES: Ex[] = [
  {
    en: 'Squat', ar: 'السكوات', muscles: 'Quads · Glutes',
    cues: [['Feet shoulder-width, toes slightly out', 'القدمين بعرض الكتفين والأصابع للخارج قليلاً'], ['Brace your core, then sit down between your hips', 'شد البطن ثم انزل بين الوركين'], ['Knees follow your toes; drive up through the whole foot', 'الركب باتجاه الأصابع، واطلع بالضغط على القدم كاملة']],
    mistakes: [['Knees caving in', 'الركب تدخل للداخل'], ['Heels lifting off the floor', 'رفع الكعب عن الأرض']],
  },
  {
    en: 'Romanian deadlift', ar: 'الرفعة الرومانية', muscles: 'Hamstrings · Glutes',
    cues: [['Soft knees, push your hips back', 'ركب مرنة وادفع الورك للخلف'], ['Bar stays close to your legs', 'البار قريب من رجولك'], ['Stop when you feel a hamstring stretch, then squeeze glutes to stand', 'وقف عند الشد الخلفي واطلع بشد المؤخرة']],
    mistakes: [['Rounding the lower back', 'تقويس أسفل الظهر'], ['Turning it into a squat', 'تحويلها لسكوات']],
  },
  {
    en: 'Bench press', ar: 'البنش برس', muscles: 'Chest · Triceps',
    cues: [['Shoulder blades pinched back and down', 'ضم لوحي الكتف للخلف وللأسفل'], ['Bar touches lower chest, elbows ~45°', 'البار يلمس أسفل الصدر والكوع بزاوية ٤٥ تقريباً'], ['Feet planted, press up and slightly back', 'القدمين ثابتة، وادفع لفوق وللخلف قليلاً']],
    mistakes: [['Elbows flared to 90°', 'فتح الكوع ٩٠ درجة'], ['Bouncing the bar off the chest', 'ضرب البار في الصدر']],
  },
  {
    en: 'Push-up', ar: 'الضغط', muscles: 'Chest · Shoulders · Core',
    cues: [['Hands under shoulders, body in one straight line', 'اليدين تحت الكتفين والجسم خط مستقيم'], ['Lower until your chest nearly touches the floor', 'انزل لين صدرك يقرب من الأرض'], ['Squeeze glutes to keep hips level', 'شد المؤخرة عشان الورك يبقى مستوي']],
    mistakes: [['Hips sagging', 'نزول الورك'], ['Half reps', 'نص حركة']],
  },
  {
    en: 'Bent-over row', ar: 'التجديف بالانحناء', muscles: 'Back · Biceps',
    cues: [['Hinge forward, flat back', 'انحنِ للأمام بظهر مستقيم'], ['Pull elbows toward your hips', 'اسحب الكوع باتجاه الورك'], ['Pause and squeeze at the top', 'وقف لحظة واعصر فوق']],
    mistakes: [['Using momentum to jerk the weight', 'استخدام الاندفاع'], ['Shrugging shoulders to ears', 'رفع الأكتاف للأذن']],
  },
  {
    en: 'Overhead press', ar: 'الضغط فوق الرأس', muscles: 'Shoulders · Triceps',
    cues: [['Squeeze glutes and abs so you don’t lean back', 'شد المؤخرة والبطن عشان ما تميل للخلف'], ['Press straight up, head through at the top', 'ادفع لفوق مستقيم وادخل راسك تحت البار'], ['Lower under control to your collarbone', 'انزل بتحكم لعظمة الترقوة']],
    mistakes: [['Arching the lower back', 'تقويس أسفل الظهر'], ['Pressing forward instead of up', 'الدفع للأمام بدل فوق']],
  },
  {
    en: 'Plank', ar: 'البلانك', muscles: 'Core',
    cues: [['Elbows under shoulders', 'الكوع تحت الكتف'], ['Squeeze glutes, tuck ribs down', 'شد المؤخرة ونزّل الضلوع'], ['Breathe slowly; quality over time', 'تنفس ببطء، الجودة أهم من الوقت']],
    mistakes: [['Hips too high or sagging', 'الورك عالي أو نازل'], ['Holding your breath', 'حبس النفس']],
  },
];

export default function Tutorials() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const [open, setOpen] = useState<number | null>(0);
  const L = (p: [string, string]) => (lang === 'ar' ? p[1] : p[0]);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 12, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1">{t('tutorials')}</Txt>
        <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>
      {EXERCISES.map((ex, i) => {
        const on = open === i;
        return (
          <Animated.View key={ex.en} entering={FadeInDown.delay(i * 50).springify()} layout={LinearTransition.springify()}>
            <Press onPress={() => setOpen(on ? null : i)} scaleTo={0.99} style={{ backgroundColor: theme.card, borderRadius: 24, padding: 18, gap: 12 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <View>
                  <Txt v="h2">{lang === 'ar' ? ex.ar : ex.en}</Txt>
                  <Txt v="small" muted>{ex.muscles}</Txt>
                </View>
                <View style={{ transform: [{ rotate: on ? '90deg' : '0deg' }] }}>
                  <Icon name="chevron" color={theme.muted} />
                </View>
              </Row>
              {on ? (
                <Animated.View entering={FadeIn.duration(250)} style={{ gap: 10 }}>
                  {ex.cues.map((c, j) => (
                    <Row key={j} gap={10} style={{ alignItems: 'flex-start' }}>
                      <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: theme.accent, alignItems: 'center', justifyContent: 'center', marginTop: 1 }}>
                        <Txt v="small" color={theme.onAccent} style={{ fontSize: 12 }}>{j + 1}</Txt>
                      </View>
                      <Txt style={{ flex: 1 }}>{L(c)}</Txt>
                    </Row>
                  ))}
                  {ex.mistakes.map((m, j) => (
                    <Row key={`m${j}`} gap={10}>
                      <Icon name="close" size={18} color={theme.danger} />
                      <Txt muted style={{ flex: 1 }}>{L(m)}</Txt>
                    </Row>
                  ))}
                </Animated.View>
              ) : null}
            </Press>
          </Animated.View>
        );
      })}
    </ScrollView>
  );
}
