// New challenge with friends: % weight lost, kg lost, steps or days logged.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Switch } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { success, warn } from '@/lib/haptics';
import { ChallengeKind, createChallenge, FriendRow, getGroup, groupBoard, KIND_LABEL, listFriends } from '@/lib/social';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function ChallengeNew() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { group } = useLocalSearchParams<{ group?: string }>();
  const { session } = useSession();
  const [groupName, setGroupName] = useState('');
  const [groupIds, setGroupIds] = useState<string[]>([]);
  const [kind, setKind] = useState<ChallengeKind>('weight_pct');
  const [days, setDays] = useState('30');
  const [title, setTitle] = useState('');
  const [stake, setStake] = useState('');
  const [friends, setFriends] = useState<FriendRow[]>([]);
  const [picked, setPicked] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (group) {
      getGroup(group).then((g) => setGroupName(g?.name ?? ''));
      groupBoard(group).then((r) => setGroupIds(r.map((x) => x.user_id).filter((x) => x !== session?.user.id))).catch(() => {});
    } else listFriends().then((f) => setFriends(f.filter((x) => x.status === 'accepted'))).catch(() => {});
  }, [group]);

  const save = async () => {
    const members = group ? groupIds : picked;
    if (!members.length) return Alert.alert(group ? L('The group needs at least 2 people', 'المجموعة تحتاج شخصين على الأقل') : L('Pick at least one friend', 'اختر صديق واحد على الأقل'));
    setBusy(true);
    try {
      const id = await createChallenge({ title: title.trim() || L(KIND_LABEL[kind].en, KIND_LABEL[kind].ar), kind, days: Math.max(3, Math.min(180, Number(days) || 30)), stake, friends: members, groupId: group || undefined });
      success();
      router.replace({ pathname: '/challenge/[id]', params: { id } });
    } catch {
      warn();
      Alert.alert(L('Could not create', 'لم يتم الإنشاء'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{L('New challenge', 'تحدي جديد')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
        </Row>
        <Txt v="label" muted>{L('Who wins?', 'مين يفوز؟')}</Txt>
        <Chips value={kind} onChange={setKind} options={(Object.keys(KIND_LABEL) as ChallengeKind[]).map((k) => ({ value: k, label: L(KIND_LABEL[k].en, KIND_LABEL[k].ar) }))} />
        <Txt v="small" faint>
          {kind === 'weight_pct' ? L('Fairest for different body sizes: % of starting weight lost.', 'الأعدل بين الأحجام المختلفة: نسبة الوزن المفقود.')
            : kind === 'weight_kg' ? L('Most kilos lost from your weigh-in on the start day.', 'أكثر كيلوات مفقودة من وزن يوم البداية.')
            : kind === 'steps' ? L('Most steps in total.', 'أكثر خطوات بالمجموع.')
            : kind === 'bank_weeks' ? L('Most weeks finished within your own weekly calorie budget. Fair for everyone: each person has their own target.', 'أكثر أسابيع ضمن ميزانية السعرات الأسبوعية. عادل للكل: كل واحد بهدفه.')
            : L('Most days with food logged.', 'أكثر أيام مسجلة.')}
        </Txt>
        <Field label={L('Length (days)', 'المدة (أيام)')} value={days} onChangeText={(v) => setDays(v.replace(/\D/g, ''))} keyboardType="number-pad" />
        <Field label={L('Name (optional)', 'الاسم (اختياري)')} value={title} onChangeText={setTitle} maxLength={60} placeholder={L('Summer cut', 'تنشيف الصيف')} />
        <Field label={L('Stake (optional)', 'الرهان (اختياري)')} value={stake} onChangeText={setStake} maxLength={80} placeholder={L('Loser buys shawarma', 'الخسران يعزم شاورما')} />
        {group ? (
          <Card><Txt>{L(`Everyone in "${groupName}" (${groupIds.length + 1} people) joins this challenge.`, `كل أعضاء "${groupName}" (${groupIds.length + 1}) بينضمون للتحدي.`)}</Txt></Card>
        ) : <Txt v="label" muted>{L('Friends', 'الأصحاب')}</Txt>}
        {group ? null : <Card>
          {friends.length ? friends.map((f) => (
            <Row key={f.id} style={{ justifyContent: 'space-between' }}>
              <Row gap={10} style={{ flex: 1 }}>
                <Avatar url={f.avatar_url} name={f.display_name ?? f.username} size={34} />
                <Txt>{f.display_name ?? f.username}</Txt>
              </Row>
              <Switch value={picked.includes(f.id)} onValueChange={(on) => setPicked((p) => (on ? [...p, f.id] : p.filter((x) => x !== f.id)))} trackColor={{ true: theme.accent }} />
            </Row>
          )) : <Txt muted>{L('Add friends first from your Profile.', 'أضف أصحاب أولاً.')}</Txt>}
        </Card>}
        {kind.startsWith('weight') ? <Txt v="small" faint>{L('Everyone should weigh in on day one so the start weight counts.', 'لازم الكل يوزن في أول يوم.')}</Txt> : null}
        <Button title={L('Start challenge', 'ابدأ التحدي')} loading={busy} onPress={save} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
