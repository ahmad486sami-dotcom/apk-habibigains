// Fasting tracker: timer ring, presets, honest body timeline and a 7-day graph.
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { endFast, Evidence, FastState, last7, loadFast, PRESETS, SOURCES, stageAt, STAGES, startFast, streak } from '@/lib/fasting';
import { success } from '@/lib/haptics';
import { useTheme } from '@/theme/theme';
import { Ring } from '@/ui/Graphics';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const hms = (ms: number) => {
  const t = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = t % 60;
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
};

export default function Fasting() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const [state, setState] = useState<FastState>({ active: null, history: [] });
  const [goal, setGoal] = useState<string>('16:8');
  const [now, setNow] = useState(Date.now());

  useFocusEffect(useCallback(() => { loadFast().then(setState); }, []));
  useEffect(() => {
    const i = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(i);
  }, []);

  const active = state.active;
  const elapsedMs = active ? now - active.start : 0;
  const hours = elapsedMs / 3_600_000;
  const goalH = active?.goalH ?? PRESETS.find((p) => p.id === goal)!.goalH;
  const stage = stageAt(hours);
  const week = last7(state.history);
  const maxH = Math.max(24, ...week.map((w) => w.hours));
  const evidenceLabel = (e: Evidence) =>
    e === 'strong' ? L('Strong evidence', 'دليل قوي') : e === 'some' ? L('Some evidence', 'دليل متوسط') : L('Mostly animal studies', 'غالباً دراسات على الحيوانات');
  const evidenceColor = (e: Evidence) => (e === 'strong' ? theme.accent : e === 'some' ? '#F5B942' : theme.faint);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 16, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h2">{L('Fasting', 'الصيام')}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>

      <Card>
        <View style={{ alignItems: 'center', gap: 10 }}>
          <Ring size={210} stroke={16} progress={active ? Math.min(1, hours / goalH) : 0}>
            <Txt v="h1">{active ? hms(elapsedMs) : '0:00:00'}</Txt>
            <Txt v="small" muted>{active ? L(`Goal ${goalH} h`, `الهدف ${goalH} ساعة`) : L('Not fasting', 'غير صائم')}</Txt>
          </Ring>
          {active ? <Txt v="bodyStrong" color={theme.accent}>{L(stage.en, stage.ar)}</Txt> : null}
          {active && hours >= goalH ? <Txt v="small" color={theme.accent}>{L('Goal reached. Nice.', 'وصلت للهدف. ممتاز.')}</Txt> : null}
        </View>
        {!active ? <Chips value={goal} onChange={setGoal} options={PRESETS.map((p) => ({ value: p.id, label: p.id }))} /> : null}
        <Button
          title={active ? L('End fast', 'إنهاء الصيام') : L('Start fast', 'ابدأ الصيام')}
          onPress={async () => { setState(active ? await endFast() : await startFast(goalH)); success(); }}
        />
        <Txt v="small" faint>{L('Logging food ends a running fast automatically.', 'تسجيل الأكل ينهي الصيام تلقائياً.')}</Txt>
      </Card>

      <Card>
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="label" muted>{L('Last 7 days', 'آخر 7 أيام')}</Txt>
          <Txt v="small">{L(`Streak: ${streak(state.history)} days`, `السلسلة: ${streak(state.history)} يوم`)}</Txt>
        </Row>
        <Row style={{ justifyContent: 'space-between', alignItems: 'flex-end', height: 110 }}>
          {week.map((w, i) => (
            <View key={i} style={{ alignItems: 'center', gap: 6, flex: 1 }}>
              <Txt v="small" faint style={{ fontSize: 10 }}>{w.hours ? `${Math.round(w.hours)}h` : ''}</Txt>
              <View style={{ width: 18, height: Math.max(4, (w.hours / maxH) * 80), borderRadius: 6, backgroundColor: w.hours ? theme.accent : theme.cardHigh }} />
              <Txt v="small" muted style={{ fontSize: 11 }}>{w.label}</Txt>
            </View>
          ))}
        </Row>
      </Card>

      <Txt v="h3">{L('What happens in your body', 'ماذا يحدث في جسمك')}</Txt>
      <Txt v="small" muted>{L('Times are typical ranges, not exact. They depend on your last meal, activity and body.', 'الأوقات تقريبية وليست دقيقة، وتعتمد على آخر وجبة ونشاطك وجسمك.')}</Txt>
      {STAGES.map((st) => {
        const current = active && st === stage;
        return (
          <Card key={st.en} style={current ? { borderWidth: 1.5, borderColor: theme.accent } : undefined}>
            <Row style={{ justifyContent: 'space-between' }}>
              <Txt v="bodyStrong">{L(st.en, st.ar)}</Txt>
              <Txt v="small" muted>{st.toH ? `${st.fromH}–${st.toH} h` : `${st.fromH}+ h`}</Txt>
            </Row>
            <Txt v="small" muted>{L(st.bodyEn, st.bodyAr)}</Txt>
            <View style={{ alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, backgroundColor: theme.cardHigh }}>
              <Txt v="small" color={evidenceColor(st.evidence)} style={{ fontSize: 11 }}>{evidenceLabel(st.evidence)}</Txt>
            </View>
          </Card>
        );
      })}
      <View style={{ gap: 4 }}>
        <Txt v="label" muted>{L('Sources', 'المصادر')}</Txt>
        {SOURCES.map((s) => <Txt key={s} v="small" faint>{s}</Txt>)}
        <Txt v="small" faint style={{ marginTop: 6 }}>{L('Not medical advice. Check with a doctor before fasting if you have a medical condition, are pregnant or take medication.', 'ليست نصيحة طبية. استشر الطبيب قبل الصيام إذا كان لديك حالة صحية أو حامل أو تتناول أدوية.')}</Txt>
      </View>
    </ScrollView>
  );
}
