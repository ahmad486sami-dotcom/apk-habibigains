// A group: last-7-days leaderboard (on-budget days, steps), group challenges, invite code.
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { Alert, ScrollView, Share, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { useSession } from '@/lib/session';
import { Challenge, deleteGroup, getGroup, Group, groupBoard, groupChallenges, GroupRow, KIND_LABEL, leaveGroup } from '@/lib/social';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const MEDAL = ['🥇', '🥈', '🥉'];

export default function GroupScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { session } = useSession();
  const [g, setG] = useState<Group | null>(null);
  const [rows, setRows] = useState<GroupRow[]>([]);
  const [ch, setCh] = useState<Challenge[]>([]);
  const [by, setBy] = useState<'budget' | 'steps'>('budget');

  useFocusEffect(useCallback(() => {
    if (!id) return;
    getGroup(id).then(setG);
    groupBoard(id).then(setRows).catch(() => {});
    groupChallenges(id).then(setCh).catch(() => {});
  }, [id]));

  if (!g) return <View style={{ flex: 1, backgroundColor: theme.bg }} />;
  const owner = g.created_by === session?.user.id;
  const sorted = [...rows].sort((a, b) => (by === 'steps' ? (b.steps ?? -1) - (a.steps ?? -1) : b.days_on_budget - a.days_on_budget || b.days_logged - a.days_logged));
  const invite = () => Share.share({ message: L(`Join my group "${g.name}" on Habibi Gains with code ${g.invite_code}`, `انضم لمجموعتي "${g.name}" في Habibi Gains بالكود ${g.invite_code}`) });

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <View style={{ flex: 1 }}>
          <Txt v="h2">{g.name}</Txt>
          <Txt v="small" muted>{`${rows.length} ${L('members', 'عضو')} · ${L('code', 'الكود')} ${g.invite_code}`}</Txt>
        </View>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <Row gap={10}>
        <View style={{ flex: 1 }}><Button kind="secondary" title={L('Invite', 'دعوة')} icon={<Icon name="share" size={16} />} onPress={invite} /></View>
        <View style={{ flex: 1 }}><Button title={L('Challenge', 'تحدي')} icon={<Icon name="medal" size={16} color={theme.onAccent} />} onPress={() => router.push({ pathname: '/challenge-new', params: { group: g.id } })} /></View>
      </Row>

      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="label" muted>{L('Last 7 days', 'آخر ٧ أيام')}</Txt>
        <Chips value={by} onChange={setBy} options={[{ value: 'budget', label: L('On budget', 'الميزانية') }, { value: 'steps', label: L('Steps', 'خطوات') }]} />
      </Row>
      <Card>
        {sorted.map((r, i) => (
          <Press key={r.user_id} onPress={() => router.push({ pathname: '/user/[id]', params: { id: r.user_id } })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 6 }}>
            <Txt v="bodyStrong" style={{ width: 28 }}>{MEDAL[i] ?? `${i + 1}`}</Txt>
            <Avatar url={r.avatar_url} name={r.display_name ?? r.username} size={36} />
            <Txt style={{ flex: 1 }} numberOfLines={1}>{r.display_name ?? `@${r.username}`}{r.user_id === session?.user.id ? L(' (you)', ' (أنت)') : ''}</Txt>
            <Txt v="bodyStrong">
              {by === 'steps' ? (r.steps != null ? r.steps.toLocaleString('en-US') : '🔒') : `${r.days_on_budget}/7`}
            </Txt>
          </Press>
        ))}
      </Card>
      <Txt v="small" faint>{by === 'budget' ? L('Days at or under calorie target. Only counts are shown, never what anyone ate.', 'الأيام ضمن هدف السعرات. نعرض العدد فقط، مو الأكل.') : L('🔒 = that person keeps their steps private.', '🔒 = خطواته خاصة.')}</Txt>

      <Txt v="label" muted>{L('Group challenges', 'تحديات المجموعة')}</Txt>
      {ch.length ? ch.map((c) => (
        <Card key={c.id} onPress={() => router.push({ pathname: '/challenge/[id]', params: { id: c.id } })}>
          <Txt v="bodyStrong">{c.title}</Txt>
          <Txt v="small" faint>{`${L(KIND_LABEL[c.kind]?.en ?? c.kind, KIND_LABEL[c.kind]?.ar ?? c.kind)} · ${L('ends', 'ينتهي')} ${c.ends_on}`}</Txt>
        </Card>
      )) : <Card><Txt muted>{L('No challenges yet. Start one for the whole group.', 'ما في تحديات. ابدأ واحد للمجموعة كلها.')}</Txt></Card>}

      <Button kind="ghost" title={owner ? L('Delete group', 'حذف المجموعة') : L('Leave group', 'اترك المجموعة')} onPress={() =>
        Alert.alert(owner ? L('Delete this group for everyone?', 'تحذف المجموعة للكل؟') : L('Leave this group?', 'تترك المجموعة؟'), '', [
          { text: L('Cancel', 'إلغاء') },
          { text: owner ? L('Delete', 'حذف') : L('Leave', 'اترك'), style: 'destructive', onPress: async () => { await (owner ? deleteGroup(g.id) : leaveGroup(g.id)); router.back(); } },
        ])} />
    </ScrollView>
  );
}
