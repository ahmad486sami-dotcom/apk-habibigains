// Profiles, friends, privacy, food-diary sharing and challenges.
import { supabase, todayISO } from './supabase';

export type Visibility = 'everyone' | 'friends' | 'only_me' | 'specific';
export const PRIVACY_FIELDS = ['photo', 'bio', 'gym', 'streak', 'steps', 'kg_lost', 'week', 'diary'] as const;
export type PrivacyField = (typeof PRIVACY_FIELDS)[number];
export type Privacy = Record<PrivacyField, Visibility>;
export const DEFAULT_PRIVACY: Privacy = { photo: 'everyone', bio: 'everyone', gym: 'friends', streak: 'friends', steps: 'friends', kg_lost: 'only_me', week: 'friends', diary: 'only_me' };

export const FIELD_LABEL: Record<PrivacyField, { en: string; ar: string }> = {
  photo: { en: 'Profile photo', ar: 'الصورة' },
  bio: { en: 'Bio', ar: 'النبذة' },
  gym: { en: 'My gym', ar: 'النادي' },
  streak: { en: 'Streak', ar: 'السلسلة' },
  steps: { en: 'Steps', ar: 'الخطوات' },
  kg_lost: { en: 'Weight lost', ar: 'الوزن المفقود' },
  week: { en: 'My week (calorie dots)', ar: 'أسبوعي' },
  diary: { en: 'Food diary (what I eat)', ar: 'يومياتي الغذائية' },
};

export const UAE_GYMS = ['Fitness First', 'GymNation', "Gold's Gym", 'Warehouse Gym', 'Gymnasium', 'Snap Fitness', 'Anytime Fitness', 'Fitness Time', 'ProFit', 'Home gym'];

export type ProfileCard = {
  id: string;
  display_name: string | null;
  username: string | null;
  relation: 'self' | 'friend' | 'requested' | 'incoming' | 'none';
  avatar_url: string | null;
  bio: string | null;
  gym: string | null;
  streak: number | null;
  steps_today: number | null;
  kg_lost: number | null;
  week: { day: string; kcal: number }[] | null;
  calorie_target: number | null;
  diary: boolean;
};

async function me() {
  const { data } = await supabase.auth.getUser();
  if (!data.user) throw new Error('not signed in');
  return data.user.id;
}

export async function getProfileCard(id: string): Promise<ProfileCard | null> {
  const { data, error } = await supabase.rpc('profile_card', { target: id });
  if (error) throw error;
  return (data as ProfileCard) ?? null;
}

export async function uploadAvatar(uri: string) {
  const uid = await me();
  const path = `${uid}/avatar-${Date.now()}.jpg`;
  const body = await (await fetch(uri)).arrayBuffer();
  const { error } = await supabase.storage.from('avatars').upload(path, body, { contentType: 'image/jpeg', upsert: true });
  if (error) throw error;
  return supabase.storage.from('avatars').getPublicUrl(path).data.publicUrl;
}

// Phone numbers are matched by a hash of their last 9 digits, never stored in plain text.
const tail = (n: string) => n.replace(/\D/g, '').slice(-9);
export const hashPhone = async (n: string) => (tail(n).length === 9 ? sha256(tail(n)) : null);

// Small SHA-256 (ASCII input) so no extra native add-on is needed.
function sha256(msg: string) {
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const bytes = [...msg].map((c) => c.charCodeAt(0) & 0xff);
  const l = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 7; i >= 0; i--) bytes.push(i > 3 ? 0 : (l >>> (i * 8)) & 0xff);
  const r = (x: number, n: number) => (x >>> n) | (x << (32 - n));
  for (let o = 0; o < bytes.length; o += 64) {
    const w = new Array(64);
    for (let i = 0; i < 16; i++) w[i] = (bytes[o + i * 4] << 24) | (bytes[o + i * 4 + 1] << 16) | (bytes[o + i * 4 + 2] << 8) | bytes[o + i * 4 + 3];
    for (let i = 16; i < 64; i++) {
      const s0 = r(w[i - 15], 7) ^ r(w[i - 15], 18) ^ (w[i - 15] >>> 3);
      const s1 = r(w[i - 2], 17) ^ r(w[i - 2], 19) ^ (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }
    let [a, b, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const t1 = (h + (r(e, 6) ^ r(e, 11) ^ r(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
      const t2 = ((r(a, 2) ^ r(a, 13) ^ r(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
    H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
  }
  return H.map((x) => (x >>> 0).toString(16).padStart(8, '0')).join('');
}

export type Person = { id: string; username: string | null; display_name: string | null; avatar_url?: string | null };

export async function searchPeople(q: string): Promise<Person[]> {
  const term = q.trim().replace(/^@/, '').toLowerCase();
  if (term.length < 2) return [];
  const { data, error } = await supabase.rpc('find_by_username', { q: term });
  if (error) throw error;
  return (data ?? []) as Person[];
}

export async function matchContacts(numbers: string[]): Promise<Person[]> {
  const hashes = (await Promise.all([...new Set(numbers)].slice(0, 2000).map(hashPhone))).filter(Boolean) as string[];
  if (!hashes.length) return [];
  const { data, error } = await supabase.rpc('match_contacts', { hashes });
  if (error) throw error;
  return (data ?? []) as Person[];
}

export async function sendRequest(to: string) {
  const { error } = await supabase.from('friendships').insert({ requester: await me(), addressee: to, status: 'pending' });
  if (error) throw error;
  notify(to, 'friend_request');
}
export async function acceptRequest(from: string) {
  const { error } = await supabase.from('friendships').update({ status: 'accepted' }).eq('requester', from).eq('addressee', await me());
  if (error) throw error;
  notify(from, 'friend_accepted');
}
export async function removeFriend(other: string) {
  const uid = await me();
  const { error } = await supabase.from('friendships').delete().or(`and(requester.eq.${uid},addressee.eq.${other}),and(requester.eq.${other},addressee.eq.${uid})`);
  if (error) throw error;
}

export type FriendRow = Person & { status: 'accepted' | 'incoming' | 'outgoing' };
export async function listFriends(): Promise<FriendRow[]> {
  const uid = await me();
  const { data, error } = await supabase.from('friendships').select('requester,addressee,status');
  if (error) throw error;
  const rows = (data ?? []) as { requester: string; addressee: string; status: string }[];
  const ids = rows.map((r) => (r.requester === uid ? r.addressee : r.requester));
  if (!ids.length) return [];
  const { data: cards } = await supabase.rpc('profile_cards', { ids });
  const byId = new Map(((cards ?? []) as any[]).map((c) => [c.id, c]));
  return rows.map((r) => {
    const other = r.requester === uid ? r.addressee : r.requester;
    const c = byId.get(other) ?? {};
    return {
      id: other,
      username: c.username ?? null,
      display_name: c.display_name ?? null,
      avatar_url: c.avatar_url ?? null,
      status: r.status === 'accepted' ? 'accepted' : r.requester === uid ? 'outgoing' : 'incoming',
    } as FriendRow;
  });
}

/** "Specific people" list: who can see fields set to Specific. */
export async function getAllowList(): Promise<string[]> {
  const { data } = await supabase.from('visibility_allow').select('viewer');
  return (data ?? []).map((r: any) => r.viewer);
}
export async function setAllowed(viewer: string, on: boolean) {
  const owner = await me();
  if (on) await supabase.from('visibility_allow').upsert({ owner, viewer });
  else await supabase.from('visibility_allow').delete().eq('owner', owner).eq('viewer', viewer);
}

/** A friend's food diary for a day (only works if they share it with you). */
export async function friendDiary(userId: string, day = todayISO()) {
  const { data, error } = await supabase.from('food_logs').select('*').eq('user_id', userId).eq('logged_on', day).order('created_at');
  if (error) throw error;
  return data ?? [];
}

// ───────── Steps (saved so friends and step challenges can use them) ─────────
export async function saveSteps(steps: number, day = todayISO()) {
  const user_id = await me();
  await supabase.from('daily_steps').upsert({ user_id, day, steps: Math.max(0, Math.min(200000, Math.round(steps))) });
}

// ───────── Challenges ─────────
export type ChallengeKind = 'weight_pct' | 'weight_kg' | 'steps' | 'log_days' | 'bank_weeks';
export const KIND_LABEL: Record<ChallengeKind, { en: string; ar: string; unit: string }> = {
  weight_pct: { en: '% weight lost', ar: 'نسبة الوزن المفقود', unit: '%' },
  weight_kg: { en: 'kg lost', ar: 'كجم مفقود', unit: 'kg' },
  steps: { en: 'Most steps', ar: 'أكثر خطوات', unit: 'steps' },
  log_days: { en: 'Days logged', ar: 'أيام التسجيل', unit: 'days' },
  bank_weeks: { en: 'Weeks within budget', ar: 'أسابيع ضمن الميزانية', unit: 'weeks' },
};
export type Challenge = { id: string; creator: string; title: string; kind: ChallengeKind; starts_on: string; ends_on: string; stake: string | null; group_id?: string | null };

export async function myChallenges(): Promise<Challenge[]> {
  const { data, error } = await supabase.from('challenges').select('id,creator,title,kind,starts_on,ends_on,stake').eq('is_community', false).order('ends_on', { ascending: false }).limit(30);
  if (error) throw error;
  return (data ?? []) as Challenge[];
}

export async function createChallenge(c: { title: string; kind: ChallengeKind; days: number; stake: string; friends: string[]; groupId?: string }) {
  const creator = await me();
  const start = todayISO();
  const end = todayISO(new Date(Date.now() + (c.days - 1) * 86_400_000));
  const { data, error } = await supabase.from('challenges').insert({ creator, title: c.title, kind: c.kind, starts_on: start, ends_on: end, is_community: false, stake: c.stake || null, group_id: c.groupId ?? null }).select('id').single();
  if (error) throw error;
  const ids = [...new Set([creator, ...c.friends])];
  const { error: e2 } = await supabase.from('challenge_members').insert(ids.map((user_id) => ({ challenge_id: data.id, user_id })));
  if (e2) throw e2;
  ids.filter((i) => i !== creator).forEach((i) => notify(i, 'challenge', { id: data.id, title: c.title }));
  return data.id as string;
}

export async function challengeBoard(id: string) {
  const { data, error } = await supabase.rpc('challenge_board', { cid: id });
  if (error) throw error;
  return (data ?? []) as { user_id: string; username: string | null; display_name: string | null; avatar_key: string | null; score: number | null }[];
}

export async function leaveChallenge(id: string) {
  const { error } = await supabase.from('challenge_members').delete().eq('challenge_id', id).eq('user_id', await me());
  if (error) throw error;
}


// ───────── Invite link + QR ─────────
export const profileLink = (username: string) => `habibigains://u/${username}`;
/** Reads a scanned QR / pasted link and returns the @username in it, if any. */
export function usernameFromLink(text: string): string | null {
  const m = text.trim().match(/(?:habibigains:\/\/u\/|habibigains\.store\/u\/)([a-z0-9_.]{3,20})/i);
  return m ? m[1].toLowerCase() : null;
}
export async function findByUsername(username: string): Promise<Person | null> {
  const list = await searchPeople(username);
  return list.find((p) => (p.username ?? '').toLowerCase() === username.toLowerCase()) ?? null;
}

// ───────── Block / report ─────────
export async function blockUser(id: string) {
  const blocker = await me();
  await removeFriend(id).catch(() => {});
  const { error } = await supabase.from('user_blocks').upsert({ blocker, blocked: id });
  if (error) throw error;
}
export async function unblockUser(id: string) {
  await supabase.from('user_blocks').delete().eq('blocker', await me()).eq('blocked', id);
}
export const REPORT_REASONS = [
  { value: 'spam', en: 'Spam', ar: 'سبام' },
  { value: 'harassment', en: 'Harassment', ar: 'مضايقة' },
  { value: 'inappropriate', en: 'Inappropriate photo or text', ar: 'محتوى غير لائق' },
  { value: 'impersonation', en: 'Pretending to be someone', ar: 'انتحال شخصية' },
  { value: 'other', en: 'Something else', ar: 'شي ثاني' },
] as const;
export async function reportUser(id: string, reason: string, details?: string) {
  const { error } = await supabase.from('user_reports').insert({ reporter: await me(), reported: id, reason, details: details || null });
  if (error) throw error;
}

// ───────── Inbox (in-app notifications) ─────────
export type InboxKind = 'nudge' | 'reaction' | 'friend_request' | 'friend_accepted' | 'buddy_request' | 'buddy_alert' | 'challenge' | 'group_invite';
export type InboxItem = { id: string; from_user: string | null; kind: InboxKind; data: any; read: boolean; created_at: string; from?: Person };

/** Fire-and-forget: tell someone something happened. The server checks who is allowed. */
export function notify(to: string, kind: Exclude<InboxKind, 'nudge' | 'buddy_alert'>, data: Record<string, unknown> = {}) {
  supabase.rpc('notify', { target: to, p_kind: kind, p_data: data }).then(() => {}, () => {});
}

export async function fetchInbox(): Promise<InboxItem[]> {
  const { data, error } = await supabase.from('notifications').select('id,from_user,kind,data,read,created_at').order('created_at', { ascending: false }).limit(60);
  if (error) throw error;
  const rows = (data ?? []) as InboxItem[];
  const ids = [...new Set(rows.map((r) => r.from_user).filter(Boolean))] as string[];
  if (ids.length) {
    const { data: cards } = await supabase.rpc('profile_cards', { ids });
    const byId = new Map(((cards ?? []) as any[]).map((c) => [c.id, c]));
    rows.forEach((r) => { if (r.from_user) r.from = byId.get(r.from_user); });
  }
  return rows;
}
export async function unreadCount() {
  const { count } = await supabase.from('notifications').select('id', { count: 'exact', head: true }).eq('read', false);
  return count ?? 0;
}
export async function markAllRead() {
  await supabase.from('notifications').update({ read: true }).eq('read', false);
}

// ───────── Nudge ─────────
export const NUDGES = [
  { en: 'Log your food 👀', ar: 'سجّل أكلك 👀' },
  { en: 'Get your steps in 🚶', ar: 'امشِ شوي 🚶' },
  { en: 'Drink water 💧', ar: 'اشرب ماي 💧' },
  { en: "Let's go, gym time 💪", ar: 'يلا عالجيم 💪' },
];
/** Returns false if you already nudged this friend in the last 20 hours. */
export async function nudge(to: string, text: string) {
  const { data, error } = await supabase.rpc('nudge', { target: to, p_text: text });
  if (error) throw error;
  return data as boolean;
}

// ───────── Feed ─────────
export type FeedKind = 'week_on_budget' | 'streak' | 'week_logged_all' | 'challenge_won' | 'weight_low' | 'joined';
export type FeedItem = { id: string; user_id: string; kind: FeedKind; data: any; created_at: string; who?: Person; reactions: { emoji: string; user_id: string }[] };
export const REACTIONS = ['🔥', '💪', '👏'] as const;

/** Post an automatic achievement once (the same dedupe key is ignored the second time). */
export async function postEvent(kind: FeedKind, dedupe: string, data: Record<string, unknown> = {}) {
  const user_id = await me();
  await supabase.from('feed_events').upsert({ user_id, kind, dedupe_key: dedupe, data }, { onConflict: 'user_id,kind,dedupe_key', ignoreDuplicates: true });
}

export async function fetchFeed(limit = 40): Promise<FeedItem[]> {
  const { data, error } = await supabase.from('feed_events').select('id,user_id,kind,data,created_at,feed_reactions(emoji,user_id)').order('created_at', { ascending: false }).limit(limit);
  if (error) throw error;
  const rows = ((data ?? []) as any[]).map((r) => ({ ...r, reactions: r.feed_reactions ?? [] })) as FeedItem[];
  const ids = [...new Set(rows.map((r) => r.user_id))];
  if (ids.length) {
    const { data: cards } = await supabase.rpc('profile_cards', { ids });
    const byId = new Map(((cards ?? []) as any[]).map((c) => [c.id, c]));
    rows.forEach((r) => { r.who = byId.get(r.user_id); });
  }
  return rows;
}

export async function react(item: FeedItem, emoji: string) {
  const user_id = await me();
  const mine = item.reactions.find((r) => r.user_id === user_id);
  if (mine?.emoji === emoji) {
    await supabase.from('feed_reactions').delete().eq('event_id', item.id).eq('user_id', user_id);
    return;
  }
  const { error } = await supabase.from('feed_reactions').upsert({ event_id: item.id, user_id, emoji });
  if (error) throw error;
  if (!mine && item.user_id !== user_id) notify(item.user_id, 'reaction', { emoji, kind: item.kind });
}

export function feedText(i: FeedItem, lang: string): string {
  const ar = lang === 'ar';
  const d = i.data ?? {};
  switch (i.kind) {
    case 'week_on_budget': return ar ? `خلّص الأسبوع ضمن الميزانية (${d.logged ?? 7}/٧ أيام)` : `finished the week within budget (${d.logged ?? 7}/7 days)`;
    case 'week_logged_all': return ar ? 'سجّل كل أيام الأسبوع ٧/٧' : 'logged all 7 days this week';
    case 'streak': return ar ? `وصل لسلسلة ${d.days} يوم 🔥` : `hit a ${d.days}-day streak 🔥`;
    case 'challenge_won': return ar ? `فاز بتحدي "${d.title ?? ''}" 🏆` : `won the "${d.title ?? ''}" challenge 🏆`;
    case 'weight_low': return ar ? 'وصل لأقل وزن له 📉' : 'hit a new lowest weight 📉';
    case 'joined': return ar ? 'انضم لـ Habibi Gains 👋' : 'joined Habibi Gains 👋';
  }
}

// ───────── Add a friend's meal to my diary ─────────
export async function copyToMyDiary(log: any, meal: string, day = todayISO()) {
  const user_id = await me();
  const { error } = await supabase.from('food_logs').insert({
    user_id, logged_on: day, meal, source: 'friend',
    food_id: log.food_id ?? null, name: log.name, brand: log.brand ?? null,
    quantity: log.quantity ?? 1, serving_label: log.serving_label ?? '1 serving', serving_g: log.serving_g ?? null,
    kcal: log.kcal, protein_g: log.protein_g ?? 0, carbs_g: log.carbs_g ?? 0, fat_g: log.fat_g ?? 0,
    fiber_g: log.fiber_g ?? null, sugar_g: log.sugar_g ?? null, sodium_mg: log.sodium_mg ?? null,
  });
  if (error) throw error;
}

// ───────── Accountability buddies (max 3, both agree) ─────────
export type BuddyRow = Person & { status: 'accepted' | 'incoming' | 'outgoing' };
export async function listBuddies(): Promise<BuddyRow[]> {
  const uid = await me();
  const { data, error } = await supabase.from('buddies').select('requester,addressee,status');
  if (error) throw error;
  const rows = (data ?? []) as any[];
  const ids = rows.map((r) => (r.requester === uid ? r.addressee : r.requester));
  if (!ids.length) return [];
  const { data: cards } = await supabase.rpc('profile_cards', { ids });
  const byId = new Map(((cards ?? []) as any[]).map((c) => [c.id, c]));
  return rows.map((r) => {
    const other = r.requester === uid ? r.addressee : r.requester;
    const c = byId.get(other) ?? {};
    return { id: other, username: c.username ?? null, display_name: c.display_name ?? null, avatar_url: c.avatar_url ?? null, status: r.status === 'accepted' ? 'accepted' : r.requester === uid ? 'outgoing' : 'incoming' };
  });
}
export async function askBuddy(id: string) {
  const { error } = await supabase.from('buddies').insert({ requester: await me(), addressee: id });
  if (error) throw new Error(error.message.includes('row-level') ? 'max3' : error.message);
  notify(id, 'buddy_request');
}
export async function acceptBuddy(id: string) {
  const { error } = await supabase.from('buddies').update({ status: 'accepted' }).eq('requester', id).eq('addressee', await me());
  if (error) throw error;
}
export async function endBuddy(id: string) {
  const uid = await me();
  await supabase.from('buddies').delete().or(`and(requester.eq.${uid},addressee.eq.${id}),and(requester.eq.${id},addressee.eq.${uid})`);
}
/** Buddies with nothing logged today. */
export async function buddiesNotLogged(): Promise<Person[]> {
  const { data } = await supabase.rpc('buddies_not_logged');
  return (data ?? []) as Person[];
}

// ───────── Groups ─────────
export type Group = { id: string; name: string; created_by: string; invite_code: string; members?: number };
export async function myGroups(): Promise<Group[]> {
  const { data, error } = await supabase.from('groups').select('id,name,created_by,invite_code,group_members(count)').order('created_at', { ascending: false });
  if (error) throw error;
  return ((data ?? []) as any[]).map((g) => ({ ...g, members: g.group_members?.[0]?.count ?? 0 }));
}
export async function getGroup(id: string): Promise<Group | null> {
  const { data } = await supabase.from('groups').select('id,name,created_by,invite_code').eq('id', id).maybeSingle();
  return (data as Group) ?? null;
}
export async function createGroup(name: string, invite: string[]) {
  const uid = await me();
  const { data, error } = await supabase.from('groups').insert({ name: name.trim(), created_by: uid }).select('id,invite_code').single();
  if (error) throw error;
  await supabase.from('group_members').insert({ group_id: data.id, user_id: uid });
  invite.forEach((f) => notify(f, 'group_invite', { code: data.invite_code, name: name.trim() }));
  return data.id as string;
}
export async function joinGroup(code: string) {
  const { data, error } = await supabase.rpc('join_group', { code });
  if (error) throw new Error('nogroup');
  return data as string;
}
export async function leaveGroup(id: string) {
  await supabase.from('group_members').delete().eq('group_id', id).eq('user_id', await me());
}
export async function deleteGroup(id: string) {
  await supabase.from('groups').delete().eq('id', id);
}
export type GroupRow = { user_id: string; username: string | null; display_name: string | null; avatar_url: string | null; steps: number | null; days_logged: number; days_on_budget: number };
export async function groupBoard(id: string): Promise<GroupRow[]> {
  const { data, error } = await supabase.rpc('group_board', { g: id });
  if (error) throw error;
  return (data ?? []) as GroupRow[];
}
export async function groupChallenges(id: string): Promise<Challenge[]> {
  const { data } = await supabase.from('challenges').select('id,creator,title,kind,starts_on,ends_on,stake,group_id').eq('group_id', id).order('ends_on', { ascending: false });
  return (data ?? []) as Challenge[];
}
