// Email + password accounts.
// New accounts are created by the `signup` edge function. Once email sending is set up (Resend),
// they start unconfirmed and a 6-digit code is emailed; sign-in only works after the code is entered.
// Forgot password: a 6-digit code by email, then a new password. All codes go through `auth-code`.
import { supabase, SUPABASE_KEY, SUPABASE_URL } from './supabase';

export class AuthError extends Error {
  constructor(public code: 'email_taken' | 'invalid_email' | 'weak_password' | 'wrong_password' | 'network' | 'failed' | 'unverified' | 'wrong_code' | 'expired' | 'too_many_tries' | 'wait' | 'too_many' | 'email_not_set_up') {
    super(code);
  }
}

const clean = (email: string) => email.trim().toLowerCase();

export async function signInWithPassword(email: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({ email: clean(email), password });
  if (error) {
    const m = error.message.toLowerCase();
    if (m.includes('not confirmed')) throw new AuthError('unverified');
    if (m.includes('invalid') || m.includes('credentials')) throw new AuthError('wrong_password');
    if (m.includes('network') || m.includes('fetch')) throw new AuthError('network');
    throw new AuthError('failed');
  }
}

/** Returns 'verify' when a code was emailed and must be entered before signing in. */
export async function signUpWithPassword(name: string, email: string, password: string, lang = 'en'): Promise<'in' | 'verify'> {
  let res: Response;
  try {
    res = await fetch(`${SUPABASE_URL}/functions/v1/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: SUPABASE_KEY },
      body: JSON.stringify({ name: name.trim(), email: clean(email), password, lang }),
    });
  } catch {
    throw new AuthError('network');
  }
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    if (body.error === 'email_taken') throw new AuthError('email_taken');
    if (body.error === 'invalid_email') throw new AuthError('invalid_email');
    if (body.error === 'weak_password') throw new AuthError('weak_password');
    throw new AuthError('failed');
  }
  const body = (await res.json().catch(() => ({}))) as { verify?: boolean };
  if (body.verify) return 'verify';
  await signInWithPassword(email, password);
  return 'in';
}

async function codeCall(payload: Record<string, unknown>) {
  let res: Response;
  try {
    res = await fetch(`${SUPABASE_URL}/functions/v1/auth-code`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: SUPABASE_KEY },
      body: JSON.stringify(payload),
    });
  } catch {
    throw new AuthError('network');
  }
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    const known = ['invalid_email', 'weak_password', 'wrong_code', 'expired', 'too_many_tries', 'wait', 'too_many', 'email_not_set_up'];
    throw new AuthError((known.includes(body.error ?? '') ? body.error : 'failed') as AuthError['code']);
  }
}

/** Email a fresh 6-digit code ('verify' = confirm email, 'reset' = forgot password). */
export const sendEmailCode = (email: string, purpose: 'verify' | 'reset', lang = 'en') => codeCall({ action: 'send', email: clean(email), purpose, lang });

/** Confirm the email with the code, then sign in. */
export async function verifyEmail(email: string, code: string, password: string) {
  await codeCall({ action: 'verify', email: clean(email), code: code.trim() });
  await signInWithPassword(email, password);
}

/** Set a new password with the emailed code, then sign in with it. */
export async function resetPassword(email: string, code: string, password: string) {
  await codeCall({ action: 'reset', email: clean(email), code: code.trim(), password });
  await signInWithPassword(email, password);
}

export async function changePassword(password: string) {
  const { error } = await supabase.auth.updateUser({ password });
  if (error) throw error;
}

/** 'later' (default): switch the account off now, wipe it after 30 days. 'now': wipe everything immediately. */
export async function deleteAccount(when: 'later' | 'now' = 'later') {
  const { error } = await supabase.functions.invoke('delete-account', { method: 'POST', body: { action: when === 'now' ? 'now' : 'schedule' } });
  if (error) throw error;
  await supabase.auth.signOut();
}

/** Undo a deletion within the 30 days. */
export async function restoreAccount() {
  const { error } = await supabase.functions.invoke('delete-account', { method: 'POST', body: { action: 'restore' } });
  if (error) throw error;
}
