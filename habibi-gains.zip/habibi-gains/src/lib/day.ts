// Small helpers shared by the food screens.
import type { Meal, NUTRIENT_KEYS } from './data';
import { todayISO } from './supabase';

export function shiftDay(day: string, by: number) {
  const [y, m, d] = day.split('-').map(Number);
  return todayISO(new Date(y, m - 1, d + by));
}

export function dayLabel(day: string, lang: string) {
  const today = todayISO();
  if (day === today) return lang === 'ar' ? 'اليوم' : 'Today';
  if (day === shiftDay(today, -1)) return lang === 'ar' ? 'أمس' : 'Yesterday';
  if (day === shiftDay(today, 1)) return lang === 'ar' ? 'بكرة' : 'Tomorrow';
  const [y, m, d] = day.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString(lang === 'ar' ? 'ar-AE' : 'en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
}

export function mealsFor(ramadan: boolean): Meal[] {
  return ramadan ? ['suhoor', 'iftar', 'dinner', 'snack'] : ['breakfast', 'lunch', 'dinner', 'snack'];
}

export function defaultMeal(ramadan: boolean): Meal {
  const h = new Date().getHours();
  if (ramadan) return h >= 17 || h < 2 ? 'iftar' : 'suhoor';
  if (h < 11) return 'breakfast';
  if (h < 16) return 'lunch';
  if (h < 21) return 'dinner';
  return 'snack';
}

export const MEAL_LABEL: Record<Meal, { en: string; ar: string }> = {
  breakfast: { en: 'Breakfast', ar: 'الفطور' },
  lunch: { en: 'Lunch', ar: 'الغداء' },
  dinner: { en: 'Dinner', ar: 'العشاء' },
  snack: { en: 'Snacks', ar: 'سناك' },
  suhoor: { en: 'Suhoor', ar: 'السحور' },
  iftar: { en: 'Iftar', ar: 'الإفطار' },
};

/** Daily macro goals from the calorie target: protein from the plan, ~28% fat, carbs fill the rest. */
export function macroTargets(kcal: number, proteinG: number) {
  const fat = Math.round((kcal * 0.28) / 9);
  const carbs = Math.max(0, Math.round((kcal - proteinG * 4 - fat * 9) / 4));
  return { kcal, protein: proteinG, carbs, fat };
}

/** Reference daily values (adult). Fiber 14 g per 1000 kcal (DGA), sodium < 2300 mg, sat fat < 10% kcal, added/total sugar shown against 50 g. */
export function nutrientGoals(kcal: number) {
  return {
    fiber_g: Math.round((kcal / 1000) * 14),
    sugar_g: 50,
    sodium_mg: 2300,
    sat_fat_g: Math.round((kcal * 0.1) / 9),
    cholesterol_mg: 300,
    potassium_mg: 3400,
  };
}

/** Human description of what was logged, e.g. "2 × 1 cup" or "150 g". */
export function servingText(quantity: number, label: string) {
  const q = Math.round(quantity * 100) / 100;
  if (label === 'g') return `${q} g`;
  if (q === 1) return label;
  return `${q} × ${label}`;
}

export const NUTRIENT_LABEL: Record<(typeof NUTRIENT_KEYS)[number], { en: string; ar: string; unit: string }> = {
  kcal: { en: 'Calories', ar: 'السعرات', unit: 'kcal' },
  protein_g: { en: 'Protein', ar: 'البروتين', unit: 'g' },
  carbs_g: { en: 'Carbohydrates', ar: 'الكربوهيدرات', unit: 'g' },
  fat_g: { en: 'Fat', ar: 'الدهون', unit: 'g' },
  fiber_g: { en: 'Fiber', ar: 'الألياف', unit: 'g' },
  sugar_g: { en: 'Sugar', ar: 'السكر', unit: 'g' },
  sat_fat_g: { en: 'Saturated fat', ar: 'الدهون المشبعة', unit: 'g' },
  sodium_mg: { en: 'Sodium', ar: 'الصوديوم', unit: 'mg' },
  cholesterol_mg: { en: 'Cholesterol', ar: 'الكوليسترول', unit: 'mg' },
  potassium_mg: { en: 'Potassium', ar: 'البوتاسيوم', unit: 'mg' },
};
