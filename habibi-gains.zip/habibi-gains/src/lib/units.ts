// Units: everything is stored metric (kg, cm, ml); these convert for display and input.
export type Units = { weight: 'kg' | 'lb'; height: 'cm' | 'ft'; water: 'l' | 'oz' };
export const DEFAULT_UNITS: Units = { weight: 'kg', height: 'cm', water: 'l' };

const LB = 2.20462;
const ML_PER_OZ = 29.5735;

export const kgTo = (kg: number, u: Units) => (u.weight === 'lb' ? Math.round(kg * LB * 10) / 10 : Math.round(kg * 10) / 10);
export const toKg = (v: number, u: Units) => (u.weight === 'lb' ? v / LB : v);
export const weightLabel = (u: Units) => (u.weight === 'lb' ? 'lb' : 'kg');
export const fmtWeight = (kg: number, u: Units) => `${kgTo(kg, u)} ${weightLabel(u)}`;

/** Height input: cm, or feet + inches. */
export const ftInToCm = (ft: number, inch: number) => Math.round((ft * 30.48 + inch * 2.54) * 10) / 10;
export const cmToFtIn = (cm: number) => {
  const totalIn = cm / 2.54;
  return { ft: Math.floor(totalIn / 12), inch: Math.round(totalIn % 12) };
};

export const fmtWater = (ml: number, u: Units) => (u.water === 'oz' ? `${Math.round(ml / ML_PER_OZ)} fl oz` : `${(ml / 1000).toFixed(2).replace(/0$/, '')} L`);
export const waterSteps = (u: Units) => (u.water === 'oz' ? [-8, 8, 16].map((o) => Math.round(o * ML_PER_OZ)) : [-250, 250, 500]);
export const waterStepLabel = (ml: number, u: Units) => {
  const v = u.water === 'oz' ? Math.round(ml / ML_PER_OZ) : ml;
  return `${ml < 0 ? '−' : '+'}${Math.abs(v)}${u.water === 'oz' ? ' oz' : ''}`;
};

export const unitsOf = (p: { units?: Partial<Units> | null } | null | undefined): Units => ({ ...DEFAULT_UNITS, ...(p?.units ?? {}) });
