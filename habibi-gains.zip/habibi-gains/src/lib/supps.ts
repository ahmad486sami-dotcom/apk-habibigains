// Supplements catalogue: categories (guide text) and products (partner listings).
// Everything lives in the database so admins can edit it in the app without an update.
import { supabase } from './supabase';

export type SuppCategory = {
  id: string;
  name_en: string; name_ar: string;
  tagline_en: string; tagline_ar: string;
  good_for_en: string; good_for_ar: string;
  how_en: string; how_ar: string;
  note_en: string; note_ar: string;
  sources: string;
  icon: string;
  sort: number;
  visible: boolean;
};

export type SuppLink = { label: string; url: string };
export type SuppProduct = {
  id: string;
  category_id: string;
  name: string;
  brand: string | null;
  image_url: string | null;
  blurb_en: string; blurb_ar: string;
  size_label: string | null;
  links: SuppLink[];
  promo_code: string | null;
  partner: boolean;
  sort: number;
  visible: boolean;
};

export const STORE_PRESETS = ['Noon', 'Amazon.ae', 'iHerb', 'Brand store', 'In gyms', 'Pharmacy'];

export async function fetchCatalog(): Promise<{ categories: SuppCategory[]; products: SuppProduct[] }> {
  const [c, p] = await Promise.all([
    supabase.from('supp_categories').select('*').order('sort'),
    supabase.from('supp_products').select('*').order('partner', { ascending: false }).order('sort'),
  ]);
  if (c.error) throw c.error;
  return {
    categories: (c.data ?? []) as SuppCategory[],
    products: ((p.data ?? []) as any[]).map((x) => ({ ...x, links: Array.isArray(x.links) ? x.links : [] })),
  };
}

/** Counted for partner reports. Fire-and-forget. */
export function logTap(productId: string, label: string) {
  supabase.auth.getUser().then(({ data }) => {
    if (data.user) supabase.from('supp_clicks').insert({ product_id: productId, label: label.slice(0, 40), user_id: data.user.id }).then(() => {}, () => {});
  });
}

// ───────── Admin ─────────
export async function saveCategory(c: Partial<SuppCategory> & { id: string }) {
  const { error } = await supabase.from('supp_categories').upsert({ ...c, updated_at: new Date().toISOString() });
  if (error) throw error;
}
export async function deleteCategory(id: string) {
  const { error } = await supabase.from('supp_categories').delete().eq('id', id);
  if (error) throw error;
}
export async function saveProduct(p: Partial<SuppProduct> & { category_id: string; name: string }) {
  const row = { ...p, links: (p.links ?? []).filter((l) => l.label.trim() && /^https?:\/\//i.test(l.url.trim())), updated_at: new Date().toISOString() };
  const q = p.id ? supabase.from('supp_products').update(row).eq('id', p.id) : supabase.from('supp_products').insert(row);
  const { error } = await q;
  if (error) throw error;
}
export async function deleteProduct(id: string) {
  const { error } = await supabase.from('supp_products').delete().eq('id', id);
  if (error) throw error;
}
export async function uploadSuppPhoto(uri: string) {
  const path = `products/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.jpg`;
  const body = await (await fetch(uri)).arrayBuffer();
  const { error } = await supabase.storage.from('supplements').upload(path, body, { contentType: 'image/jpeg', upsert: false });
  if (error) throw error;
  return supabase.storage.from('supplements').getPublicUrl(path).data.publicUrl;
}
/** Taps per product in the last N days (admins only). */
export async function tapStats(days = 30): Promise<Record<string, { taps: number; people: number }>> {
  const { data } = await supabase.rpc('supp_tap_stats', { days });
  const out: Record<string, { taps: number; people: number }> = {};
  ((data ?? []) as any[]).forEach((r) => { out[r.product_id] = { taps: Number(r.taps), people: Number(r.people) }; });
  return out;
}
