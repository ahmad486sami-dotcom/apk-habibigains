// Posts automatic achievements to friends' feed (each one only once, server ignores repeats).
// Respects privacy: nothing about your week or streak is posted if you keep that "Only me".
import { postEvent } from './social';
import { todayISO } from './supabase';
import { buildWeek, weekStart } from './week';

const MILESTONES = [7, 14, 30, 60, 100, 180, 365];

export async function postAutoEvents(profile: any, daily: { day: string; kcal: number }[], exercise: { day: string; kcal: number }[] = []) {
  if (!profile?.username) return;
  const privacy = profile.privacy ?? {};
  const tasks: Promise<unknown>[] = [postEvent('joined', 'joined')];

  if (privacy.streak !== 'only_me') {
    const streak = Number(profile.streak_days ?? 0);
    const start = todayISO(new Date(Date.now() - (streak - 1) * 86_400_000));
    MILESTONES.filter((m) => streak >= m).slice(-1).forEach((m) => tasks.push(postEvent('streak', `${m}-${start}`, { days: m })));
  }

  if (privacy.week !== 'only_me' && profile.calorie_target) {
    // Last full week (finished yesterday or earlier).
    const thisStart = weekStart(new Date(), profile.week_start_day ?? 6);
    const lastDay = new Date(thisStart); lastDay.setDate(lastDay.getDate() - 1);
    const lastIso = todayISO(lastDay);
    const kcal = daily.find((d) => d.day === lastIso)?.kcal ?? 0;
    const w = buildWeek(daily, kcal, profile.calorie_target, 'en', profile.week_start_day ?? 6, lastDay, exercise);
    const key = w.days[0]?.day ?? lastIso;
    if (w.logged === 7) tasks.push(postEvent('week_logged_all', key));
    if (w.logged >= 4 && w.left >= 0) tasks.push(postEvent('week_on_budget', key, { logged: w.logged }));
  }
  await Promise.all(tasks.map((t) => t.catch(() => {})));
}
