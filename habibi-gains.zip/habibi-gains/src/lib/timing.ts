// Timing coach: builds a daily eating and supplement schedule from the user's
// wake time, training time and bedtime.
//
// Evidence base (summarised, see SOURCES):
// • Total daily protein and calories matter most; timing is the next layer.
// • Protein: spread over 3–5 meals of ~0.4 g/kg each; 30–40 g slow protein before bed can support overnight recovery.
// • Carbs: a carb-containing meal 1–4 h before training fuels it; carbs + protein after training help recovery,
//   most important when training again within ~24 h.
// • Creatine monohydrate: 3–5 g daily; consistency matters more than timing.
// • Caffeine: ~3 mg/kg, 30–60 min before training; keep under 400 mg/day for healthy adults
//   and away from bedtime.
// This is general guidance for healthy adults, not medical advice.

export type TimingInput = {
  weightKg: number;
  wake: string; // "07:00"
  sleep: string; // "23:30"
  training: string | null; // "18:00", or null on rest days
  goal: 'lose' | 'maintain' | 'gain';
  proteinTargetG: number;
  ramadan?: { suhoorEnds: Date; iftar: Date } | null;
  useCreatine: boolean;
  useCaffeine: boolean;
};

export type TimingItem = {
  time: string; // "HH:MM"
  kind: 'meal' | 'preworkout' | 'training' | 'postworkout' | 'supplement' | 'bedtime' | 'hydration';
  titleKey: TimingTitle;
  proteinG?: number;
  carbs?: 'low' | 'moderate' | 'high';
  detail: { en: string; ar: string };
};

export type TimingTitle =
  | 'breakfast' | 'lunch' | 'dinner' | 'snack' | 'preWorkout' | 'training' | 'postWorkout'
  | 'creatine' | 'caffeine' | 'beforeBed' | 'suhoor' | 'iftar' | 'water';

const toMin = (hhmm: string) => {
  const [h, m] = hhmm.split(':').map(Number);
  return (h % 24) * 60 + (m || 0);
};
const toHHMM = (min: number) => {
  const m = ((Math.round(min) % 1440) + 1440) % 1440;
  return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
};
const gulfHHMM = (d: Date) =>
  toHHMM(((d.getUTCHours() + 4) % 24) * 60 + d.getUTCMinutes());

export function buildTiming(input: TimingInput): TimingItem[] {
  const perMeal = Math.max(20, Math.min(45, Math.round(input.weightKg * 0.4)));
  const items: TimingItem[] = [];

  if (input.ramadan) return ramadanPlan(input, perMeal);

  const wake = toMin(input.wake);
  let sleep = toMin(input.sleep);
  if (sleep <= wake) sleep += 1440;
  const train = input.training ? (() => { let t = toMin(input.training!); if (t < wake) t += 1440; return t; })() : null;

  // Base meals spread across the waking day.
  const span = sleep - wake;
  const mealTimes = [wake + 45, wake + span * 0.38, wake + span * 0.72];
  const mealKeys: TimingTitle[] = ['breakfast', 'lunch', 'dinner'];

  // A regular meal that lands right after training doubles as the post-workout meal.
  let postMealMerged = false;
  mealTimes.forEach((t, i) => {
    // Skip meals that land just before or during training; the pre-workout meal covers them.
    if (train !== null && t > train - 75 && t < train + 30) return;
    if (train !== null && t >= train + 30 && t <= train + 150) {
      postMealMerged = true;
      items.push({
        time: toHHMM(t),
        kind: 'postworkout',
        titleKey: 'postWorkout',
        proteinG: perMeal,
        carbs: input.goal === 'lose' ? 'moderate' : 'high',
        detail: { en: `${perMeal} g protein with a good carb portion to refill after training.`, ar: `${perMeal} غ بروتين مع حصة كربوهيدرات جيدة لتعويض الطاقة بعد التمرين.` },
      });
      return;
    }
    items.push({
      time: toHHMM(t),
      kind: 'meal',
      titleKey: mealKeys[i],
      proteinG: perMeal,
      carbs: input.goal === 'lose' ? 'low' : 'moderate',
      detail: { en: `${perMeal} g protein, vegetables, and a moderate carb portion.`, ar: `${perMeal} غ بروتين مع خضار وحصة كربوهيدرات معتدلة.` },
    });
  });

  if (train !== null) {
    const early = train - wake < 150; // not enough time for a full meal before training
    items.push(
      early
        ? {
            time: toHHMM(Math.max(wake + 10, train - 45)),
            kind: 'preworkout',
            titleKey: 'preWorkout',
            carbs: 'moderate',
            detail: {
              en: 'Early session: a small, fast snack like a banana or 2–3 dates, or train fasted if that feels better. Eat properly after.',
              ar: 'تمرين مبكر: سناك صغير وسريع مثل موزة أو ٢–٣ تمرات، أو تمرّن صائماً إذا كان أريح لك. وكُل وجبة كاملة بعده.',
            },
          }
        : {
            time: toHHMM(train - 120),
            kind: 'preworkout',
            titleKey: 'preWorkout',
            proteinG: Math.round(perMeal * 0.75),
            carbs: 'high',
            detail: {
              en: 'Carbs + some protein, low in fat and fibre so it digests easily. Example: rice and chicken, or oats with laban.',
              ar: 'كربوهيدرات مع بعض البروتين، قليل الدهون والألياف لسهولة الهضم. مثال: رز ودجاج أو شوفان مع لبن.',
            },
          },
    );
    if (input.useCaffeine) {
      const mg = Math.min(300, Math.round(input.weightKg * 3));
      const late = (sleep - train) < 360;
      items.push({
        time: toHHMM(train - 45),
        kind: 'supplement',
        titleKey: 'caffeine',
        detail: late
          ? { en: `Skip caffeine today: training is within ~6 h of bedtime and it can hurt your sleep.`, ar: 'تجنب الكافيين اليوم: التمرين قريب من موعد النوم وقد يؤثر على نومك.' }
          : { en: `~${mg} mg (about 3 mg/kg), e.g. coffee. Stay under 400 mg/day. Avoid if pregnant, or with heart or blood pressure problems.`, ar: `حوالي ${mg} ملغ (٣ ملغ لكل كغ) مثل القهوة. لا تتجاوز ٤٠٠ ملغ يومياً. تجنبه أثناء الحمل أو مع مشاكل القلب أو الضغط.` },
      });
    }
    items.push({
      time: toHHMM(train),
      kind: 'training',
      titleKey: 'training',
      detail: { en: 'Sip water during training. Add electrolytes if it’s hot or you sweat a lot.', ar: 'اشرب الماء أثناء التمرين. أضف أملاحاً إذا كان الجو حاراً أو تعرّقت كثيراً.' },
    });
    if (!postMealMerged) {
      items.push({
        time: toHHMM(train + 75),
        kind: 'postworkout',
        titleKey: 'postWorkout',
        proteinG: perMeal,
        carbs: input.goal === 'lose' ? 'moderate' : 'high',
        detail: {
          en: `${perMeal} g protein plus carbs within ~2 h. A shake counts if your next meal is far away.`,
          ar: `${perMeal} غ بروتين مع كربوهيدرات خلال ساعتين تقريباً. الشيك يكفي إذا كانت وجبتك التالية بعيدة.`,
        },
      });
    }
  }

  if (input.useCreatine) {
    items.push({
      time: toHHMM(train !== null ? train + 75 : wake + 45),
      kind: 'supplement',
      titleKey: 'creatine',
      detail: {
        en: '3–5 g creatine monohydrate with a meal, every day including rest days. Timing matters less than consistency. Drink enough water. Check with a doctor if you have kidney problems.',
        ar: '٣–٥ غ كرياتين مونوهيدرات مع وجبة يومياً حتى في أيام الراحة. الانتظام أهم من التوقيت. اشرب ماء كافياً. استشر طبيباً إذا عندك مشاكل في الكلى.',
      },
    });
  }

  // Top up protein before bed if the day's meals fall short.
  const planned = items.reduce((s, i) => s + (i.kind !== 'supplement' ? i.proteinG ?? 0 : 0), 0);
  const gap = input.proteinTargetG - planned;
  items.push({
    time: toHHMM(sleep - 60),
    kind: 'bedtime',
    titleKey: 'beforeBed',
    proteinG: gap > 10 ? Math.min(40, Math.max(25, gap)) : undefined,
    carbs: 'low',
    detail: gap > 10
      ? { en: `${Math.min(40, Math.max(25, gap))} g slow protein (Greek yogurt, laban, cottage cheese or casein) closes today’s gap and supports overnight recovery.`, ar: `${Math.min(40, Math.max(25, gap))} غ بروتين بطيء (زبادي يوناني أو لبن أو جبن قريش أو كازين) يكمل احتياجك ويدعم الاستشفاء أثناء النوم.` }
      : { en: 'Protein target met. Keep it light before sleep.', ar: 'وصلت لهدف البروتين. خلّها خفيفة قبل النوم.' },
  });

  return items.sort((a, b) => sortKey(a.time, wake) - sortKey(b.time, wake));
}

function ramadanPlan(input: TimingInput, perMeal: number): TimingItem[] {
  const suhoor = toMin(gulfHHMM(input.ramadan!.suhoorEnds));
  const iftar = toMin(gulfHHMM(input.ramadan!.iftar));
  const items: TimingItem[] = [
    {
      time: toHHMM(iftar), kind: 'meal', titleKey: 'iftar', carbs: 'moderate',
      detail: { en: 'Break the fast with water and 2–3 dates, then pray or rest before the main meal.', ar: 'افطر على ماء و٢–٣ تمرات، ثم صلِّ أو ارتح قبل الوجبة الرئيسية.' },
    },
    {
      time: toHHMM(iftar + 30), kind: 'meal', titleKey: 'dinner', proteinG: perMeal, carbs: 'moderate',
      detail: { en: `Main meal: ${perMeal} g protein, vegetables, and rice or bread. Go easy on fried food and sweets.`, ar: `الوجبة الرئيسية: ${perMeal} غ بروتين مع خضار ورز أو خبز. خفف المقليات والحلويات.` },
    },
  ];
  if (input.training) {
    items.push({
      time: toHHMM(iftar + 120), kind: 'training', titleKey: 'training',
      detail: { en: 'Best training window in Ramadan: 1.5–2 h after iftar, when you’re fuelled and hydrated.', ar: 'أفضل وقت للتمرين في رمضان: بعد الإفطار بساعة ونصف إلى ساعتين، وأنت متغذي ومرتوي.' },
    });
    items.push({
      time: toHHMM(iftar + 210), kind: 'postworkout', titleKey: 'postWorkout', proteinG: perMeal, carbs: 'moderate',
      detail: { en: `${perMeal} g protein after training, e.g. a shake or chicken with rice.`, ar: `${perMeal} غ بروتين بعد التمرين، مثل شيك أو دجاج مع رز.` },
    });
  }
  items.push({
    time: toHHMM(iftar + 60), kind: 'hydration', titleKey: 'water',
    detail: { en: 'Aim for 2–3 litres between iftar and suhoor, spread out, not all at once.', ar: 'استهدف ٢–٣ لتر بين الإفطار والسحور موزعة وليس دفعة واحدة.' },
  });
  if (input.useCreatine) {
    items.push({
      time: toHHMM(iftar + 30), kind: 'supplement', titleKey: 'creatine',
      detail: { en: '3–5 g creatine with your main meal, with plenty of water.', ar: '٣–٥ غ كرياتين مع الوجبة الرئيسية مع ماء كافٍ.' },
    });
  }
  items.push({
    time: toHHMM(suhoor - 45), kind: 'meal', titleKey: 'suhoor', proteinG: Math.max(perMeal, 30), carbs: 'moderate',
    detail: { en: `${Math.max(perMeal, 30)} g slow protein (eggs, laban, Greek yogurt) with slow carbs like oats or brown bread to stay full through the fast.`, ar: `${Math.max(perMeal, 30)} غ بروتين بطيء (بيض، لبن، زبادي يوناني) مع كربوهيدرات بطيئة مثل الشوفان أو الخبز الأسمر لتبقى شبعان أثناء الصيام.` },
  });
  return items.sort((a, b) => sortKey(a.time, iftar) - sortKey(b.time, iftar));
}

function sortKey(hhmm: string, dayStart: number) {
  const m = toMin(hhmm);
  return m < dayStart - 60 ? m + 1440 : m;
}

export const SOURCES = [
  'Kerksick CM et al. ISSN position stand: nutrient timing. J Int Soc Sports Nutr. 2017.',
  'Jäger R et al. ISSN position stand: protein and exercise. J Int Soc Sports Nutr. 2017.',
  'Schoenfeld BJ, Aragon AA. How much protein can the body use in a single meal? J Int Soc Sports Nutr. 2018.',
  'Kreider RB et al. ISSN position stand: safety and efficacy of creatine supplementation. J Int Soc Sports Nutr. 2017.',
  'Guest NS et al. ISSN position stand: caffeine and exercise performance. J Int Soc Sports Nutr. 2021.',
];
