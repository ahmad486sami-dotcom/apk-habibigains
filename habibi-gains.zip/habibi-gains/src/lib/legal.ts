// Privacy Policy and Terms of Use, in plain English and Arabic.
// The same text is published on habibigains.store/privacy and /terms (Apple needs those links).
// Not legal advice: have it reviewed before the App Store launch.

export type LegalDoc = { title: string; updated: string; intro: string; sections: { h: string; p: string[] }[] };
export const LEGAL_UPDATED = '31 October 2026';
export const CONTACT = 'hello@habibigains.store';

const privacyEn: LegalDoc = {
  title: 'Privacy Policy',
  updated: LEGAL_UPDATED,
  intro: 'Habibi Gains is a calorie and fitness tracker made in the UAE. This page explains, in plain words, what we save, why, who can see it, and how to delete it. We never sell your data.',
  sections: [
    { h: 'What we save', p: [
      'Account: your name, email address and password (stored scrambled, we can never see it).',
      'Profile: @username, photo, bio, gym, emirate, goals, units and the privacy choices you make.',
      'Body and progress: height, weight entries, goal weight, and progress photos you add.',
      'Food and activity: the foods you log, water, workouts, step counts from your iPhone, and fasting timers.',
      'Social: friends, friend requests, buddies, groups, challenges, reactions and nudges.',
      'Foods you add or correct, including barcodes you scan.',
    ] },
    { h: 'What we do not take', p: [
      'Your contacts are never uploaded. When you use "Find friends from contacts", numbers are scrambled (hashed) on your phone and only those scrambled codes are compared.',
      'If you turn on "Let friends find me from contacts", we save a scrambled code of your number, never the number itself.',
      'We do not use your location or sell or rent your data to anyone. Partner products are not targeted using your personal data.',
    ] },
    { h: 'Why we use it', p: [
      'To run the app: work out your calorie target, show your day and week, and keep your history.',
      'To run the social features you choose to use.',
      'To keep accounts safe: email codes to confirm your email and reset your password.',
      'To fix bugs and improve food data (for example, a team member checking a scanned product).',
    ] },
    { h: 'Who can see what', p: [
      'Your name, @username, profile photo and bio are public, so friends can find and recognise you.',
      'You choose who sees everything else (gym, streak, steps, weight lost, your week, your food diary): Everyone, Friends, Specific people, or Only me.',
      'Your food diary and weight lost are "Only me" until you change them.',
      'Accountability buddies (up to 3, both must agree) can always see each other\'s food diary.',
      'Group and step leaderboards only show what your privacy settings allow. The UAE and emirate step boards only include people who set steps to Everyone.',
      'Blocked people cannot find you or see your profile.',
    ] },
    { h: 'Services we use', p: [
      'Supabase: stores the app\'s database and photos securely.',
      'Resend: sends our emails (only your email address and the code).',
      'Open Food Facts: when you search or scan a product we do not have yet, the barcode or search words are sent to this free public food database. Nothing about you is sent.',
      'Apple: if paid features are added, payments are handled by Apple. We never see your card.',
      'These providers only process data to run Habibi Gains.',
    ] },
    { h: 'How long we keep it', p: [
      'We keep your data while your account is open. Email codes are deleted once used and expire after 10 minutes.',
      'When you delete your account it is switched off straight away and hidden from everyone. If you sign in again within 30 days you can restore it. After 30 days your profile, logs, photos and social data are permanently deleted, and backups clear within a further 30 days.',
    ] },
    { h: 'Your choices and rights', p: [
      'See and change your data in the app at any time, and change who can see it in Edit profile.',
      'Delete your account: Settings › Delete account (at the bottom). You have 30 days to change your mind, or you can choose to delete everything immediately.',
      `Ask us for a copy of your data or anything else about privacy: ${CONTACT}.`,
    ] },
    { h: 'Health information', p: [
      'Weight, food and body data are personal. We only use them to run your app, never for ads, and they are only shared the ways you choose above.',
      'Habibi Gains is not a medical service. See the Terms of Use.',
    ] },
    { h: 'Age', p: ['Habibi Gains is for people aged 16 and over. If you are younger, please do not create an account.'] },
    { h: 'Changes', p: ['If this policy changes in a way that matters, we will tell you in the app before it applies.'] },
    { h: 'Contact', p: [`Habibi Gains, Abu Dhabi, UAE · ${CONTACT}`] },
  ],
};

const termsEn: LegalDoc = {
  title: 'Terms of Use',
  updated: LEGAL_UPDATED,
  intro: 'By creating an account or using Habibi Gains you agree to these terms. They are short on purpose.',
  sections: [
    { h: 'Not medical advice', p: [
      'Calorie targets, macros, fasting stages and other numbers in the app are general estimates, not medical advice.',
      'Talk to a doctor before big diet changes, long fasts or hard training, especially if you are pregnant, have diabetes, an eating disorder, or any health condition.',
      'Stop and get help if something feels wrong. You use the app at your own risk.',
    ] },
    { h: 'Your account', p: [
      'Use your real email and keep your password private. You are responsible for what happens on your account.',
      'You must be 16 or older.',
      'Your @username must not copy another person or brand, or be offensive. We can change or remove usernames that break this.',
    ] },
    { h: 'Be decent', p: [
      'No harassment, hate, threats, nudity, spam, or shaming people about their bodies or what they eat.',
      'Do not post photos or information about other people without their permission.',
      'Do not try to break, overload, copy or scrape the app or its food data.',
      'We can remove content and suspend or close accounts that break these rules. You can report or block anyone from their profile.',
    ] },
    { h: 'Your content', p: [
      'What you add (photos, foods, logs) stays yours. You let us store and show it only so the app works, and only to the people your privacy settings allow.',
      'Foods you create or correct may be checked by our team and, once approved, shown to other users without your name.',
    ] },
    { h: 'Food data', p: [
      'Food information comes from public databases, users and our own estimates. It can be wrong. Check the label when it matters.',
    ] },
    { h: 'Challenges and stakes', p: [
      'Challenge "stakes" (like "loser buys shawarma") are between friends. We do not handle money or enforce them.',
    ] },
    { h: 'Partner products', p: [
      'Some products shown in the app (for example supplements) are from partner brands that pay us when you view or buy through our link. These are always marked "Partner" or "Sponsored".',
      'Partners never see your personal data, and buying from them is between you and them. Their prices, delivery and refunds are their responsibility.',
    ] },
    { h: 'Paid features', p: [
      'Habibi Gains is free today. If paid features are added, the price and what you get will be shown before you pay, and payments go through Apple under its rules.',
    ] },
    { h: 'Changes and availability', p: [
      'We keep improving the app and may change or remove features. We try to keep it running, but cannot promise it will never be down or lose data.',
      'If these terms change in a way that matters, we will tell you in the app.',
    ] },
    { h: 'Liability', p: [
      'As far as UAE law allows, Habibi Gains is provided "as is" and we are not liable for indirect losses, or for health outcomes from following numbers in the app.',
    ] },
    { h: 'Law', p: ['These terms follow the laws of the United Arab Emirates.'] },
    { h: 'Contact', p: [`Questions: ${CONTACT}`] },
  ],
};

const privacyAr: LegalDoc = {
  title: 'سياسة الخصوصية',
  updated: '٣١ أكتوبر ٢٠٢٦',
  intro: 'Habibi Gains تطبيق لتتبع السعرات واللياقة صُنع في الإمارات. هذه الصفحة تشرح ببساطة ماذا نحفظ، ولماذا، ومن يقدر يشوفه، وكيف تحذفه. نحن لا نبيع بياناتك أبداً.',
  sections: [
    { h: 'ماذا نحفظ', p: [
      'الحساب: اسمك وإيميلك وكلمة المرور (محفوظة مشفّرة ولا نقدر نشوفها).',
      'الملف الشخصي: اسم المستخدم، الصورة، النبذة، النادي، الإمارة، أهدافك، الوحدات وإعدادات الخصوصية.',
      'الجسم والتقدم: الطول، أوزانك، الوزن المستهدف، وصور التقدم اللي تضيفها.',
      'الأكل والنشاط: الأكل المسجل، الماء، التمارين، خطوات الآيفون، ومؤقت الصيام.',
      'الجانب الاجتماعي: الأصحاب، الطلبات، شركاء الالتزام، المجموعات، التحديات، التفاعلات والنكزات.',
      'الأكلات اللي تضيفها أو تصححها، ومنها الباركود الممسوح.',
    ] },
    { h: 'ماذا لا نأخذ', p: [
      'جهات اتصالك لا تُرفع أبداً. عند البحث عن أصحاب من جهات الاتصال، الأرقام تُشفّر على جهازك ونقارن الرموز المشفرة فقط.',
      'إذا فعّلت "خلّ أصحابي يلقوني من جهات الاتصال"، نحفظ رمزاً مشفراً لرقمك وليس الرقم نفسه.',
      'لا نستخدم موقعك، ولا نبيع أو نؤجر بياناتك لأي أحد. منتجات الشركاء لا تُستهدف باستخدام بياناتك الشخصية.',
    ] },
    { h: 'لماذا نستخدمها', p: [
      'لتشغيل التطبيق: حساب هدف السعرات، عرض يومك وأسبوعك، وحفظ سجلك.',
      'لتشغيل المزايا الاجتماعية اللي تختار تستخدمها.',
      'لحماية الحسابات: رموز بالإيميل لتأكيد الإيميل وتغيير كلمة المرور.',
      'لإصلاح الأخطاء وتحسين بيانات الأكل (مثل مراجعة منتج ممسوح).',
    ] },
    { h: 'من يشوف ماذا', p: [
      'اسمك واسم المستخدم وصورتك ونبذتك عامة، عشان أصحابك يلقونك ويعرفونك.',
      'وأنت تختار من يشوف الباقي (النادي، السلسلة، الخطوات، الوزن المفقود، أسبوعك، يومياتك الغذائية): الكل، الأصحاب، أشخاص محددين، أو أنا فقط.',
      'يومياتك الغذائية والوزن المفقود "أنا فقط" إلى أن تغيرها.',
      'شركاء الالتزام (حتى ٣، وبموافقة الطرفين) يشوفون يوميات أكل بعض دائماً.',
      'لوحات الترتيب تعرض فقط ما تسمح به إعداداتك. ترتيب الإمارات والإمارة يشمل فقط من جعل خطواته للكل.',
      'من تحظره لا يقدر يلقاك أو يشوف ملفك.',
    ] },
    { h: 'الخدمات اللي نستخدمها', p: [
      'Supabase: لحفظ قاعدة البيانات والصور بشكل آمن.',
      'Resend: لإرسال الإيميلات (إيميلك والرمز فقط).',
      'Open Food Facts: عند البحث أو مسح منتج غير موجود عندنا، يُرسل الباركود أو كلمات البحث لهذه القاعدة العامة المجانية. لا يُرسل شيء عنك.',
      'Apple: إذا أضفنا مزايا مدفوعة، الدفع يتم عن طريق Apple ولا نشوف بطاقتك.',
      'هذه الجهات تعالج البيانات فقط لتشغيل Habibi Gains.',
    ] },
    { h: 'مدة الحفظ', p: [
      'نحفظ بياناتك طالما حسابك مفتوح. رموز الإيميل تُحذف بعد استخدامها وتنتهي بعد ١٠ دقائق.',
      'عند حذف حسابك يتوقف فوراً ويختفي عن الكل. إذا سجلت دخول خلال ٣٠ يوم تقدر ترجعه. بعد ٣٠ يوم تُحذف بياناتك وصورك وسجلاتك نهائياً، والنسخ الاحتياطية تُمسح خلال ٣٠ يوم إضافية.',
    ] },
    { h: 'خياراتك وحقوقك', p: [
      'تقدر تشوف بياناتك وتغيرها في أي وقت، وتغير من يشوفها من تعديل الملف.',
      'حذف الحساب: الإعدادات › حذف الحساب (في الأسفل). عندك ٣٠ يوم تغير رأيك، أو تقدر تحذف كل شي فوراً.',
      `لطلب نسخة من بياناتك أو أي سؤال عن الخصوصية: ${CONTACT}`,
    ] },
    { h: 'المعلومات الصحية', p: [
      'الوزن والأكل وبيانات الجسم معلومات شخصية. نستخدمها فقط لتشغيل تطبيقك، ولا نستخدمها للإعلانات، ولا تُشارك إلا بالطرق اللي تختارها.',
      'Habibi Gains ليس خدمة طبية. راجع شروط الاستخدام.',
    ] },
    { h: 'العمر', p: ['التطبيق لمن عمرهم ١٦ سنة وأكثر. إذا كنت أصغر، لا تنشئ حساباً.'] },
    { h: 'التغييرات', p: ['إذا تغيرت هذه السياسة بشكل مهم، بنبلغك داخل التطبيق قبل التطبيق.'] },
    { h: 'تواصل معنا', p: [`Habibi Gains، أبوظبي، الإمارات · ${CONTACT}`] },
  ],
};

const termsAr: LegalDoc = {
  title: 'شروط الاستخدام',
  updated: '٣١ أكتوبر ٢٠٢٦',
  intro: 'بإنشاء حساب أو استخدام Habibi Gains أنت توافق على هذه الشروط. خليناها قصيرة عن قصد.',
  sections: [
    { h: 'ليست نصيحة طبية', p: [
      'أهداف السعرات والماكروز ومراحل الصيام وباقي الأرقام تقديرات عامة وليست نصيحة طبية.',
      'استشر طبيبك قبل أي تغيير كبير في الأكل أو صيام طويل أو تمرين قوي، خصوصاً إذا كنتِ حاملاً أو عندك سكري أو اضطراب أكل أو أي حالة صحية.',
      'توقف واطلب المساعدة إذا حسيت بشي غلط. استخدامك للتطبيق على مسؤوليتك.',
    ] },
    { h: 'حسابك', p: [
      'استخدم إيميلك الحقيقي واحفظ كلمة مرورك. أنت مسؤول عما يحدث في حسابك.',
      'لازم يكون عمرك ١٦ سنة أو أكثر.',
      'اسم المستخدم لا يقلد شخصاً أو علامة تجارية ولا يكون مسيئاً. نقدر نغيره أو نحذفه إذا خالف ذلك.',
    ] },
    { h: 'الاحترام', p: [
      'ممنوع التنمر أو الكراهية أو التهديد أو العري أو السبام أو السخرية من أجسام الناس أو أكلهم.',
      'لا تنشر صوراً أو معلومات عن غيرك بدون إذنه.',
      'لا تحاول تخريب التطبيق أو إثقاله أو نسخه أو سحب بيانات الأكل منه.',
      'نقدر نحذف المحتوى ونوقف أو نغلق الحسابات المخالفة. وتقدر تبلغ عن أي أحد أو تحظره من ملفه.',
    ] },
    { h: 'محتواك', p: [
      'ما تضيفه (صور، أكلات، سجلات) يبقى لك. تسمح لنا بحفظه وعرضه فقط لتشغيل التطبيق وللأشخاص اللي تسمح لهم إعداداتك.',
      'الأكلات اللي تنشئها أو تصححها قد يراجعها فريقنا وتظهر للمستخدمين بدون اسمك بعد اعتمادها.',
    ] },
    { h: 'بيانات الأكل', p: ['معلومات الأكل من قواعد بيانات عامة ومن المستخدمين ومن تقديراتنا، وقد تكون غير دقيقة. راجع الملصق عند الحاجة.'] },
    { h: 'التحديات والرهانات', p: ['"رهان" التحدي (مثل: الخسران يعزم شاورما) بين الأصحاب فقط. نحن لا نتعامل بالمال ولا نفرضه.'] },
    { h: 'منتجات الشركاء', p: [
      'بعض المنتجات في التطبيق (مثل المكملات) من علامات شريكة تدفع لنا عند المشاهدة أو الشراء عن طريق رابطنا، وتكون دائماً موسومة بـ "شريك" أو "إعلان".',
      'الشركاء لا يشوفون بياناتك الشخصية، والشراء منهم بينك وبينهم، وهم مسؤولون عن الأسعار والتوصيل والاسترجاع.',
    ] },
    { h: 'المزايا المدفوعة', p: ['Habibi Gains مجاني حالياً. إذا أضفنا مزايا مدفوعة، بيظهر السعر وما تحصل عليه قبل الدفع، والدفع عن طريق Apple وحسب قوانينها.'] },
    { h: 'التغييرات والتوفر', p: [
      'نطور التطبيق باستمرار وقد نغير أو نحذف مزايا. نحاول نخليه شغال دائماً، لكن ما نقدر نضمن أنه ما يتعطل أو تضيع بيانات.',
      'إذا تغيرت الشروط بشكل مهم، بنبلغك داخل التطبيق.',
    ] },
    { h: 'المسؤولية', p: ['بالقدر الذي يسمح به قانون الإمارات، التطبيق مقدم "كما هو" ولسنا مسؤولين عن الخسائر غير المباشرة أو النتائج الصحية من اتباع أرقام التطبيق.'] },
    { h: 'القانون', p: ['تخضع هذه الشروط لقوانين دولة الإمارات العربية المتحدة.'] },
    { h: 'تواصل معنا', p: [`للأسئلة: ${CONTACT}`] },
  ],
};

export const LEGAL = { privacy: { en: privacyEn, ar: privacyAr }, terms: { en: termsEn, ar: termsAr } } as const;
export type LegalKind = keyof typeof LEGAL;
