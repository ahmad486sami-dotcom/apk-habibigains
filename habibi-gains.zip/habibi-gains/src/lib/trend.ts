// Weight trend maths.
// The trend is an exponentially smoothed moving average (the "Hacker's Diet" method):
// daily water swings flatten out, so the line shows real fat loss or gain.

export type WeighIn = { measured_on: string; weight_kg: number };
export type TrendPoint = { date: string; weight: number; trend: number };

const ALPHA = 0.1;
const DAY = 86_400_000;

export function buildTrend(entries: WeighIn[]): TrendPoint[] {
  const sorted = [...entries].sort((a, b) => a.measured_on.localeCompare(b.measured_on));
  const out: TrendPoint[] = [];
  let trend: number | null = null;
  for (const e of sorted) {
    const w = Number(e.weight_kg);
    if (trend === null) trend = w;
    else {
      // Missing days still count, so the trend reacts sensibly after a gap.
      const gap = Math.max(1, Math.round((+new Date(e.measured_on) - +new Date(out[out.length - 1].date)) / DAY));
      const a = 1 - Math.pow(1 - ALPHA, gap);
      trend = trend + a * (w - trend);
    }
    out.push({ date: e.measured_on, weight: w, trend: round1(trend) });
  }
  return out;
}

/** Trend change per day over the last `days` days (least squares). */
export function slopePerDay(points: TrendPoint[], days = 21): number | null {
  if (points.length < 4) return null;
  const end = +new Date(points[points.length - 1].date);
  const recent = points.filter((p) => end - +new Date(p.date) <= days * DAY);
  if (recent.length < 4) return null;
  const xs = recent.map((p) => (+new Date(p.date) - end) / DAY);
  const ys = recent.map((p) => p.trend);
  const mx = avg(xs);
  const my = avg(ys);
  let num = 0;
  let den = 0;
  xs.forEach((x, i) => {
    num += (x - mx) * (ys[i] - my);
    den += (x - mx) * (x - mx);
  });
  return den === 0 ? null : num / den;
}

/** Predicted date to reach the goal, or null if not heading there. */
export function predictGoalDate(points: TrendPoint[], goalKg: number | null | undefined): Date | null {
  if (!goalKg || points.length === 0) return null;
  const slope = slopePerDay(points);
  if (slope === null || Math.abs(slope) < 0.005) return null;
  const current = points[points.length - 1].trend;
  const remaining = goalKg - current;
  if (Math.sign(remaining) !== Math.sign(slope)) return null;
  const daysLeft = remaining / slope;
  if (daysLeft > 730) return null;
  return new Date(Date.now() + daysLeft * DAY);
}

/** Weekly rate as % of body weight. Above ~1%/week is flagged as too fast. */
export function weeklyRatePct(points: TrendPoint[]): number | null {
  const s = slopePerDay(points);
  if (s === null || points.length === 0) return null;
  return ((s * 7) / points[points.length - 1].trend) * 100;
}

export function round1(n: number) {
  return Math.round(n * 10) / 10;
}

function avg(a: number[]) {
  return a.reduce((s, v) => s + v, 0) / a.length;
}
