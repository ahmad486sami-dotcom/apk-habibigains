// Fasting tracker: stored on the phone (no account data needed).
// Body stages are shown as time ranges with an honest "how sure is the science" tag.
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'hg.fasting.v1';

export type FastRecord = { start: number; end: number; goalH: number };
export type FastState = { active: { start: number; goalH: number } | null; history: FastRecord[] };

export const PRESETS = [
  { id: '16:8', goalH: 16 },
  { id: '18:6', goalH: 18 },
  { id: '20:4', goalH: 20 },
  { id: 'OMAD', goalH: 23 },
] as const;

export type Evidence = 'strong' | 'some' | 'animal';
export type Stage = { fromH: number; toH: number | null; en: string; ar: string; bodyEn: string; bodyAr: string; evidence: Evidence };

// Ranges are typical, not exact: they vary with the last meal, activity and the person.
export const STAGES: Stage[] = [
  { fromH: 0, toH: 4, en: 'Digesting', ar: 'الهضم', bodyEn: 'Blood sugar and insulin rise after your meal, then start to fall.', bodyAr: 'يرتفع السكر والإنسولين بعد الوجبة ثم يبدآن بالانخفاض.', evidence: 'strong' },
  { fromH: 4, toH: 12, en: 'Using stored sugar', ar: 'استخدام السكر المخزّن', bodyEn: 'Insulin is low. Your liver releases stored glycogen to keep blood sugar steady.', bodyAr: 'الإنسولين منخفض والكبد يطلق الجلايكوجين المخزّن لتثبيت السكر.', evidence: 'strong' },
  { fromH: 12, toH: 18, en: 'Fat burning picks up', ar: 'زيادة حرق الدهون', bodyEn: 'Usually 12–18 h: more energy comes from fat and ketones start to rise.', bodyAr: 'عادة بين 12 و18 ساعة: طاقة أكثر من الدهون وتبدأ الكيتونات بالارتفاع.', evidence: 'strong' },
  { fromH: 18, toH: 24, en: 'Ketones climb', ar: 'ارتفاع الكيتونات', bodyEn: 'Liver glycogen runs low for many people around 18–24 h and ketone levels keep rising. Timing varies a lot.', bodyAr: 'عند كثير من الناس ينخفض جلايكوجين الكبد بين 18 و24 ساعة وتستمر الكيتونات بالارتفاع. التوقيت يختلف كثيراً.', evidence: 'some' },
  { fromH: 24, toH: null, en: 'Autophagy (claimed)', ar: 'الالتهام الذاتي (ادعاء)', bodyEn: 'Often claimed to start at 16–24 h. In humans this is not well measured; most evidence is from animal and cell studies.', bodyAr: 'يُقال إنه يبدأ بين 16 و24 ساعة، لكنه غير مُقاس جيداً عند البشر؛ أغلب الأدلة من دراسات على الحيوانات والخلايا.', evidence: 'animal' },
];

export const SOURCES = [
  'Cahill GF. Fuel metabolism in starvation. Annu Rev Nutr. 2006.',
  'Anton SD et al. Flipping the metabolic switch. Obesity. 2018.',
  'de Cabo R, Mattson MP. Effects of intermittent fasting on health, aging, and disease. N Engl J Med. 2019.',
];

export async function loadFast(): Promise<FastState> {
  try {
    const v = await AsyncStorage.getItem(KEY);
    if (v) return JSON.parse(v);
  } catch {}
  return { active: null, history: [] };
}

async function save(s: FastState) {
  await AsyncStorage.setItem(KEY, JSON.stringify(s)).catch(() => {});
}

export async function startFast(goalH: number, start = Date.now()) {
  const s = await loadFast();
  s.active = { start, goalH };
  await save(s);
  return s;
}

export async function endFast(end = Date.now()) {
  const s = await loadFast();
  if (!s.active) return s;
  if (end - s.active.start > 30 * 60_000) s.history = [{ start: s.active.start, end, goalH: s.active.goalH }, ...s.history].slice(0, 60);
  s.active = null;
  await save(s);
  return s;
}

/** Logging food ends a running fast automatically. */
export async function endFastIfRunning() {
  const s = await loadFast();
  if (s.active) await endFast();
}

export function stageAt(hours: number) {
  return STAGES.find((st) => hours >= st.fromH && (st.toH === null || hours < st.toH)) ?? STAGES[0];
}

/** Hours fasted per day for the last 7 days (by the day each fast ended). */
export function last7(history: FastRecord[], now = new Date()) {
  const out: { label: string; hours: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
    const next = +d + 86_400_000;
    const hrs = history.filter((f) => f.end >= +d && f.end < next).reduce((m, f) => Math.max(m, (f.end - f.start) / 3_600_000), 0);
    out.push({ label: ['S', 'M', 'T', 'W', 'T', 'F', 'S'][d.getDay()], hours: hrs });
  }
  return out;
}

/** Days in a row (ending today or yesterday) with a fast that hit its goal. */
export function streak(history: FastRecord[], now = new Date()) {
  const hit = new Set(history.filter((f) => (f.end - f.start) / 3_600_000 >= f.goalH).map((f) => new Date(f.end).toDateString()));
  let n = 0;
  const d = new Date(now);
  if (!hit.has(d.toDateString())) d.setDate(d.getDate() - 1);
  while (hit.has(d.toDateString())) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
}
