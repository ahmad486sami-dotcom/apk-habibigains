import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

export const ACCENTS = [
  { id: 'white', hex: '#F5F5F2' },
  { id: 'gold', hex: '#D6B46A' },
  { id: 'cyan', hex: '#3DDCFF' },
  { id: 'red', hex: '#E31B23' },
  { id: 'orange', hex: '#FF6B2C' },
  { id: 'lime', hex: '#C6FF3D' },
  { id: 'pink', hex: '#FF3DCB' },
  { id: 'violet', hex: '#9B7BFF' },
] as const;

export const base = {
  bg: '#000000',
  surface: '#0E0F11',
  card: '#141619',
  cardHigh: '#1B1E22',
  border: '#24272C',
  text: '#F5F5F2',
  muted: '#9BA1A6',
  faint: '#5E6268',
  danger: '#FF5A5A',
  radius: { sm: 12, md: 20, lg: 28, pill: 999 },
  space: (n: number) => n * 4,
};

export const fonts = {
  display: 'SpaceGrotesk_700Bold',
  displayMedium: 'SpaceGrotesk_500Medium',
  body: 'Inter_400Regular',
  bodyMedium: 'Inter_500Medium',
  bodySemi: 'Inter_600SemiBold',
};

function luminance(hex: string) {
  const n = parseInt(hex.slice(1), 16);
  const c = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
}

export type Theme = typeof base & { accent: string; onAccent: string; accentSoft: string };

type Ctx = { theme: Theme; setAccent: (hex: string) => void };
const ThemeCtx = createContext<Ctx | null>(null);
const KEY = 'hg.accent';

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [accent, setAccentState] = useState<string>(ACCENTS[0].hex);

  useEffect(() => {
    AsyncStorage.getItem(KEY).then((v) => v && setAccentState(v)).catch(() => {});
  }, []);

  const value = useMemo<Ctx>(() => {
    const onAccent = luminance(accent) > 0.35 ? '#0A0B0D' : '#FFFFFF';
    return {
      theme: { ...base, accent, onAccent, accentSoft: accent + '26' },
      setAccent: (hex: string) => {
        setAccentState(hex);
        AsyncStorage.setItem(KEY, hex).catch(() => {});
      },
    };
  }, [accent]);

  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeCtx);
  if (!ctx) throw new Error('useTheme outside ThemeProvider');
  return ctx;
}
