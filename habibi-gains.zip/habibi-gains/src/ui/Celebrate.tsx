// Full-screen celebration: badge flips in, confetti bursts, strong haptic.
// Call celebrate({ title, subtitle, icon }) from anywhere.
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { Dimensions, Modal, Pressable, View } from 'react-native';
import Animated, {
  Easing,
  FadeIn,
  FadeOut,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { success } from '@/lib/haptics';
import { useTheme } from '@/theme/theme';
import { Icon, IconName } from './Icon';
import { Txt } from './Txt';

type Payload = { title: string; subtitle?: string; icon?: IconName };
const Ctx = createContext<(p: Payload) => void>(() => {});
export const useCelebrate = () => useContext(Ctx);

const { width: W, height: H } = Dimensions.get('window');

function Piece({ i, color }: { i: number; color: string }) {
  const x = useSharedValue(0);
  const y = useSharedValue(0);
  const r = useSharedValue(0);
  const o = useSharedValue(1);
  useEffect(() => {
    const angle = (i / 28) * Math.PI * 2 + Math.random() * 0.4;
    const dist = 140 + Math.random() * 160;
    x.value = withTiming(Math.cos(angle) * dist, { duration: 900, easing: Easing.out(Easing.cubic) });
    y.value = withSequence(
      withTiming(Math.sin(angle) * dist - 60, { duration: 900, easing: Easing.out(Easing.cubic) }),
      withTiming(H * 0.5, { duration: 1600, easing: Easing.in(Easing.quad) }),
    );
    r.value = withTiming(720 * (Math.random() > 0.5 ? 1 : -1), { duration: 2500 });
    o.value = withDelay(1700, withTiming(0, { duration: 700 }));
  }, [i, x, y, r, o]);
  const s = useAnimatedStyle(() => ({
    opacity: o.value,
    transform: [{ translateX: x.value }, { translateY: y.value }, { rotate: `${r.value}deg` }],
  }));
  const big = i % 3 === 0;
  return (
    <Animated.View
      style={[
        { position: 'absolute', width: big ? 10 : 7, height: big ? 16 : 7, borderRadius: big ? 2 : 4, backgroundColor: color },
        s,
      ]}
    />
  );
}

export function CelebrateProvider({ children }: { children: React.ReactNode }) {
  const { theme } = useTheme();
  const { t } = useI18n();
  const [payload, setPayload] = useState<Payload | null>(null);
  const scale = useSharedValue(0);
  const spin = useSharedValue(0);

  const celebrate = useCallback((p: Payload) => {
    setPayload(p);
    success();
    scale.value = 0;
    spin.value = -180;
    scale.value = withDelay(80, withSpring(1, { damping: 9, stiffness: 140 }));
    spin.value = withDelay(80, withSpring(0, { damping: 12, stiffness: 90 }));
  }, [scale, spin]);

  const badge = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }, { rotateY: `${spin.value}deg` }] }));
  const colors = [theme.accent, theme.text, theme.muted, theme.accent];

  return (
    <Ctx.Provider value={celebrate}>
      {children}
      <Modal visible={!!payload} transparent animationType="none" onRequestClose={() => setPayload(null)}>
        {payload ? (
          <Animated.View entering={FadeIn.duration(200)} exiting={FadeOut.duration(200)} style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.88)' }}>
            <Pressable style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 }} onPress={() => setPayload(null)}>
              <View style={{ position: 'absolute', left: W / 2, top: H / 2 - 60 }}>
                {Array.from({ length: 28 }).map((_, i) => (
                  <Piece key={i} i={i} color={colors[i % colors.length]} />
                ))}
              </View>
              <Animated.View
                style={[
                  {
                    width: 150,
                    height: 150,
                    borderRadius: 75,
                    borderWidth: 6,
                    borderColor: theme.accent,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: theme.card,
                  },
                  badge,
                ]}
              >
                <Icon name={payload.icon ?? 'medal'} size={64} color={theme.accent} stroke={1.8} />
              </Animated.View>
              <Animated.View entering={FadeIn.delay(350)} style={{ alignItems: 'center', gap: 8, marginTop: 28 }}>
                <Txt v="label" muted center>{t('badgeUnlocked')}</Txt>
                <Txt v="h1" center>{payload.title}</Txt>
                {payload.subtitle ? <Txt muted center>{payload.subtitle}</Txt> : null}
              </Animated.View>
            </Pressable>
          </Animated.View>
        ) : null}
      </Modal>
    </Ctx.Provider>
  );
}
