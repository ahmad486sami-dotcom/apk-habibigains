// The 5 story designs (9:16) for Instagram / Snapchat / WhatsApp.
// Each one works as a dark card or a transparent sticker you drop on your own photo.
import React from 'react';
import { View } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import Svg, { Circle, Line, Path, Rect } from 'react-native-svg';
import type { WeekSummary } from '@/lib/week';
import { Avatar } from './Avatar';
import { Txt } from './Txt';

export type DesignId = 'day' | 'plate' | 'bank' | 'progress' | 'profile';
export type Look = 'dark' | 'sticker';

export type ShareInput = {
  lang: string;
  name: string;
  username: string | null;
  avatar_url: string | null;
  gym: string | null;
  dateLabel: string;
  kcal: number;
  target: number;
  macros: { protein: number; carbs: number; fat: number };
  macroTargets: { protein: number; carbs: number; fat: number };
  meals: { label: string; items: { name: string; kcal: number }[] }[];
  week: WeekSummary;
  streak: number;
  kgChange: number | null; // negative = lost, already in the user's unit
  wUnit: string; // 'kg' or 'lb'
  pctChange: number | null;
  trendDays: number;
  trend: { weight: number; trend: number }[];
  stepsWeek: number | null;
  rank: { pos: number; of: number } | null;
  stepsToday: number | null;
};

export type Toggles = {
  macros: boolean; // day
  foods: boolean; // plate: show item names
  numbers: boolean; // bank + day: show kcal numbers
  kg: boolean; // progress: kg (true) or %
  chart: boolean; // progress
  rank: boolean; // progress
  stats: boolean; // profile
  qr: boolean; // profile
};
export const DEFAULT_TOGGLES: Toggles = { macros: true, foods: true, numbers: true, kg: true, chart: true, rank: true, stats: true, qr: true };

const fmt = (n: number) => Math.round(n).toLocaleString('en-US');
const W_ = 'rgba(255,255,255,';

type P = { d: ShareInput; w: number; look: Look; accent: string; t: Toggles };

function Frame({ w, look, children, pad = 0.075 }: { w: number; look: Look; children: React.ReactNode; pad?: number }) {
  const h = (w * 16) / 9;
  return (
    <View style={{ width: w, height: h, backgroundColor: look === 'sticker' ? 'transparent' : '#0A0B0D', padding: w * pad, justifyContent: 'space-between', overflow: 'hidden' }}>
      {children}
    </View>
  );
}

function Brand({ d, w, accent, dark = false }: { d: ShareInput; w: number; accent: string; dark?: boolean }) {
  const c = dark ? '#0A0B0D' : '#FFFFFF';
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: w * 0.02 }}>
        <View style={{ width: w * 0.035, height: w * 0.035, borderRadius: w * 0.01, backgroundColor: accent }} />
        <Txt v="label" color={c} style={{ letterSpacing: 2, fontSize: w * 0.036 }}>HABIBI GAINS</Txt>
      </View>
      <Txt v="small" color={dark ? '#555' : W_ + '0.6)'} style={{ fontSize: w * 0.034 }}>{d.dateLabel}</Txt>
    </View>
  );
}

function Handle({ d, w, dark = false }: { d: ShareInput; w: number; dark?: boolean }) {
  return (
    <Txt v="small" center color={dark ? '#555' : W_ + '0.55)'} style={{ fontSize: w * 0.034 }}>
      {d.username ? `@${d.username} · habibigains.store` : 'habibigains.store'}
    </Txt>
  );
}

function StaticRing({ size, stroke, p, color }: { size: number; stroke: number; p: number; color: string }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(1, p));
  return (
    <Svg width={size} height={size} style={{ position: 'absolute' }}>
      <Circle cx={size / 2} cy={size / 2} r={r} stroke={W_ + '0.12)'} strokeWidth={stroke} fill="none" />
      <Circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={stroke} fill="none" strokeLinecap="round"
        strokeDasharray={`${c * v} ${c}`} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
    </Svg>
  );
}

// 1 ─ My day: one big ring, under/over, macros.
export function DayDesign({ d, w, look, accent, t }: P) {
  const ar = d.lang === 'ar';
  const left = d.target - d.kcal;
  const size = w * 0.66;
  const over = left < 0;
  const bar = (label: string, v: number, goal: number) => (
    <View style={{ flex: 1, gap: w * 0.015 }}>
      <Txt v="small" color={W_ + '0.6)'} style={{ fontSize: w * 0.032 }}>{label}</Txt>
      <View style={{ height: w * 0.018, borderRadius: w, backgroundColor: W_ + '0.12)' }}>
        <View style={{ width: `${Math.min(100, (v / Math.max(1, goal)) * 100)}%`, height: '100%', borderRadius: w, backgroundColor: accent }} />
      </View>
      <Txt v="bodyStrong" color="#FFF" style={{ fontSize: w * 0.04 }}>{`${Math.round(v)}g`}</Txt>
    </View>
  );
  return (
    <Frame w={w} look={look}>
      <Brand d={d} w={w} accent={accent} />
      <View style={{ alignItems: 'center', gap: w * 0.05 }}>
        <Txt v="label" color={W_ + '0.6)'} style={{ letterSpacing: 3, fontSize: w * 0.036 }}>{ar ? 'يومي' : 'MY DAY'}</Txt>
        <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
          <StaticRing size={size} stroke={w * 0.055} p={d.kcal / Math.max(1, d.target)} color={over ? '#FF7A59' : accent} />
          {t.numbers ? (
            <>
              <Txt v="h1" color="#FFF" style={{ fontSize: w * 0.16, lineHeight: w * 0.18 }}>{fmt(d.kcal)}</Txt>
              <Txt v="small" color={W_ + '0.6)'} style={{ fontSize: w * 0.036 }}>{`/ ${fmt(d.target)} kcal`}</Txt>
            </>
          ) : <Txt v="h1" color="#FFF" style={{ fontSize: w * 0.12 }}>{over ? '😅' : '✅'}</Txt>}
        </View>
        <Txt v="h2" color={over ? '#FF7A59' : accent} style={{ fontSize: w * 0.07 }}>
          {over ? (ar ? `زيادة ${fmt(-left)}` : `${fmt(-left)} OVER`) : ar ? `تحت الهدف بـ ${fmt(left)}` : `${fmt(left)} UNDER`}
        </Txt>
        {t.macros ? (
          <View style={{ flexDirection: 'row', gap: w * 0.05, alignSelf: 'stretch' }}>
            {bar(ar ? 'بروتين' : 'Protein', d.macros.protein, d.macroTargets.protein)}
            {bar(ar ? 'كارب' : 'Carbs', d.macros.carbs, d.macroTargets.carbs)}
            {bar(ar ? 'دهون' : 'Fat', d.macros.fat, d.macroTargets.fat)}
          </View>
        ) : null}
      </View>
      <Handle d={d} w={w} />
    </Frame>
  );
}

// 2 ─ My plate: the day as a shop receipt.
export function PlateDesign({ d, w, look, accent, t }: P) {
  const ar = d.lang === 'ar';
  const paper = '#F7F5EF';
  const ink = '#0A0B0D';
  const mono = { fontFamily: 'Courier', fontSize: w * 0.034 } as const;
  const dash = <View style={{ borderBottomWidth: 1, borderStyle: 'dashed', borderColor: '#999', marginVertical: w * 0.02 }} />;
  const items = d.meals.flatMap((m) => m.items);
  const maxRows = 14;
  let rows = 0;
  return (
    <Frame w={w} look={look} pad={0.06}>
      <Brand d={d} w={w} accent={accent} />
      <View style={{ backgroundColor: paper, borderRadius: w * 0.02, padding: w * 0.06, transform: [{ rotate: '-1.5deg' }] }}>
        <Txt v="h3" color={ink} center style={{ letterSpacing: 2, fontSize: w * 0.05 }}>{ar ? 'فاتورة اليوم' : "TODAY'S RECEIPT"}</Txt>
        <Txt color="#555" center style={mono}>{d.dateLabel}</Txt>
        {dash}
        {d.meals.filter((m) => m.items.length).map((m) => {
          if (rows >= maxRows) return null;
          const shown = t.foods ? m.items.slice(0, Math.max(0, maxRows - rows)) : [];
          rows += shown.length + 1;
          const total = m.items.reduce((a, i) => a + i.kcal, 0);
          return (
            <View key={m.label} style={{ marginBottom: w * 0.015 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Txt color={ink} style={[mono, { fontWeight: '700' }]}>{m.label.toUpperCase()}</Txt>
                {!t.foods ? <Txt color={ink} style={mono}>{fmt(total)}</Txt> : null}
              </View>
              {shown.map((i, k) => (
                <View key={k} style={{ flexDirection: 'row', justifyContent: 'space-between', gap: w * 0.03 }}>
                  <Txt color="#333" numberOfLines={1} style={[mono, { flex: 1 }]}>{`  ${i.name}`}</Txt>
                  <Txt color="#333" style={mono}>{fmt(i.kcal)}</Txt>
                </View>
              ))}
            </View>
          );
        })}
        {!items.length ? <Txt color="#555" center style={mono}>{ar ? 'ما في أكل مسجل' : 'Nothing logged yet'}</Txt> : null}
        {dash}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Txt color={ink} style={[mono, { fontWeight: '700', fontSize: w * 0.042 }]}>{ar ? 'المجموع' : 'TOTAL'}</Txt>
          <Txt color={ink} style={[mono, { fontWeight: '700', fontSize: w * 0.042 }]}>{`${fmt(d.kcal)} kcal`}</Txt>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Txt color="#555" style={mono}>{ar ? 'الهدف' : 'BUDGET'}</Txt>
          <Txt color="#555" style={mono}>{fmt(d.target)}</Txt>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Txt color="#555" style={mono}>{ar ? 'الباقي' : 'CHANGE'}</Txt>
          <Txt color={d.target - d.kcal < 0 ? '#D3462B' : '#1B8A3A'} style={[mono, { fontWeight: '700' }]}>{fmt(d.target - d.kcal)}</Txt>
        </View>
        {dash}
        <Txt color="#555" center style={mono}>{`P ${Math.round(d.macros.protein)}g · C ${Math.round(d.macros.carbs)}g · F ${Math.round(d.macros.fat)}g`}</Txt>
        <Txt color={ink} center style={[mono, { marginTop: w * 0.02 }]}>{ar ? 'شكراً لزيارتكم 💪' : 'THANK YOU, COME AGAIN 💪'}</Txt>
      </View>
      <Handle d={d} w={w} />
    </Frame>
  );
}

// 3 ─ Calorie bank: this week's bars against the daily target, balance in the "bank".
export function BankDesign({ d, w, look, accent, t }: P) {
  const ar = d.lang === 'ar';
  const inner = w * 0.85;
  const chartH = w * 0.62;
  const days = d.week.days;
  const max = Math.max(d.target * 1.4, ...days.map((x) => x.kcal));
  const barW = (inner / 7) * 0.56;
  const targetY = chartH * (1 - d.target / max);
  const bal = d.week.left;
  return (
    <Frame w={w} look={look}>
      <Brand d={d} w={w} accent={accent} />
      <View style={{ gap: w * 0.04 }}>
        <Txt v="label" color={W_ + '0.6)'} style={{ letterSpacing: 3, fontSize: w * 0.036 }}>{ar ? 'بنك السعرات' : 'CALORIE BANK'}</Txt>
        <Txt v="h1" color={bal >= 0 ? accent : '#FF7A59'} style={{ fontSize: w * 0.15, lineHeight: w * 0.17 }}>
          {t.numbers ? `${bal >= 0 ? '+' : '−'}${fmt(Math.abs(bal))}` : bal >= 0 ? (ar ? 'ضمن الميزانية' : 'ON BUDGET') : ar ? 'فوق' : 'OVER'}
        </Txt>
        <Txt color="#FFF" style={{ fontSize: w * 0.042 }}>
          {bal >= 0 ? (ar ? 'سعرة باقية في البنك هالأسبوع' : 'kcal left in the bank this week') : ar ? 'سعرة فوق الميزانية' : 'kcal over budget this week'}
        </Txt>
        <View style={{ height: chartH, width: inner, marginTop: w * 0.03 }}>
          <Svg width={inner} height={chartH}>
            <Line x1={0} x2={inner} y1={targetY} y2={targetY} stroke={W_ + '0.35)'} strokeWidth={1.5} strokeDasharray="6 6" />
            {days.map((x, i) => {
              const cx = (inner / 7) * i + (inner / 7 - barW) / 2;
              const h = x.kcal > 0 ? Math.max(4, (x.kcal / max) * chartH) : 4;
              const fill = x.status === 'over' ? '#FF7A59' : x.status === 'under' ? accent : W_ + '0.15)';
              return <Rect key={x.day} x={cx} y={chartH - h} width={barW} height={h} rx={barW / 3} fill={fill} />;
            })}
          </Svg>
        </View>
        <View style={{ flexDirection: 'row', width: inner }}>
          {days.map((x) => (
            <Txt key={x.day} v="small" center color={x.isToday ? '#FFF' : W_ + '0.5)'} style={{ flex: 1, fontSize: w * 0.034 }}>{x.label}</Txt>
          ))}
        </View>
        <Txt v="small" color={W_ + '0.6)'} style={{ fontSize: w * 0.034 }}>
          {ar ? `${d.week.logged} من ٧ أيام مسجلة · الخط = هدفي اليومي` : `${d.week.logged}/7 days logged · dashed line = my daily target`}
        </Txt>
      </View>
      <Handle d={d} w={w} />
    </Frame>
  );
}

// 4 ─ Progress: weight change, trend line, steps rank among friends.
export function ProgressDesign({ d, w, look, accent, t }: P) {
  const ar = d.lang === 'ar';
  const inner = w * 0.85;
  const chartH = w * 0.42;
  const big = t.kg
    ? d.kgChange != null ? `${d.kgChange > 0 ? '+' : '−'}${Math.abs(d.kgChange).toFixed(1)} ${d.wUnit}` : '—'
    : d.pctChange != null ? `${d.pctChange > 0 ? '+' : '−'}${Math.abs(d.pctChange).toFixed(1)}%` : '—';
  const path = (() => {
    const pts = d.trend;
    if (pts.length < 2) return '';
    const vals = pts.map((p) => p.trend);
    const min = Math.min(...vals) - 0.2;
    const max = Math.max(...vals) + 0.2;
    return pts.map((p, i) => `${i ? 'L' : 'M'}${(i / (pts.length - 1)) * inner},${(1 - (p.trend - min) / (max - min || 1)) * chartH}`).join(' ');
  })();
  return (
    <Frame w={w} look={look}>
      <Brand d={d} w={w} accent={accent} />
      <View style={{ gap: w * 0.035 }}>
        <Txt v="label" color={W_ + '0.6)'} style={{ letterSpacing: 3, fontSize: w * 0.036 }}>{ar ? 'تقدمي' : 'MY PROGRESS'}</Txt>
        <Txt v="h1" color={accent} style={{ fontSize: w * 0.17, lineHeight: w * 0.19 }}>{big}</Txt>
        <Txt color="#FFF" style={{ fontSize: w * 0.045 }}>{ar ? `في ${d.trendDays} يوم` : `in ${d.trendDays} days`}</Txt>
        {t.chart && path ? (
          <Svg width={inner} height={chartH} style={{ marginTop: w * 0.02 }}>
            <Path d={path} stroke={accent} strokeWidth={w * 0.012} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        ) : null}
        <View style={{ flexDirection: 'row', gap: w * 0.03, marginTop: w * 0.02 }}>
          <Stat w={w} v={`${d.streak}🔥`} l={ar ? 'سلسلة' : 'day streak'} />
          <Stat w={w} v={`${d.week.logged}/7`} l={ar ? 'أيام مسجلة' : 'days logged'} />
          {d.stepsWeek != null ? <Stat w={w} v={d.stepsWeek >= 10000 ? `${Math.round(d.stepsWeek / 1000)}k` : fmt(d.stepsWeek)} l={ar ? 'خطوات الأسبوع' : 'steps / week'} /> : null}
        </View>
        {t.rank && d.rank && d.rank.of > 1 ? (
          <View style={{ alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: w * 0.02, paddingHorizontal: w * 0.04, paddingVertical: w * 0.022, borderRadius: w, backgroundColor: accent }}>
            <Txt v="bodyStrong" color="#0A0B0D" style={{ fontSize: w * 0.04 }}>
              {ar ? `#${d.rank.pos} من ${d.rank.of} بين أصحابي في الخطوات` : `#${d.rank.pos} of ${d.rank.of} friends in steps this week`}
            </Txt>
          </View>
        ) : null}
      </View>
      <Handle d={d} w={w} />
    </Frame>
  );
}

function Stat({ w, v, l }: { w: number; v: string; l: string }) {
  return (
    <View style={{ flex: 1, backgroundColor: W_ + '0.08)', borderRadius: w * 0.04, padding: w * 0.035, gap: 2 }}>
      <Txt v="h2" color="#FFF" style={{ fontSize: w * 0.06 }}>{v}</Txt>
      <Txt v="small" color={W_ + '0.6)'} style={{ fontSize: w * 0.03 }}>{l}</Txt>
    </View>
  );
}

// 5 ─ Profile: player card with a QR code so people can add you straight from your story.
export function ProfileDesign({ d, w, look, accent, t }: P) {
  const ar = d.lang === 'ar';
  const card = w * 0.86;
  return (
    <Frame w={w} look={look}>
      <Brand d={d} w={w} accent={accent} />
      <View style={{ width: card, alignSelf: 'center', borderRadius: w * 0.06, overflow: 'hidden', borderWidth: 2, borderColor: accent, backgroundColor: '#121418' }}>
        <View style={{ height: w * 0.22, backgroundColor: accent }} />
        <View style={{ alignItems: 'center', marginTop: -w * 0.13, padding: w * 0.05, gap: w * 0.015 }}>
          <View style={{ borderWidth: 4, borderColor: '#121418', borderRadius: w }}>
            <Avatar url={d.avatar_url} name={d.name} size={w * 0.24} />
          </View>
          <Txt v="h1" color="#FFF" center style={{ fontSize: w * 0.075 }}>{d.name}</Txt>
          {d.username ? <Txt color={W_ + '0.6)'} style={{ fontSize: w * 0.04 }}>{`@${d.username}`}</Txt> : null}
          {d.gym ? <Txt v="bodyStrong" color={accent} style={{ fontSize: w * 0.04 }}>{`🏋️ ${d.gym}`}</Txt> : null}
          {t.stats ? (
            <View style={{ flexDirection: 'row', gap: w * 0.025, marginTop: w * 0.03, alignSelf: 'stretch' }}>
              <Stat w={w} v={`${d.streak}🔥`} l={ar ? 'سلسلة' : 'streak'} />
              {d.kgChange != null && d.kgChange < 0 ? <Stat w={w} v={`${Math.abs(d.kgChange).toFixed(1)}${d.wUnit}`} l={ar ? 'خسرت' : 'lost'} /> : null}
              <Stat w={w} v={`${d.week.logged}/7`} l={ar ? 'هالأسبوع' : 'this week'} />
            </View>
          ) : null}
          {t.qr && d.username ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: w * 0.04, marginTop: w * 0.04, backgroundColor: '#FFF', borderRadius: w * 0.04, padding: w * 0.03, alignSelf: 'stretch' }}>
              <QRCode value={`habibigains://u/${d.username}`} size={w * 0.2} color="#0A0B0D" backgroundColor="#FFFFFF" />
              <View style={{ flex: 1 }}>
                <Txt v="bodyStrong" color="#0A0B0D" style={{ fontSize: w * 0.042 }}>{ar ? 'ضيفني' : 'Add me'}</Txt>
                <Txt v="small" color="#555" style={{ fontSize: w * 0.032 }}>{ar ? 'امسح الكود في Habibi Gains' : 'Scan in Habibi Gains · Profile › Scan'}</Txt>
              </View>
            </View>
          ) : null}
        </View>
      </View>
      <Handle d={d} w={w} />
    </Frame>
  );
}

export const DESIGNS: { id: DesignId; en: string; ar: string; C: (p: P) => React.ReactElement; toggles: (keyof Toggles)[] }[] = [
  { id: 'day', en: 'My day', ar: 'يومي', C: DayDesign, toggles: ['numbers', 'macros'] },
  { id: 'plate', en: 'Receipt', ar: 'الفاتورة', C: PlateDesign, toggles: ['foods'] },
  { id: 'bank', en: 'Calorie bank', ar: 'بنك السعرات', C: BankDesign, toggles: ['numbers'] },
  { id: 'progress', en: 'Progress', ar: 'التقدم', C: ProgressDesign, toggles: ['kg', 'chart', 'rank'] },
  { id: 'profile', en: 'Profile card', ar: 'بطاقتي', C: ProfileDesign, toggles: ['stats', 'qr'] },
];

export const TOGGLE_LABEL: Record<keyof Toggles, { en: string; ar: string }> = {
  macros: { en: 'Macros', ar: 'الماكروز' },
  foods: { en: 'Show foods', ar: 'اعرض الأكل' },
  numbers: { en: 'Show numbers', ar: 'اعرض الأرقام' },
  kg: { en: 'Weight (off = %)', ar: 'الوزن (أو %)' },
  chart: { en: 'Trend line', ar: 'خط التقدم' },
  rank: { en: 'Friends rank', ar: 'ترتيبي' },
  stats: { en: 'Stats', ar: 'الإحصائيات' },
  qr: { en: 'QR code', ar: 'كود QR' },
};
