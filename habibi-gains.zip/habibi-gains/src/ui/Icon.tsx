import React from 'react';
import Svg, { Circle, Path, Rect } from 'react-native-svg';
import { useTheme } from '@/theme/theme';

export type IconName =
  | 'home' | 'food' | 'plus' | 'chart' | 'run' | 'camera' | 'scan' | 'search' | 'flame' | 'scale'
  | 'star' | 'trend' | 'fork' | 'settings' | 'close' | 'chevron' | 'check' | 'share' | 'clock'
  | 'moon' | 'pill' | 'bolt' | 'trash' | 'lock' | 'pin' | 'sparkle' | 'medal' | 'book' | 'info' | 'user' | 'mic' | 'users' | 'bell' | 'qr' | 'block';

/** Simple stroke icons, drawn for this app. */
export function Icon({ name, size = 22, color, stroke = 2 }: { name: IconName; size?: number; color?: string; stroke?: number }) {
  const { theme } = useTheme();
  const c = color ?? theme.text;
  const p = { stroke: c, strokeWidth: stroke, fill: 'none', strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };
  const body = (() => {
    switch (name) {
      case 'user': return <><Circle {...p} cx={12} cy={8} r={4} /><Path {...p} d="M4 21c1-4 4.5-6 8-6s7 2 8 6" /></>;
      case 'users': return <><Circle {...p} cx={9} cy={8} r={3.5} /><Path {...p} d="M2.5 20c.8-3.5 3.5-5 6.5-5s5.7 1.5 6.5 5M16 4.5a3.5 3.5 0 0 1 0 7M18 15c2 .6 3.2 2.2 3.5 5" /></>;
      case 'bell': return <Path {...p} d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15zM10 20.5a2 2 0 0 0 4 0" />;
      case 'qr': return <><Rect {...p} x={4} y={4} width={6} height={6} rx={1} /><Rect {...p} x={14} y={4} width={6} height={6} rx={1} /><Rect {...p} x={4} y={14} width={6} height={6} rx={1} /><Path {...p} d="M14 14h2v2h-2zM18 18h2v2h-2zM14 20h2M20 14v2" /></>;
      case 'block': return <><Circle {...p} cx={12} cy={12} r={8.5} /><Path {...p} d="M6 6l12 12" /></>;
      case 'mic': return <><Rect {...p} x={9} y={3} width={6} height={11} rx={3} /><Path {...p} d="M5 11a7 7 0 0 0 14 0M12 18v3" /></>;
      case 'home': return <Path {...p} d="M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-4v-6h-6v6H5a1 1 0 0 1-1-1z" />;
      case 'food': return <><Path {...p} d="M7 3v8a2 2 0 0 0 4 0V3M9 11v10" /><Path {...p} d="M17 3c-2 0-3 3-3 6s1 4 3 4v8" /></>;
      case 'plus': return <Path {...p} d="M12 5v14M5 12h14" />;
      case 'chart': return <Path {...p} d="M4 19h16M5 15l4-4 4 3 6-7" />;
      case 'run': return <><Circle {...p} cx={14} cy={4.5} r={1.5} /><Path {...p} d="M6 20l3.5-5 3 2.5L14 13l3 3h3M9 9l3-2 3 2-2.5 4" /></>;
      case 'camera': return <><Path {...p} d="M4 8h3l2-3h6l2 3h3v11H4z" /><Circle {...p} cx={12} cy={13} r={3.5} /></>;
      case 'scan': return <Path {...p} d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M7 12h10" />;
      case 'search': return <><Circle {...p} cx={11} cy={11} r={6} /><Path {...p} d="M20 20l-4.5-4.5" /></>;
      case 'flame': return <Path {...p} d="M12 3c1 4 5 6 5 11a5 5 0 0 1-10 0c0-3 2-4 2-7 2 1 3 3 3 5" />;
      case 'scale': return <><Rect {...p} x={4} y={4} width={16} height={16} rx={4} /><Path {...p} d="M9 9a4 4 0 0 1 6 0M12 9l1.5-1.5" /></>;
      case 'star': return <Path {...p} d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.4 6.7 19.4l1.2-6L3.4 9.3l6-.7z" />;
      case 'trend': return <Path {...p} d="M4 7l6 6 4-4 6 6M20 15v-4M20 15h-4" />;
      case 'fork': return <Path {...p} d="M8 3v7a2 2 0 0 0 4 0V3M10 12v9M16 3v18M16 3c2 1 3 3 3 6h-3" />;
      case 'settings': return <><Circle {...p} cx={12} cy={12} r={3} /><Path {...p} d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4" /></>;
      case 'close': return <Path {...p} d="M6 6l12 12M18 6L6 18" />;
      case 'chevron': return <Path {...p} d="M9 6l6 6-6 6" />;
      case 'check': return <Path {...p} d="M5 12.5l4.5 4.5L19 7" />;
      case 'share': return <Path {...p} d="M12 15V3M7 8l5-5 5 5M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6" />;
      case 'clock': return <><Circle {...p} cx={12} cy={12} r={8.5} /><Path {...p} d="M12 7.5V12l3 2" /></>;
      case 'moon': return <Path {...p} d="M19 15.5A8 8 0 0 1 8.5 5 7.5 7.5 0 1 0 19 15.5z" />;
      case 'pill': return <><Rect {...p} x={3.5} y={8.5} width={17} height={7} rx={3.5} transform="rotate(-35 12 12)" /><Path {...p} d="M10 8.5l4 7" /></>;
      case 'bolt': return <Path {...p} d="M13 3L5 13.5h6L10 21l8-10.5h-6z" />;
      case 'trash': return <Path {...p} d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13" />;
      case 'lock': return <><Rect {...p} x={5} y={10.5} width={14} height={10} rx={2.5} /><Path {...p} d="M8 10.5V8a4 4 0 0 1 8 0v2.5" /></>;
      case 'pin': return <><Path {...p} d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z" /><Circle {...p} cx={12} cy={9.5} r={2.5} /></>;
      case 'sparkle': return <Path {...p} d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 17l.8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8z" />;
      case 'medal': return <><Circle {...p} cx={12} cy={14.5} r={5.5} /><Path {...p} d="M8.5 9.8L6 3h4l2 4.5L14 3h4l-2.5 6.8" /></>;
      case 'book': return <Path {...p} d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2zM4 19V5M8 7h7" />;
      case 'info': return <><Circle {...p} cx={12} cy={12} r={8.5} /><Path {...p} d="M12 11v5M12 7.8v.2" /></>;
    }
  })();
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24">
      {body}
    </Svg>
  );
}
