import React from 'react';
import { StyleProp, Text, TextProps, TextStyle } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { fonts, useTheme } from '@/theme/theme';

type Variant = 'hero' | 'h1' | 'h2' | 'h3' | 'body' | 'bodyStrong' | 'small' | 'label' | 'number';

const styles: Record<Variant, TextStyle> = {
  hero: { fontFamily: fonts.display, fontSize: 44, lineHeight: 46, letterSpacing: -1.5 },
  h1: { fontFamily: fonts.display, fontSize: 32, lineHeight: 36, letterSpacing: -1 },
  h2: { fontFamily: fonts.display, fontSize: 24, lineHeight: 28, letterSpacing: -0.5 },
  h3: { fontFamily: fonts.display, fontSize: 18, lineHeight: 22, letterSpacing: -0.2 },
  body: { fontFamily: fonts.body, fontSize: 15, lineHeight: 22 },
  bodyStrong: { fontFamily: fonts.bodySemi, fontSize: 15, lineHeight: 22 },
  small: { fontFamily: fonts.body, fontSize: 13, lineHeight: 18 },
  label: { fontFamily: fonts.bodySemi, fontSize: 11, lineHeight: 14, letterSpacing: 1.4, textTransform: 'uppercase' },
  number: { fontFamily: fonts.display, fontSize: 48, lineHeight: 50, letterSpacing: -1.5 },
};

export function Txt({
  v = 'body',
  color,
  muted,
  faint,
  center,
  style,
  ...rest
}: TextProps & { v?: Variant; color?: string; muted?: boolean; faint?: boolean; center?: boolean; style?: StyleProp<TextStyle> }) {
  const { theme } = useTheme();
  const { isRTL } = useI18n();
  const c = color ?? (faint ? theme.faint : muted ? theme.muted : theme.text);
  const base = styles[v];
  // Latin display fonts have no Arabic glyphs; let the system font take over and drop tight tracking.
  const rtlFix: TextStyle = isRTL ? { letterSpacing: 0, fontFamily: undefined, fontWeight: v === 'body' || v === 'small' ? '400' : '700' } : {};
  return (
    <Text
      {...rest}
      style={[base, { color: c, textAlign: center ? 'center' : isRTL ? 'right' : 'left', writingDirection: isRTL ? 'rtl' : 'ltr' }, rtlFix, style]}
    />
  );
}
