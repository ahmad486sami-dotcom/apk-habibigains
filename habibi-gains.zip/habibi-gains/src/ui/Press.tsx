import React from 'react';
import { ActivityIndicator, Pressable, PressableProps, StyleProp, View, ViewStyle } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { tap } from '@/lib/haptics';
import { useTheme } from '@/theme/theme';
import { Txt } from './Txt';

const APressable = Animated.createAnimatedComponent(Pressable);

/** Any pressable surface that squishes slightly and ticks on press. */
export function Press({
  style,
  children,
  scaleTo = 0.96,
  haptic = true,
  onPress,
  ...rest
}: PressableProps & { style?: StyleProp<ViewStyle>; scaleTo?: number; haptic?: boolean; children?: React.ReactNode }) {
  const s = useSharedValue(1);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: s.value }] }));
  return (
    <APressable
      {...rest}
      accessibilityRole={rest.accessibilityRole ?? 'button'}
      onPressIn={(e) => {
        s.value = withSpring(scaleTo, { damping: 18, stiffness: 400 });
        rest.onPressIn?.(e);
      }}
      onPressOut={(e) => {
        s.value = withSpring(1, { damping: 14, stiffness: 300 });
        rest.onPressOut?.(e);
      }}
      onPress={(e) => {
        if (haptic) tap();
        onPress?.(e);
      }}
      style={[anim, style]}
    >
      {children}
    </APressable>
  );
}

export function Button({
  title,
  onPress,
  kind = 'primary',
  loading,
  disabled,
  icon,
  style,
}: {
  title: string;
  onPress?: () => void;
  kind?: 'primary' | 'secondary' | 'ghost' | 'danger';
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  const { theme } = useTheme();
  const bg = kind === 'primary' ? theme.accent : kind === 'secondary' ? theme.cardHigh : 'transparent';
  const fg = kind === 'primary' ? theme.onAccent : kind === 'danger' ? theme.danger : theme.text;
  return (
    <Press
      onPress={onPress}
      disabled={disabled || loading}
      style={[
        {
          height: 56,
          borderRadius: theme.radius.pill,
          backgroundColor: bg,
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'row',
          gap: 10,
          paddingHorizontal: 24,
          opacity: disabled ? 0.4 : 1,
          borderWidth: kind === 'ghost' ? 1 : 0,
          borderColor: theme.border,
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <>
          {icon ? <View>{icon}</View> : null}
          <Txt v="bodyStrong" color={fg} style={{ fontSize: 16 }}>
            {title}
          </Txt>
        </>
      )}
    </Press>
  );
}
