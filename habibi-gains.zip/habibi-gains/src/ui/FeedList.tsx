// Friends' automatic achievements with 🔥 💪 👏 reactions (no comments).
import { router } from 'expo-router';
import React from 'react';
import { View } from 'react-native';
import { select } from '@/lib/haptics';
import { FeedItem, feedText, react, REACTIONS } from '@/lib/social';
import { useTheme } from '@/theme/theme';
import { Avatar } from './Avatar';
import { Card, Row } from './Layout';
import { Press } from './Press';
import { Txt } from './Txt';

export function FeedList({ items, me, lang, onChange }: { items: FeedItem[]; me?: string; lang: string; onChange: (next: FeedItem[]) => void }) {
  const { theme } = useTheme();
  const tap = (item: FeedItem, emoji: string) => {
    select();
    const mine = item.reactions.find((r) => r.user_id === me);
    const reactions = item.reactions.filter((r) => r.user_id !== me);
    if (mine?.emoji !== emoji && me) reactions.push({ emoji, user_id: me });
    onChange(items.map((i) => (i.id === item.id ? { ...i, reactions } : i)));
    react(item, emoji).catch(() => {});
  };
  return (
    <Card>
      {items.map((i, idx) => {
        const name = i.user_id === me ? (lang === 'ar' ? 'أنت' : 'You') : i.who?.display_name ?? (i.who?.username ? `@${i.who.username}` : '');
        return (
          <View key={i.id} style={{ gap: 8, paddingVertical: 6, borderTopWidth: idx ? 1 : 0, borderColor: theme.cardHigh }}>
            <Press onPress={() => router.push({ pathname: '/user/[id]', params: { id: i.user_id } })} style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
              <Avatar url={i.who?.avatar_url} name={i.who?.display_name ?? i.who?.username} size={34} />
              <Txt style={{ flex: 1 }}><Txt v="bodyStrong">{name}</Txt>{` ${feedText(i, lang)}`}</Txt>
            </Press>
            <Row gap={8} style={{ paddingLeft: 44 }}>
              {REACTIONS.map((e) => {
                const n = i.reactions.filter((r) => r.emoji === e).length;
                const on = i.reactions.some((r) => r.emoji === e && r.user_id === me);
                return (
                  <Press key={e} haptic={false} onPress={() => tap(i, e)} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, height: 30, borderRadius: 15, backgroundColor: on ? theme.accent + '33' : theme.cardHigh, borderWidth: on ? 1 : 0, borderColor: theme.accent }}>
                    <Txt style={{ fontSize: 15 }}>{e}</Txt>
                    {n ? <Txt v="small">{String(n)}</Txt> : null}
                  </Press>
                );
              })}
            </Row>
          </View>
        );
      })}
    </Card>
  );
}
