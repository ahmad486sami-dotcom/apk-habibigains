// The Instagram-story card (9:16). Rendered off-screen-sized and captured as an image.
import React, { forwardRef } from 'react';
import { View } from 'react-native';
import { useTheme } from '@/theme/theme';
import { Logo, TrendChart } from './Graphics';
import { Txt } from './Txt';

export type ShareData = {
  headline: string; // e.g. "−3.6 kg"
  label: string; // e.g. "30-day transformation"
  stats: { label: string; value: string }[];
  points: { weight: number; trend: number }[];
  style: 'bold' | 'minimal' | 'accent';
};

export const ShareCard = forwardRef<View, { data: ShareData; width: number }>(({ data, width }, ref) => {
  const { theme } = useTheme();
  const height = (width * 16) / 9;
  const accentBg = data.style === 'accent';
  const fg = accentBg ? theme.onAccent : theme.text;
  const sub = accentBg ? theme.onAccent : theme.muted;
  return (
    <View
      ref={ref}
      collapsable={false}
      style={{
        width,
        height,
        backgroundColor: accentBg ? theme.accent : '#000',
        padding: width * 0.08,
        justifyContent: 'space-between',
        borderRadius: 24,
        overflow: 'hidden',
      }}
    >
      <Logo width={width * 0.22} color={fg} />
      <View style={{ gap: 10 }}>
        <Txt v="label" color={sub}>{data.label}</Txt>
        <Txt v="hero" color={fg} style={{ fontSize: data.style === 'minimal' ? width * 0.16 : width * 0.21, lineHeight: width * 0.22 }}>
          {data.headline}
        </Txt>
        {data.style !== 'minimal' && data.points.length > 1 ? (
          <TrendChart points={data.points} width={width * 0.84} height={width * 0.32} showDots={false} />
        ) : null}
      </View>
      <View style={{ gap: 14 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          {data.stats.map((s) => (
            <View key={s.label} style={{ gap: 2 }}>
              <Txt v="h2" color={fg}>{s.value}</Txt>
              <Txt v="small" color={sub}>{s.label}</Txt>
            </View>
          ))}
        </View>
        <Txt v="bodyStrong" color={sub}>@habibigains.app</Txt>
      </View>
    </View>
  );
});
ShareCard.displayName = 'ShareCard';
