import React from 'react';
import { ScrollView, ScrollViewProps, StyleProp, TextInput, TextInputProps, View, ViewStyle } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { select } from '@/lib/haptics';
import { fonts, useTheme } from '@/theme/theme';
import { Press } from './Press';
import { Txt } from './Txt';

export function Screen({
  children,
  scroll = true,
  padded = true,
  bottomInset = 120,
  ...rest
}: ScrollViewProps & { scroll?: boolean; padded?: boolean; bottomInset?: number; children?: React.ReactNode }) {
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const pad = { paddingTop: insets.top + 12, paddingHorizontal: padded ? 20 : 0, paddingBottom: bottomInset };
  if (!scroll) return <View style={[{ flex: 1, backgroundColor: theme.bg }, pad]}>{children}</View>;
  return (
    <ScrollView
      {...rest}
      style={{ flex: 1, backgroundColor: theme.bg }}
      contentContainerStyle={[pad, { gap: 14 }]}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      {children}
    </ScrollView>
  );
}

/** Card that floats in with a stagger. */
export function Card({
  children,
  style,
  index = 0,
  onPress,
}: {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  index?: number;
  onPress?: () => void;
}) {
  const { theme } = useTheme();
  const inner = (
    <View style={[{ backgroundColor: theme.card, borderRadius: theme.radius.lg, padding: 18, gap: 10 }, style]}>{children}</View>
  );
  return (
    <Animated.View entering={FadeInDown.delay(index * 70).springify().damping(18)}>
      {onPress ? <Press onPress={onPress} scaleTo={0.98}>{inner}</Press> : inner}
    </Animated.View>
  );
}

export function Row({ children, style, gap = 12 }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; gap?: number }) {
  return <View style={[{ flexDirection: 'row', alignItems: 'center', gap }, style]}>{children}</View>;
}

export function Spacer({ h = 8 }: { h?: number }) {
  return <View style={{ height: h }} />;
}

export function Field(props: TextInputProps & { label?: string }) {
  const { theme } = useTheme();
  const { isRTL } = useI18n();
  return (
    <View style={{ gap: 8 }}>
      {props.label ? <Txt v="label" muted>{props.label}</Txt> : null}
      <TextInput
        placeholderTextColor={theme.faint}
        selectionColor={theme.accent}
        {...props}
        style={[
          {
            height: 56,
            borderRadius: theme.radius.md,
            backgroundColor: theme.card,
            color: theme.text,
            paddingHorizontal: 18,
            fontFamily: isRTL ? undefined : fonts.bodyMedium,
            fontSize: 17,
            textAlign: isRTL ? 'right' : 'left',
          },
          props.style,
        ]}
      />
    </View>
  );
}

export function Chips<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  const { theme } = useTheme();
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {options.map((o) => {
        const on = o.value === value;
        return (
          <Press
            key={o.value}
            haptic={false}
            onPress={() => {
              select();
              onChange(o.value);
            }}
            style={{
              paddingHorizontal: 16,
              height: 40,
              borderRadius: theme.radius.pill,
              justifyContent: 'center',
              backgroundColor: on ? theme.accent : theme.card,
            }}
          >
            <Txt v="bodyStrong" color={on ? theme.onAccent : theme.text} style={{ fontSize: 14 }}>
              {o.label}
            </Txt>
          </Press>
        );
      })}
    </View>
  );
}

/** Big selectable option (used in onboarding). */
export function Option({ title, subtitle, selected, onPress }: { title: string; subtitle?: string; selected: boolean; onPress: () => void }) {
  const { theme } = useTheme();
  return (
    <Press
      haptic={false}
      onPress={() => {
        select();
        onPress();
      }}
      scaleTo={0.98}
      style={{
        borderRadius: theme.radius.md,
        padding: 18,
        backgroundColor: selected ? theme.accent : theme.card,
        gap: 4,
      }}
    >
      <Txt v="h3" color={selected ? theme.onAccent : theme.text}>{title}</Txt>
      {subtitle ? <Txt v="small" color={selected ? theme.onAccent : theme.muted}>{subtitle}</Txt> : null}
    </Press>
  );
}

export function SectionTitle({ children, action, onAction }: { children: React.ReactNode; action?: string; onAction?: () => void }) {
  const { theme } = useTheme();
  return (
    <Row style={{ justifyContent: 'space-between', marginTop: 10 }}>
      <Txt v="h2">{children}</Txt>
      {action ? (
        <Press onPress={onAction}>
          <Txt v="bodyStrong" color={theme.accent}>{action}</Txt>
        </Press>
      ) : null}
    </Row>
  );
}
